# Hoja de ruta Chilly Willy / Cobbleverse — 2026-11-01

## Listo para probar en v0.9.20

- Activación automática del nuevo Pokémon/resource pack de Drive antes de iniciar Minecraft, con orden visual prioritario.
- Reconexión mediante la lista de Multijugador (v0.9.19).
- Controles y sensibilidad persistentes (v0.9.19).

## Pendientes para otra versión

1. Corregir Fresh Moves / ETF para todos los jugadores (`Allow skin transparency: All skins`) sin sobrescribir preferencias. Se necesita ejemplo del `config/entity_texture_features.json` que dejó ETF después del ajuste manual, porque no conocemos el esquema exacto de esa instalación.
2. Completar Launcher Studio como editor integral: mover elementos, añadir/eliminar botones y darles funciones, cambiar fondos, tarjetas y otras propiedades. Es trabajo de mayor alcance y no está incluido en este ZIP.

**La lista es planificación, no una afirmación de que esos cambios ya estén publicados.**
