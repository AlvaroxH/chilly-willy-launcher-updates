import { app, BrowserWindow, ipcMain, shell, safeStorage, dialog, Tray, Menu } from 'electron';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFileSync } from 'node:fs';
import { validateManifest } from './manifest-validator.mjs';
import { downloadManifestJson } from './manifest-network.mjs';
import { getMinecraftStatus } from './minecraft-status.mjs';
import { clipboard } from 'electron';
import { getSkinHeadData } from './skins.mjs';
import { readPreferences, savePreferences, validGuestName } from './profile-store.mjs';
import { activateResourcePacks } from './resourcepack-options.mjs';
import { applyMasterCompleteOptions, copyMasterPackIcon } from './master-complete-options.mjs';
import { applyPackKeybindings } from './keybindings-options.mjs';
import { activateCobbleverseShaders } from './shader-options.mjs';
import { loadMicrosoftSession, saveMicrosoftSession, deleteMicrosoftSession } from './secure-account-store.mjs';
import { createUpdateManager } from './auto-updates.mjs';
import { stageMasterConfig, applyMasterConfig } from './master-config-sync.mjs';
import { migrateMinecraftLocation, describeMinecraftPath } from './game-location.mjs';
import { readLaunchCache, installedPackIntact, launchMode, saveFullLaunch, markRemoteChecked } from './launch-cache.mjs';
import { retireRemovedManagedMods } from './managed-mod-cleanup.mjs';
import { createDiscordPresence } from './discord-presence.mjs';

const base = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(base, '..');
const settings = JSON.parse(readFileSync(path.join(projectRoot, 'config', 'server.json'), 'utf8'));
let win;
let tray = null;
let minecraftActive = false;
let hiddenForGame = false;
let quitting = false;
const discordPresence = createDiscordPresence();
let session = null; // En memoria; credenciales Microsoft cifradas en disco. Nunca se envían al renderer.
let busy = false;
const updates = createUpdateManager({
  app,
  isBusy: () => busy,
  emit: (update) => {
    if (win && !win.isDestroyed()) win.webContents.send('launcher:update-status', update);
  }
});
let memoryOverride = null;
let recentManifest = null;
let recentManifestAt = 0;
function getMemoryMb() {
  if (memoryOverride !== null) return memoryOverride;
  return readPreferences(app.getPath('userData')).memoryMb ?? settings.memoryMb;
}

// El Setup y el portable usan el mismo userData bajo AppData del usuario Windows.
// La cuenta se restaura sin ventanas de login; su token se valida/renueva al jugar.
async function restoreSavedMicrosoftSession() {
  try {
    const saved = await loadMicrosoftSession(app.getPath('userData'), safeStorage);
    if (!saved) return false;
    session = {type:'microsoft',name:saved.name,account:saved.account};
    return true;
  } catch {
    // No exponer datos de la sesión en registros; puede ser cifrado inaccesible tras cambiar de usuario.
    console.warn('No se pudo restaurar la sesión Microsoft cifrada. Iniciá sesión nuevamente.');
    return false;
  }
}

// El portable también usa la carpeta de usuario de Electron (%APPDATA%).
// Así el nick sobrevive al cierre, aunque se ejecute desde otro directorio.
async function restoreSavedGuestSession() {
  if (settings.allowGuest !== true) return;
  const name = readPreferences(app.getPath('userData')).guestName;
  if (!validGuestName(name)) return;
  try {
    const { CrackAuth } = await import('eml-lib');
    const account = await new CrackAuth().auth(name);
    if (!account) throw new Error('La biblioteca no devolvió una cuenta invitada.');
    session = { type: 'guest', name, account };
  } catch (error) {
    // Si falla la restauración, conservamos el nick para que el usuario pueda reintentarlo.
    console.warn('No se pudo restaurar el perfil invitado:', error?.message ?? String(error));
  }
}


const USERNAME = /^[A-Za-z0-9_]{3,16}$/;
const sendStatus = (message, percent = null, javaVersion = null) => {
  if (win && !win.isDestroyed()) win.webContents.send('launcher:progress', { message, percent, javaVersion });
};
// Solo se envían datos públicos al renderer; nunca exponer tokens de Microsoft.
function accountUuid(account) {
  const candidates = [account?.uuid, account?.id, account?.profile?.id, account?.profile?.uuid, account?.minecraft?.uuid, account?.minecraft?.id];
  const id = candidates.find(v => typeof v === 'string' && /^[0-9a-f]{8}-?(?:[0-9a-f]{4}-?){3}[0-9a-f]{12}$/i.test(v));
  return id ? id.replace(/-/g, '').toLowerCase() : null;
}
const viewAccount = () => session ? ({ type: session.type, name: session.name, uuid: session.type === 'microsoft' ? accountUuid(session.account) : null }) : null;
const publicSettings = () => ({
  minecraftVersion: settings.minecraftVersion,
  javaMajorVersion: 21,
  javaManagedAutomatically: true,
  fabricLoaderVersion: settings.fabricLoaderVersion,
  serverAddress: settings.serverAddress,
  hasManifest: Boolean(settings.modpackManifestUrl),
  driveFolderUrl: settings.driveFolderUrl,
  driveSnapshot: settings.driveSnapshot,
  allowGuest: settings.allowGuest === true,
  memoryMb: getMemoryMb(),
  savedGuestName: readPreferences(app.getPath('userData')).guestName ?? null,
  account: viewAccount(),
  discordPresenceEnabled: readPreferences(app.getPath('userData')).discordPresenceEnabled !== false
});
const validateConfig = () => {
  if (!settings.serverAddress || !/^[a-zA-Z0-9._-]+(?::\d{1,5})?$/.test(settings.serverAddress)) {
    throw new Error('Configurá serverAddress (IP o dominio y puerto) en config/server.json.');
  }
  if (!settings.fabricLoaderVersion || !/^\d+\.\d+\.\d+$/.test(settings.fabricLoaderVersion)) {
    throw new Error('Configurá la misma versión de Fabric Loader del servidor en config/server.json.');
  }
  if (!settings.modpackManifestUrl || !settings.modpackManifestUrl.startsWith('https://')) {
    throw new Error('Falta modpackManifestUrl: desplegá el Apps Script y pegá su URL /exec en config/server.json.');
  }
};

function ensureTray() {
  if (tray) return;
  tray = new Tray(path.join(projectRoot, 'build', 'taskbar-c.ico'));
  tray.setToolTip('Chilly Willy Launcher · Minecraft en ejecución');
  tray.setContextMenu(Menu.buildFromTemplate([
    {label:'Mostrar Chilly Willy', click:() => { hiddenForGame = false; win?.show(); win?.focus(); }},
    {label:'Salir del launcher', click:() => { quitting = true; app.quit(); }}
  ]));
  tray.on('double-click', () => { hiddenForGame = false; win?.show(); win?.focus(); });
}
function createWindow() {
  win = new BrowserWindow({
    width: 1350,
    height: 820,
    minWidth: 920,
    minHeight: 650,
    frame: false,
    backgroundColor: '#0b0a10',
    title: 'Chilly Willy Launcher',
    icon: path.join(projectRoot, 'build', 'taskbar-c.ico'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(base, 'preload.cjs'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false
    }
  });
  win.on('close', (event) => {
    if (!quitting && minecraftActive) {
      event.preventDefault();
      ensureTray();
      hiddenForGame = true;
      win.hide();
    }
  });
  win.loadFile(path.join(projectRoot, 'ui', 'index.html'));
  // El instalador busca nuevas versiones luego de que la pantalla está cargada.
  win.webContents.once('did-finish-load', () => {
    win.webContents.send('launcher:update-status', updates.getState());
    void updates.check();
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

app.setAppUserModelId('com.cobbleverse.launcher');

app.whenReady().then(async () => {
  if (!await restoreSavedMicrosoftSession()) await restoreSavedGuestSession();
  createWindow();
  discordPresence.setEnabled(readPreferences(app.getPath('userData')).discordPresenceEnabled !== false);
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin' && !minecraftActive) app.quit(); });
app.on('before-quit', () => { quitting = true; discordPresence.stop(); });

ipcMain.handle('launcher:state', () => publicSettings());
ipcMain.handle('launcher:updates-state', () => updates.getState());
ipcMain.handle('launcher:discord-presence-state', () => discordPresence.getState());
ipcMain.handle('launcher:set-discord-presence', (_event, enabled) => {
  if (typeof enabled !== 'boolean') throw new Error('Preferencia de Discord inválida.');
  savePreferences(app.getPath('userData'), {discordPresenceEnabled: enabled});
  discordPresence.setEnabled(enabled);
  return discordPresence.getState();
});
ipcMain.handle('launcher:check-updates', () => updates.check({force: true}));
ipcMain.handle('launcher:install-update', () => updates.install());

ipcMain.handle('launcher:window-action', (event, action) => {
  const window = BrowserWindow.fromWebContents(event.sender);
  if (!window || window !== win) return;
  switch (action) {
    case 'minimize': window.minimize(); break;
    case 'maximize': window.isMaximized() ? window.unmaximize() : window.maximize(); break;
    case 'close': window.close(); break;
    default: throw new Error('Acción de ventana desconocida');
  }
});
ipcMain.handle('launcher:server-status', async () => getMinecraftStatus(settings.serverAddress));
ipcMain.handle('launcher:skin-head', async (_event, identity) => getSkinHeadData(identity));
ipcMain.handle('launcher:copy-ip', () => { clipboard.writeText(settings.serverAddress); return true; });
// La carpeta del programa se selecciona en el instalador NSIS. Minecraft es
// independiente y guarda Java, mods, shaders, saves y recursos en la unidad elegida.
ipcMain.handle('launcher:game-location', async () => ({
  ...await describeMinecraftPath(app.getPath('appData')),
  acknowledged: readPreferences(app.getPath('userData')).storageChoiceMade === true
}));
ipcMain.handle('launcher:default-game-location', () => {
  if (busy) throw new Error('Hay una operación en curso.');
  savePreferences(app.getPath('userData'), { storageChoiceMade: true });
  return {ok:true};
});
ipcMain.handle('launcher:choose-game-location', async () => {
  if (busy) throw new Error('Esperá hasta que Minecraft termine.');
  const before = await describeMinecraftPath(app.getPath('appData'));
  const chosen = await dialog.showOpenDialog(win, {
    title: 'Elegir carpeta para Minecraft Cobbleverse',
    buttonLabel: 'Usar esta carpeta',
    properties: ['openDirectory','createDirectory']
  });
  if (chosen.canceled || !chosen.filePaths?.[0]) return {cancelled:true, ...before};
  const destination = chosen.filePaths[0];
  const response = await dialog.showMessageBox(win, {
    type: 'question',
    title: 'Cambiar ubicación de Minecraft',
    message: before.installed ? '¿Mover Minecraft a la carpeta elegida?' : '¿Instalar Minecraft en esta carpeta?',
    detail: `Destino: ${destination}\n\n${before.installed ? 'Se copiarán Java, mods, recursos, mundos y todas las configuraciones. La operación puede tardar; no cierres Chilly Willy. La ubicación anterior se libera solamente cuando la nueva esté comprobada.' : 'Java, Minecraft y el modpack se descargarán allí al jugar. No se moverán datos de otras aplicaciones.'}`,
    buttons: ['Cancelar','Confirmar'],
    defaultId: 1,
    cancelId: 0,
    noLink: true
  });
  if (response.response !== 1) return {cancelled:true, ...before};
  busy = true;
  try {
    const result = await migrateMinecraftLocation({
      appData: app.getPath('appData'), destination,
      progress: message => sendStatus(message)
    });
    savePreferences(app.getPath('userData'), { storageChoiceMade: true });
    sendStatus(result.cleanupNeeded
      ? `Minecraft se cambió a ${result.path}. Revisá el respaldo anterior: ${result.oldLocation}.`
      : `Minecraft listo en ${result.path}.`, 100);
    return {...await describeMinecraftPath(app.getPath('appData')), ...result, acknowledged:true};
  } finally { busy = false; }
});

ipcMain.handle('launcher:set-memory', (_event, memoryMb) => {
  if (busy) throw new Error('No podés cambiar RAM mientras se inicia el juego.');
  if (![2048, 4096, 6144, 8192, 12288].includes(memoryMb)) throw new Error('Asignación de RAM inválida');
  savePreferences(app.getPath('userData'), { memoryMb });
  memoryOverride = memoryMb;
  return { memoryMb };
});

// La consulta se hace desde el proceso principal para evitar CORS y aislar la URL de descarga.
async function fetchManifest({forceRemote = false} = {}) {
  // Reutilizar el resultado de una consulta reciente; EML no tiene por qué
  // repetir una enumeración costosa de Drive al pulsar JUGAR.
  if (!forceRemote && recentManifest && Date.now() - recentManifestAt < 5 * 60_000) return recentManifest;
  const target = settings.modpackManifestUrl;
  if (!/^https:\/\/script\.google\.com\/macros\/s\/[A-Za-z0-9_-]+\/exec$/.test(target || '')) {
    throw new Error('La URL del manifiesto no tiene el formato /exec esperado.');
  }
  const json = await downloadManifestJson(target, {
    timeoutMs: 90000,
    retries: 1,
    onRetry: ({ reason }) => sendStatus(`Google Drive no respondió a tiempo (${reason}). Reintentando automáticamente…`)
  });
  recentManifest = validateManifest(json);
  recentManifestAt = Date.now();
  return recentManifest;
}

ipcMain.handle('launcher:check-manifest', async (_event, forceRemote = false) => {
  const cached = readLaunchCache(app.getPath('userData'));
  if (!forceRemote && launchMode({entry:cached, settings}) === 'fast') return cached.pack;
  const remote = await fetchManifest({forceRemote});
  if (installedPackIntact(cached, settings)) markRemoteChecked(app.getPath('userData'), cached, remote);
  return remote;
});
ipcMain.handle('launcher:force-modpack-sync', () => {
  if (busy) throw new Error('Esperá a que termine el inicio actual.');
  savePreferences(app.getPath('userData'), { forceModpackSync: true });
  return {ok:true, message:'En el próximo inicio se comprobará y reparará el modpack completo.'};
});

ipcMain.handle('launcher:login-microsoft', async () => {
  if (busy) throw new Error('Hay una operación en curso.');
  busy = true;
  try {
    const { MicrosoftAuth } = await import('eml-lib');
    sendStatus('Abriendo el inicio de sesión de Microsoft…');
    const account = await new MicrosoftAuth(win).auth();
    if (!account) throw new Error('Microsoft no devolvió una sesión válida.');
    // La estructura de Account puede variar según la versión de EML Lib.
    const name = account.name ?? account.username ?? account.profile?.name ?? 'Jugador Microsoft';
    savePreferences(app.getPath('userData'), { guestName: null });
    session = { type: 'microsoft', name, account };
    try {
      await saveMicrosoftSession(app.getPath('userData'), safeStorage, name, account);
      sendStatus('Sesión Microsoft iniciada y guardada de forma cifrada en Windows.');
    } catch {
      sendStatus('Sesión Microsoft iniciada, pero no pudo guardarse. La próxima apertura podría requerir iniciar sesión otra vez.');
    }
    return viewAccount();
  } finally {
    busy = false;
    if (!minecraftActive) discordPresence.setPhase('idle');
  }
});

ipcMain.handle('launcher:login-guest', async (_event, requestedName) => {
  if (busy) throw new Error('Hay una operación en curso.');
  const name = String(requestedName ?? '').trim();
  if (!USERNAME.test(name)) throw new Error('El nick debe tener 3 a 16 caracteres: letras, números o guion bajo.');
  const { CrackAuth } = await import('eml-lib');
  const account = await new CrackAuth().auth(name);
  if (!account) throw new Error('No se pudo preparar el perfil invitado.');
  savePreferences(app.getPath('userData'), { guestName: name });
  deleteMicrosoftSession(app.getPath('userData')); // Cambiar a invitado elimina credenciales de Microsoft.
  session = { type: 'guest', name, account };
  sendStatus('Perfil invitado preparado. El servidor debe admitir cuentas offline y proteger las identidades.');
  return viewAccount();
});

ipcMain.handle('launcher:logout', async () => {
  if (busy) throw new Error('Esperá a que finalice la operación actual.');
  savePreferences(app.getPath('userData'), { guestName: null });
  deleteMicrosoftSession(app.getPath('userData'));
  session = null;
  return null;
});

ipcMain.handle('launcher:play', async () => {
  if (busy) throw new Error('Ya hay una descarga o inicio en curso.');
  if (!session) throw new Error('Primero iniciá sesión.');
  if (session.type === 'guest' && settings.allowGuest !== true) {
    throw new Error('Este launcher no tiene habilitado el modo invitado.');
  }
  validateConfig();
  busy = true;
  discordPresence.setPhase('preparing');
  try {
    const userData = app.getPath('userData');
    const cached = readLaunchCache(userData);
    const forced = readPreferences(userData).forceModpackSync === true;
    // v0.9.17: CADA clic en JUGAR consulta Drive, sin caché de tiempo.
    // Sólo se usa inicio rápido si el manifiesto REMOTO recién validado es idéntico.
    // Un fallo de Drive jamás se interpreta como lista vacía ni autoriza borrados.
    let mode = 'full';
    let pack = null;
    let verifiedRemote = false;
    sendStatus('JUGAR: comprobando cambios de mods, configuraciones y recursos en Google Drive…');
    try {
      const remote = await fetchManifest({forceRemote: true});
      if (!remote.fullPack) throw new Error('Apps Script no incluye todas las carpetas del modpack.');
      if (!remote.completeMaster || remote.version < 6) throw new Error('Publicá el manifiesto v6 de Google Apps Script.');
      if (!remote.fullShaderPack) throw new Error('El manifiesto de Drive todavía no incluye los shaders.');
      verifiedRemote = true;
      mode = launchMode({entry:cached, settings, force:forced, remotePack:remote});
      pack = mode === 'fast' ? cached.pack : remote;
      if (mode === 'fast') {
        markRemoteChecked(userData, cached, remote);
        sendStatus('Modpack actualizado: no hay archivos nuevos ni eliminados.');
      } else {
        sendStatus('Hay archivos nuevos, retirados o pendientes de reparación. Sincronizando antes de jugar…');
      }
    } catch (error) {
      if (installedPackIntact(cached, settings) && !forced) {
        // Si no hay conexión, permitir jugar con la instalación verificada previa.
        // No se toca NINGÚN mod: no tenemos un manifiesto válido y reciente.
        mode = 'fast';
        pack = cached.pack;
        verifiedRemote = false;
        sendStatus('Google Drive no respondió: sin borrar archivos; iniciando con los mods locales comprobados.');
      } else {
        throw error;
      }
    }
    const fastLaunch = mode === 'fast';
    if (fastLaunch) sendStatus('Inicio rápido: Minecraft y mods locales listos.');
    else sendStatus(`Sincronizando modpack: ${pack.count} mods, ${pack.counts.resourcepacks} resource packs y shaders. Primera instalación o actualización detectada…`);
    const { Launcher, MicrosoftAuth } = await import('eml-lib');
    if (session.type === 'microsoft') {
      const auth = new MicrosoftAuth(win);
      if (!(await auth.validate(session.account))) {
        sendStatus('Renovando sesión de Minecraft…');
        try {
          const updatedAccount = await auth.refresh(session.account);
          if (!updatedAccount) throw new Error('Microsoft no devolvió credenciales renovadas.');
          session.account = updatedAccount;
          // Las credenciales renovadas reemplazan las anteriores también en el almacén cifrado.
          try { await saveMicrosoftSession(app.getPath('userData'), safeStorage, session.name, updatedAccount); }
          catch { sendStatus('Sesión renovada, pero Windows no pudo guardarla cifrada.'); }
        } catch {
          throw new Error('No se pudo renovar la sesión Microsoft. Comprobá tu conexión y, si persiste, cerrá sesión e iniciá Microsoft nuevamente.');
        }
      }
    }
    const launcher = new Launcher({
      root: 'cobbleverse',
      account: session.account,
      storage: 'isolated',
      cleaning: { enabled: false }, // No borrar saves, resourcepacks ni mods personales.
      minecraft: {
        version: settings.minecraftVersion,
        loader: { loader: 'fabric', version: settings.fabricLoaderVersion },
        // En un arranque rápido NO pasar el modpack al motor de EML:
        // evita reenumerar y reprocesar cientos de ficheros de Google Drive.
        // El botón JUGAR ya verificó Drive en línea justo antes de llegar acá.
        ...(fastLaunch ? {} : {modpackUrl: settings.modpackManifestUrl}),
        args: ['--quickPlayMultiplayer', settings.serverAddress]
      },
      java: { install: 'auto' },
      memory: { min: 2048, max: getMemoryMb() }
    });
    // Snapshot verificado de TODAS las configuraciones del maestro. Se obtiene antes
    // de iniciar EML para aplicarse de forma síncrona justo antes de arrancar Java.
    // Si Google Drive limita una descarga, el modpack existente sigue siendo jugable.
    let configSnapshot = null;
    if (!fastLaunch) try {
      configSnapshot = await stageMasterConfig({
        files: pack.configurationFiles,
        cacheRoot: path.join(app.getPath('userData'), 'master-config-cache'),
        progress: (done, total) => {
          if (done === total || done % 20 === 0) sendStatus(`Verificando configuraciones maestras (${done}/${total})…`);
        }
      });
      if (configSnapshot.errors.length) {
        console.warn(`Archivos maestros pendientes: ${configSnapshot.errors.length}/${configSnapshot.requested}.`);
        sendStatus(`Aviso: ${configSnapshot.errors.length} configuraciones aún no se pudieron descargar de Drive. Se reintentará al iniciar otra vez.`);
      }
    } catch (error) {
      console.warn('Configuración maestra no disponible:', String(error?.message ?? error).slice(0,180));
      sendStatus('Aviso: algunas configuraciones maestras no pudieron descargarse; se intentará iniciar con las disponibles.');
    }
    launcher.on('launch_compute_download', () => sendStatus(fastLaunch ? 'Verificando el entorno de Minecraft…' : 'Comprobando archivos y actualizaciones…'));
    // EML Lib administra el entorno Java necesario sin instalador ni permisos de administrador.
    // Para Minecraft 1.21.1, el runtime oficial corresponde a Java 21.
    launcher.on('launch_check_java', () => sendStatus('Comprobando Java 21 (se descarga automáticamente si falta)…'));
    launcher.on('java_info', (info) => {
      const version = String(info?.version ?? '21');
      const arch = info?.arch ? ` · ${info.arch}` : '';
      if (!/^21(?:\.|$)/.test(version)) {
        sendStatus(`Aviso: EML detectó Java ${version}. Se esperaba Java 21.`);
      } else {
        sendStatus(`Java ${version}${arch} listo para Minecraft.`, null, version);
      }
    });
    launcher.on('download_progress', (data) => {
      if (!/java|runtime|jre/i.test(String(data?.type ?? ''))) return;
      const all = Number(data?.total?.size ?? 0);
      const current = Number(data?.downloaded?.size ?? 0);
      const percent = all > 0 ? Math.min(100, Math.round(100 * current / all)) : null;
      sendStatus('Descargando Java 21 automáticamente…', percent);
    });
    launcher.on('launch_install_loader', () => sendStatus('Comprobando Fabric Loader…'));
    launcher.on('launch_download', (data) => {
      const total = data?.total?.amount ?? 0;
      const downloaded = data?.total?.downloaded ?? 0;
      const ratio = total > 0 ? Math.round(100 * downloaded / total) : null;
      sendStatus('Descargando archivos de Cobbleverse…', ratio);
    });
    // El evento se dispara DESPUÉS de descargar/copiar el modpack y ANTES de iniciar Java.
    // Se escribe options.txt de la instancia aislada, no el de .minecraft global.
    launcher.on('launch_launch', () => {
      minecraftActive = true;
      discordPresence.setPhase('playing');
      if (fastLaunch) {
        // Configuración y paquetes ya instalados: no reescribirlos en cada partida.
        sendStatus('Iniciando Minecraft con los archivos instalados…', 100);
        return;
      }
      let configResult = {applied: 0, total: 0, critical: []};
      let configApplied = false;
      if (configSnapshot) {
        try { configResult = applyMasterConfig({instanceRoot: launcher.config.root, snapshot: configSnapshot}); configApplied = true; }
        catch (error) { console.warn('No se pudo migrar configuración maestra:', String(error?.message ?? error).slice(0,180)); }
      }
      if (configResult.critical.length) console.warn('Faltan recursos de interfaz del modpack: '+configResult.critical.join(', '));
      // Default Options guarda los controles en config/defaultoptions/keybindings.txt.
      // Como el launcher debe escribir options.txt para habilitar resourcepacks,
      // debemos aplicar también esos controles ANTES del inicio de Java.
      const keys = applyPackKeybindings(launcher.config.root);
      // v0.9.12: copiar TODAS las opciones maestras, no solo los ajustes gráficos.
      const visuals = applyMasterCompleteOptions(launcher.config.root);
      const packIcon = copyMasterPackIcon(launcher.config.root);
      const selected = activateResourcePacks(launcher.config.root, pack.resourcepackFiles);
      const shader = activateCobbleverseShaders(launcher.config.root);
      sendStatus(`Perfiles maestros (${configResult.applied}/${configResult.total}), controles (${keys.total}), ${visuals.total} opciones maestras (${visuals.applied} cambios), ${selected.enabledCount} resource packs y shader ${shader.selected} preparados. Iniciando Minecraft…`, 100);
      // Sólo retirar mods que previamente gestionaba ESTE launcher y que
      // desaparecieron de un manifiesto válido. Jamás tocar mods personales.
      // Primero confirmar que los nuevos .jar están completos y las configuraciones
      // se descargaron. Ante error o manifest no verificable NO se elimina nada.
      const configReady = configApplied && configResult.critical.length === 0 &&
        configSnapshot && configSnapshot.requested === configSnapshot.length &&
        configSnapshot.errors.length === 0;
      if (configReady && verifiedRemote) {
        try {
          const cleanup = retireRemovedManagedMods({
            instanceRoot: launcher.config.root,
            previousCache: cached,
            currentPack: pack,
            settings
          });
          if (cleanup.removed.length) sendStatus(`${cleanup.removed.length} mod(s) obsoletos retirados de mods/ con copia de seguridad.`, 100);
          if (cleanup.preserved.length) console.warn('Mods anteriores conservados por seguridad: '+cleanup.preserved.join(', '));
          // La caché sólo avanza si EML dejó instalados los mods del nuevo manifiesto.
          if (saveFullLaunch(userData, {pack, settings, instanceRoot: launcher.config.root})) {
            savePreferences(userData, {forceModpackSync:false});
          } else {
            console.warn('No se confirmó instalación íntegra de mods; reintentar sincronización en el próximo JUGAR.');
          }
        } catch (error) {
          // No ocultar errores importantes de la reparación automática.
          console.warn('Sincronización incompleta:', String(error?.message ?? error).slice(0,240));
          sendStatus('Aviso: no se pudo completar la limpieza segura de mods; conservamos los archivos anteriores.', 100);
        }
      } else {
        sendStatus('Aviso: configuraciones incompletas. No se borraron mods; se repararán en el próximo JUGAR.', 100);
      }
    });
    launcher.on('launch_close', (code) => {
      minecraftActive = false;
      discordPresence.setPhase('idle');
      sendStatus(`Minecraft finalizó (código ${code}).`);
      if (hiddenForGame) { quitting = true; app.quit(); }
    });
    sendStatus('Preparando Cobbleverse…');
    await launcher.launch();
    return { ok: true };
  } finally {
    busy = false;
    if (!minecraftActive) discordPresence.setPhase('idle');
  }
});
