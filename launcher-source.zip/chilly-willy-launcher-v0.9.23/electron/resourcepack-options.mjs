/**
 * Chilly Willy Launcher - resource packs 1.21.1.
 * La descarga la hace EML; esto selecciona packs en options.txt justo ANTES de lanzar Java.
 * Se preservan los demás ajustes del usuario y no se alteran otros Minecraft instalados.
 */
import fs from 'node:fs';
import path from 'node:path';

const PACK_ID = /^file\/(.+)$/i;
const VALID_PACK = /^[^\\/:*?"<>|\x00-\x1f]{1,230}\.zip$/i;

// Todos los ZIP en resourcepacks/, incluso si el nombre advierte DO NOT ENABLE.
// .rpo son metadatos, no ZIPs que Minecraft pueda cargar.
export function enabledPackIdsFromManifest(resourcepackFiles) {
  if (!Array.isArray(resourcepackFiles)) throw new Error('Listado de resource packs inválido.');
  const seen = new Set();
  const out = [];
  for (const item of resourcepackFiles) {
    if (!item || item.path !== 'resourcepacks/' || typeof item.name !== 'string') continue;
    if (!VALID_PACK.test(item.name)) continue;
    const id = 'file/' + item.name;
    const key = id.toLowerCase();
    if (!seen.has(key)) { seen.add(key); out.push(id); }
  }
  // Orden estable: una lista nueva de Drive solo cambia si se agrega/quita un pack.
  out.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
  return out;
}

/** Packs que el administrador quiere mantener activos con prioridad ALTA.
 * La lista es explícita para no reactivar paquetes que el jugador deshabilitó.
 */
export function priorityPackIds(resourcepackFiles, priorityPackNames = []) {
  if (!Array.isArray(priorityPackNames) || priorityPackNames.length > 30 ||
      priorityPackNames.some(n => typeof n !== 'string' || !VALID_PACK.test(n))) {
    throw new Error('La lista de resource packs prioritarios es inválida.');
  }
  const available = new Map(enabledPackIdsFromManifest(resourcepackFiles).map(id => [id.slice(5).toLowerCase(), id]));
  const result = [];
  const seen = new Set();
  for (const name of priorityPackNames) {
    const key = name.toLowerCase();
    if (available.has(key) && !seen.has(key)) { result.push(available.get(key)); seen.add(key); }
  }
  return result;
}

/** En inicios rápidos, solo reafirma packs marcados como obligatorios.
 * No cambia ni reactiva los demás packs que el jugador pudo desactivar.
 * Un pack faltante NO se introduce en options.txt hasta haberse descargado.
 */
export function ensurePriorityResourcePacks(instanceRoot, resourcepackFiles, priorityPackNames = []) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('Instancia inválida.');
  const wanted = priorityPackIds(resourcepackFiles, priorityPackNames);
  const missing = priorityPackNames.filter(name => !wanted.some(id => id.slice(5).toLowerCase() === name.toLowerCase()));
  const ready = [];
  for (const id of wanted) {
    const file = path.join(instanceRoot, 'resourcepacks', id.slice(5));
    try {
      const st = fs.lstatSync(file);
      if (!st.isSymbolicLink() && st.isFile() && st.size > 0) ready.push(id);
      else missing.push(id.slice(5));
    } catch { missing.push(id.slice(5)); }
  }
  if (!ready.length) return {changed:false, enabledCount:0, missing};
  const optionFile = path.join(instanceRoot, 'options.txt');
  const before = fs.existsSync(optionFile) ? fs.readFileSync(optionFile, 'utf8') : '';
  if (Buffer.byteLength(before, 'utf8') > 1024*1024) throw new Error('options.txt demasiado grande.');
  const bom = before.startsWith('\uFEFF') ? '\uFEFF' : '';
  const plain = bom ? before.slice(1) : before;
  const newline = plain.includes('\r\n') ? '\r\n' : '\n';
  const lines = plain ? plain.split(/\r?\n/).filter(Boolean) : ['version:3955'];
  const existing = jsonArrayFromOption(lines, 'resourcePacks');
  const readyKeys = new Set(ready.map(id => id.toLowerCase()));
  const merged = [...existing.filter(id => !readyKeys.has(id.toLowerCase())), ...ready];
  setOption(lines, 'resourcePacks', JSON.stringify(merged));
  const after = bom + lines.join(newline) + newline;
  if (after !== before) {
    fs.mkdirSync(instanceRoot, {recursive:true});
    const tmp = path.join(instanceRoot, `options.txt.chilly-priority-${process.pid}.tmp`);
    try {fs.writeFileSync(tmp, after, {encoding:'utf8', flag:'wx'});fs.renameSync(tmp,optionFile);}
    finally {try{fs.unlinkSync(tmp);}catch{}}
  }
  return {changed:after!==before, enabledCount:ready.length, missing};
}

function jsonArrayFromOption(lines, name) {
  const prefix = name + ':';
  const line = lines.find(line => line.startsWith(prefix));
  if (!line) return [];
  try {
    const result = JSON.parse(line.slice(prefix.length));
    return Array.isArray(result) ? result.filter(v => typeof v === 'string') : [];
  } catch { return []; }
}

function setOption(lines, name, value) {
  const entry = name + ':' + value;
  const at = lines.findIndex(line => line.startsWith(name + ':'));
  if (at >= 0) {
    lines[at] = entry;
    // Evitar claves duplicadas; Minecraft puede interpretar la primera o la última.
    for (let i = lines.length - 1; i > at; i--) if (lines[i].startsWith(name + ':')) lines.splice(i, 1);
  } else lines.push(entry);
}

/** Cambia únicamente resourcePacks. No toca opciones de vídeo, sonido ni teclas. */
export function activateResourcePacks(instanceRoot, resourcepackFiles, { priorityPackNames = [] } = {}) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) {
    throw new Error('No se pudo localizar la carpeta absoluta de Minecraft (EML Lib).');
  }
  const selected = enabledPackIdsFromManifest(resourcepackFiles);
  const masterOptionsFile = path.join(instanceRoot, 'presets', 'options.txt');
  let masterOrder = [];
  if (fs.existsSync(masterOptionsFile) && fs.statSync(masterOptionsFile).size <= 1024*1024) {
    const text = fs.readFileSync(masterOptionsFile, 'utf8');
    masterOrder = jsonArrayFromOption(text.split(/\r?\n/), 'resourcePacks');
  }
  const priority = priorityPackIds(resourcepackFiles, priorityPackNames);
  // Si Drive no aporta ZIP, no tocar options.txt accidentalmente.
  if (!selected.length) throw new Error('No hay resource packs .zip válidos para activar. Revisá Drive.');
  const optionFile = path.join(instanceRoot, 'options.txt');
  const previous = fs.existsSync(optionFile) ? fs.readFileSync(optionFile, 'utf8') : '';
  const bom = previous.startsWith('\uFEFF') ? '\uFEFF' : '';
  const plain = bom ? previous.slice(1) : previous;
  const newline = plain.includes('\r\n') ? '\r\n' : '\n';
  const lines = plain ? plain.split(/\r?\n/).filter(Boolean) : ['version:3955'];
  // 'vanilla' y 'fabric' son packs internos; conservar los que ya usa el jugador.
  // Mantener packs adicionales personales, incluso los que dicen DO NOT ENABLE.
  const existing = jsonArrayFromOption(lines, 'resourcePacks');
  const merged = [];
  const seen = new Set();
  const available = new Set(selected.map(id=>id.toLowerCase()));
  // Para el modpack maestro, primero respetamos el orden de prioridad oficial.
  // Entradas del propio juego/mod también se conservan.
  const officialOrder = masterOrder.filter(id => !PACK_ID.test(id) || available.has(id.toLowerCase()));
  const officialSet = new Set(officialOrder.map(id => id.toLowerCase()));
  // Minecraft da mayor prioridad a los elementos del FINAL de resourcePacks.
  // Por eso mantenemos el orden maestro al final y colocamos los packs externos
  // (incluidos mods añadidos a Drive) por debajo, sin modificar los que ya usa el jugador.
  const extras = [...existing, ...selected].filter(id => !officialSet.has(String(id).toLowerCase()));
  const priorityKeys = new Set(priority.map(id => id.toLowerCase()));
  // Prioridad del último pack en la lista: el Pokémon debe poder sobrescribir
  // su propio modelo o textura aunque otro pack use el mismo recurso.
  for (const id of [...extras, ...officialOrder].filter(id => !priorityKeys.has(id.toLowerCase())).concat(priority)) {
    if (!id || typeof id !== 'string') continue;
    const key = id.toLowerCase();
    if (!seen.has(key)) { seen.add(key); merged.push(id); }
  }
  setOption(lines, 'resourcePacks', JSON.stringify(merged));
  if (!lines.some(line => line.startsWith('version:'))) lines.unshift('version:3955');
  // Registrar los packs forzados también en la lista de packs cuya incompatibilidad
  // de formato fue aceptada (Minecraft podría rechazar contenidos realmente rotos).
  // No reemplazamos las aprobaciones personales de otros packs.
  const incompatible = jsonArrayFromOption(lines, 'incompatibleResourcePacks');
  const approved = [...new Set([...incompatible, ...selected])];
  setOption(lines, 'incompatibleResourcePacks', JSON.stringify(approved));
  const result = bom + lines.join(newline) + newline;
  if (result !== previous) {
    fs.mkdirSync(instanceRoot, { recursive: true });
    // Escritura por reemplazo para minimizar riesgos de archivo truncado.
    const temp = path.join(instanceRoot, `options.txt.chilly-${process.pid}.tmp`);
    try { fs.writeFileSync(temp, result, { encoding: 'utf8', flag: 'wx' }); fs.renameSync(temp, optionFile); }
    finally { try { fs.unlinkSync(temp); } catch {} }
  }
  return { enabledCount: selected.length, changed: result !== previous, optionFile };
}

/** Encuentra los resource packs realmente instalados en el cliente.
 * Minecraft acepta ZIP o carpetas que contengan pack.mcmeta. El manifiesto de
 * Drive es la fuente para la descarga, pero NO contiene necesariamente todos
 * los paquetes que ya existen en el juego (packs locales/extraídos).
 * Nunca se sigue un symlink ni se exploran carpetas ajenas a resourcepacks/.
 */
export function installedLocalPackIds(instanceRoot) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('Instancia inválida.');
  const base = path.join(instanceRoot, 'resourcepacks');
  let entries;
  try { entries = fs.readdirSync(base, {withFileTypes:true}); }
  catch (error) { if (error?.code === 'ENOENT') return []; throw error; }
  const result = [];
  const seen = new Set();
  for (const entry of entries) {
    const name = entry.name;
    if (typeof name !== 'string' || name.length < 1 || name.length > 230 ||
        /[\\/:*?"<>|\x00-\x1f]/.test(name) || name === '.' || name === '..' ||
        name.endsWith('.') || name.endsWith(' ')) continue;
    try {
      if (entry.isFile() && VALID_PACK.test(name) && fs.statSync(path.join(base, name)).size > 0) {
        // Los .zip.disabled nunca se activan; no son ZIP a ojos de Minecraft.
      } else if (entry.isDirectory()) {
        const marker = path.join(base, name, 'pack.mcmeta');
        const stat = fs.lstatSync(marker);
        if (!stat.isFile() || stat.isSymbolicLink() || stat.size < 1) continue;
      } else continue;
    } catch { continue; }
    const id = 'file/' + name;
    const key = id.toLowerCase();
    if (!seen.has(key)) { seen.add(key); result.push(id); }
  }
  result.sort((a,b)=>a.localeCompare(b,'en',{sensitivity:'base'}));
  return result;
}

function uniqueIds(values) {
  const out = [], seen = new Set();
  for (const id of values) {
    if (typeof id !== 'string' || !id || id.length > 400) continue;
    const key = id.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key); out.push(id);
  }
  return out;
}

/** En CADA inicio habilita todos los paquetes realmente instalados, respeta el
 * orden oficial de presets/options.txt y coloca al final los packs prioritarios.
 * No se confunde descarga (Drive) con activación (options.txt).
 * No cambia sensibilidad, teclas, volumen ni ningún otro ajuste.
 */
export function ensureAllResourcePacks(instanceRoot, resourcepackFiles, priorityPackNames = []) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('Instancia inválida.');
  const listed = enabledPackIdsFromManifest(resourcepackFiles);
  const actual = installedLocalPackIds(instanceRoot);
  const actualKeys = new Set(actual.map(id => id.toLowerCase()));
  const missing = listed.filter(id => !actualKeys.has(id.toLowerCase())).map(id => id.slice(5));
  if (!actual.length) return {changed:false,enabledCount:0,missing};

  // Permitir prioridades locales incluso si el manifiesto no enumera todavía el ZIP.
  const localDescriptor = actual.filter(id => id.toLowerCase().endsWith('.zip'))
    .map(id => ({path:'resourcepacks/', name:id.slice(5)}));
  const priority = priorityPackIds([...resourcepackFiles, ...localDescriptor], priorityPackNames)
    .filter(id => actualKeys.has(id.toLowerCase()));
  const priorityKeys = new Set(priority.map(id => id.toLowerCase()));

  const target = path.join(instanceRoot, 'options.txt');
  const previous = fs.existsSync(target) ? fs.readFileSync(target,'utf8') : '';
  if (Buffer.byteLength(previous,'utf8') > 1024*1024) throw new Error('options.txt demasiado grande.');
  const bom = previous.startsWith('\uFEFF') ? '\uFEFF' : '';
  const text = bom ? previous.slice(1) : previous;
  const nl = text.includes('\r\n') ? '\r\n' : '\n';
  const lines = text ? text.split(/\r?\n/).filter(Boolean) : ['version:3955'];
  const previouslyActive = jsonArrayFromOption(lines,'resourcePacks');

  // Al contrario de la versión anterior, NO se pierde el orden del modpack
  // después de activateResourcePacks(). El último pack tiene mayor prioridad.
  const masterOptionsFile = path.join(instanceRoot,'presets','options.txt');
  let officialOrder = [];
  try {
    const stat = fs.statSync(masterOptionsFile);
    if (stat.isFile() && stat.size < 1024*1024) {
      officialOrder = jsonArrayFromOption(fs.readFileSync(masterOptionsFile,'utf8').split(/\r?\n/),'resourcePacks')
        .filter(id => !PACK_ID.test(id) || actualKeys.has(id.toLowerCase()));
    }
  } catch (error) { if (error?.code !== 'ENOENT') throw error; }
  const officialKeys = new Set(officialOrder.map(id => id.toLowerCase()));
  const otherActive = previouslyActive.filter(id => !actualKeys.has(id.toLowerCase()) &&
    !officialKeys.has(id.toLowerCase()) && !priorityKeys.has(id.toLowerCase()));
  const localExtras = actual.filter(id => !officialKeys.has(id.toLowerCase()) && !priorityKeys.has(id.toLowerCase()));
  const regularOfficial = officialOrder.filter(id => !priorityKeys.has(id.toLowerCase()));
  const ordered = uniqueIds([...otherActive, ...localExtras, ...regularOfficial, ...priority]);
  setOption(lines, 'resourcePacks', JSON.stringify(ordered));
  const acknowledged = jsonArrayFromOption(lines,'incompatibleResourcePacks');
  setOption(lines, 'incompatibleResourcePacks', JSON.stringify(uniqueIds([...acknowledged, ...actual])));
  const after = bom + lines.join(nl) + nl;
  if (after !== previous) {
    fs.mkdirSync(instanceRoot,{recursive:true});
    // Respaldo una sola vez: el usuario puede restaurar su orden previo.
    const backup = path.join(instanceRoot,'options.txt.chilly-willy-before-rp-hotfix.bak');
    if (previous && !fs.existsSync(backup)) fs.copyFileSync(target,backup,fs.constants.COPYFILE_EXCL);
    const tmp = path.join(instanceRoot, `options.txt.chilly-all-${process.pid}.tmp`);
    try {fs.writeFileSync(tmp,after,{encoding:'utf8',flag:'wx'});fs.renameSync(tmp,target);}
    finally {try {fs.unlinkSync(tmp);}catch{}}
  }
  return {changed:after!==previous,enabledCount:actual.length,missing};
}
