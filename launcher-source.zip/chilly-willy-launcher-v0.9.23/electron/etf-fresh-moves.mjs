/** Migración puntual de ETF para corregir ojos negros con Fresh Moves.
 * No pisa opciones de Minecraft ni fuerza la preferencia en inicios posteriores.
 */
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const CONFIG='config/entity_texture_features.json';
const MARKER='config/chilly-willy/fresh-moves-etf-v0922.json';
const BACKUP='config/chilly-willy/backups/entity_texture_features.before-v0922.json';
const MAX_BYTES=1024*1024;

function checkSafe(root,relative){
  const rootPath=path.resolve(root);
  let current=rootPath;
  for(const part of relative.split('/')) {
    current=path.join(current,part);
    if(fs.existsSync(current) && fs.lstatSync(current).isSymbolicLink())
      throw new Error('La configuración ETF atraviesa un enlace simbólico.');
  }
  return current;
}
function writeAtomic(target,data){
  fs.mkdirSync(path.dirname(target),{recursive:true});
  const tmp=target+'.'+randomUUID()+'.tmp';
  try{fs.writeFileSync(tmp,data,{flag:'wx'});fs.renameSync(tmp,target);}
  finally{try{fs.unlinkSync(tmp);}catch{}}
}
export function applyFreshMovesEtfDefault(instanceRoot){
  if(typeof instanceRoot!=='string'||!path.isAbsolute(instanceRoot))throw new Error('Instancia de Minecraft inválida.');
  const marker=checkSafe(instanceRoot,MARKER);
  if(fs.existsSync(marker))return {status:'already-migrated'};
  const config=checkSafe(instanceRoot,CONFIG);
  if(!fs.existsSync(config)){
    const mods=checkSafe(instanceRoot,'mods');
    if(!fs.existsSync(mods)||!fs.statSync(mods).isDirectory() ||
       !fs.readdirSync(mods).some(name=>/^entity[_-]?texture[_-]?features.*\.jar$/i.test(name)))
      return {status:'etf-not-installed'};
  }
  const original=fs.existsSync(config)?fs.readFileSync(config):null;
  if(original && original.length>MAX_BYTES)throw new Error('El archivo ETF supera el tamaño esperado.');
  let options={};
  if(original){
    options=JSON.parse(original.toString('utf8'));
    if(!options||typeof options!=='object'||Array.isArray(options))throw new Error('Formato de configuración ETF inválido.');
  }
  const changed=options.skinTransparencyMode!=='ALL';
  if(changed){
    options.skinTransparencyMode='ALL';
    // Copia del archivo anterior antes de la migración; nunca sobrescribirla.
    if(original){
      const backup=checkSafe(instanceRoot,BACKUP);
      fs.mkdirSync(path.dirname(backup),{recursive:true});
      if(!fs.existsSync(backup))fs.writeFileSync(backup,original,{flag:'wx'});
    }
    writeAtomic(config,JSON.stringify(options,null,2)+'\n');
  }
  writeAtomic(marker,JSON.stringify({schema:1,skinTransparencyMode:'ALL',changed,appliedAt:new Date().toISOString()},null,2)+'\n');
  return {status:changed?'updated':'already-correct',changed};
}
