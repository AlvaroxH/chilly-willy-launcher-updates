/** Noticias públicas editables desde Google Sheets, consultadas por el proceso principal. */
import { existsSync,readFileSync,mkdirSync,writeFileSync,renameSync } from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const MAX_ITEMS=30;
const CACHE_MS=5*60_000;
const clean=(x,n)=>typeof x==='string'?x.trim().slice(0,n):'';
function httpsUrl(value){
  const s=clean(value,1024);if(!s)return '';
  try {const u=new URL(s);return u.protocol==='https:' && !u.username && !u.password ? u.toString():'';}catch{return '';}
}
function isoDate(value){
  if(!value)return '';
  if(typeof value!=='string'||!/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(value))return null;
  const ms=Date.parse(value);return Number.isFinite(ms)&&new Date(ms).toISOString()===value?value:null;
}
export function validateNewsFeed(raw,{now=Date.now()}={}) {
  if(raw?.error)throw new Error('La hoja de noticias del administrador no está configurada.');
  if(!raw||raw.version!==1||!Array.isArray(raw.news))throw new Error('Feed de noticias inválido. Actualizá Apps Script.');
  const news=[];
  for(const article of raw.news.slice(0,MAX_ITEMS)){
    if(!article||typeof article!=='object')continue;
    const title=clean(article.title,110),body=clean(article.body,900);
    if(!title||!body)continue;
    const publishAt=isoDate(article.publishAt),expiresAt=isoDate(article.expiresAt);
    if(publishAt===null||expiresAt===null)continue;
    if(publishAt&&Date.parse(publishAt)>now)continue;
    if(expiresAt&&Date.parse(expiresAt)<=now)continue;
    news.push({id:clean(article.id,60),title,body,
      category:clean(article.category,28)||'COMUNIDAD',date:clean(article.date,35),
      image:httpsUrl(article.image),link:httpsUrl(article.link),publishAt,expiresAt});
  }
  return news;
}
export function newsFeedUrl(manifestUrl) {
  const u=new URL(manifestUrl);
  if(u.protocol!=='https:' || u.hostname!=='script.google.com' || !u.pathname.endsWith('/exec'))throw new Error('URL de Apps Script inválida.');
  u.searchParams.set('feed','news');return u.toString();
}
export function readNewsCache(userData){
  try {const f=path.join(userData,'server-news.json');if(!existsSync(f))return null;
    const p=JSON.parse(readFileSync(f,'utf8'));
    return {news:validateNewsFeed(p),at:Number(p.at)||0};
  } catch{return null;}
}
export function writeNewsCache(userData,news){
  mkdirSync(userData,{recursive:true});const target=path.join(userData,'server-news.json');const tmp=path.join(userData,`.news-${randomUUID()}.tmp`);
  writeFileSync(tmp,JSON.stringify({version:1,news,at:Date.now()}));renameSync(tmp,target);
}
export async function loadServerNews(manifestUrl,userData,{request=fetch,force=false}={}){
  const cached=readNewsCache(userData);
  if(cached && !force && Date.now()-cached.at<CACHE_MS)return {news:cached.news,source:'cache'};
  try {
    const u=new URL(newsFeedUrl(manifestUrl));
    // Evita que Google/proxies devuelvan una respuesta anterior al publicar una noticia.
    u.searchParams.set('_',String(Date.now()));
    const response=await request(u.toString(),{signal:AbortSignal.timeout(14000),headers:{Accept:'application/json','Cache-Control':'no-cache'},cache:'no-store'});
    if(!response.ok)throw new Error(`HTTP ${response.status}`);
    const size=Number(response.headers.get('content-length')||0);
    if(size>100_000)throw new Error('Noticias demasiado grandes.');
    const body=await response.text();if(body.length>100_000)throw new Error('Noticias demasiado grandes.');
    const news=validateNewsFeed(JSON.parse(body));
    writeNewsCache(userData,news);return {news,source:'online'};
  }catch(error){
    return {news:cached?.news||[],source:cached?'offline':'unavailable',error:'No se pudieron cargar las noticias del servidor. Revisá la hoja y la nueva implementación de Apps Script.'};
  }
}
