/** Historial privado de skins por cuenta. Solo PNG, sin tokens ni datos de otra cuenta. */
import path from 'node:path';
import { createHash, randomUUID } from 'node:crypto';
import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync, readdirSync, unlinkSync } from 'node:fs';
import { validateSkinPng } from './premium-skins.mjs';

const MAX_HISTORY = 24;
const KEY_PATTERN = /^[a-z0-9_:-]{3,100}$/i;
const SAFE_ID = /^[a-f0-9]{64}$/;
const hash = value => createHash('sha256').update(value).digest('hex');
export function historyDir(userData, accountKey) {
  if (!KEY_PATTERN.test(accountKey)) throw new Error('Cuenta Microsoft inválida para historial.');
  return path.join(userData, 'skin-history', hash(accountKey.toLowerCase()));
}
function readIndex(dir) {
  try {
    const items = JSON.parse(readFileSync(path.join(dir,'index.json'), 'utf8'));
    if (!Array.isArray(items)) return [];
    return items.filter(item => item && SAFE_ID.test(item.id) && ['classic','slim'].includes(item.variant) && typeof item.name === 'string' && item.name.length <= 110 && Number.isFinite(item.when)).slice(0,MAX_HISTORY);
  } catch { return []; }
}
function saveIndex(dir,items) {
  const tmp=path.join(dir, `.${randomUUID()}.tmp`);
  try { writeFileSync(tmp,JSON.stringify(items,null,2),'utf8');renameSync(tmp,path.join(dir,'index.json')); }
  finally { if(existsSync(tmp)) unlinkSync(tmp); }
}
export function listSkinHistory(userData,accountKey) {
  const dir=historyDir(userData,accountKey);
  return readIndex(dir).filter(item=>existsSync(path.join(dir,item.id+'.png')));
}
export function saveSkinHistory(userData,accountKey,bytes,{variant,name}) {
  validateSkinPng(bytes);
  if (!['classic','slim'].includes(variant)) throw new Error('Modelo inválido');
  const dir=historyDir(userData,accountKey);
  mkdirSync(dir,{recursive:true,mode:0o700});
  const id=hash(bytes);
  const old=readIndex(dir);
  const existing=old.find(item=>item.id===id);
  const item={id,variant,name:String(name||'Skin').slice(0,100),when:Date.now()};
  if(!existing) writeFileSync(path.join(dir,id+'.png'),bytes,{flag:'wx',mode:0o600});
  const next=[item,...old.filter(entry=>entry.id!==id)];
  saveIndex(dir,next.slice(0,MAX_HISTORY));
  for(const gone of next.slice(MAX_HISTORY)) {
    try {unlinkSync(path.join(dir,gone.id+'.png'));}catch{}
  }
  return item;
}
export function readHistoricalSkin(userData,accountKey,id) {
  if (typeof id !== 'string' || !SAFE_ID.test(id)) throw new Error('Identificador de skin inválido.');
  const entry=listSkinHistory(userData,accountKey).find(item=>item.id===id);
  if (!entry) throw new Error('No se encontró esta skin en el historial de la cuenta.');
  const bytes=readFileSync(path.join(historyDir(userData,accountKey),id+'.png'));
  validateSkinPng(bytes);
  if (hash(bytes)!==id) throw new Error('Skin histórica dañada.');
  return {entry,bytes};
}
/** Respaldar la skin actualmente pública del perfil, cuando esté disponible. */
export async function snapshotCurrentSkin(userData,accountKey,uuid,{request=fetch}={}) {
  const id=typeof uuid==='string'?uuid.replaceAll('-',''):'';
  if(!/^[0-9a-f]{32}$/i.test(id))return false;
  try {
    const profile=await request(`https://sessionserver.mojang.com/session/minecraft/profile/${id}`,{signal:AbortSignal.timeout(4500)});
    if(!profile.ok) return false;
    const body=await profile.json();
    const prop=body?.properties?.find(x=>x.name==='textures')?.value;
    if(typeof prop!=='string' || prop.length>50000)return false;
    const decoded=JSON.parse(Buffer.from(prop,'base64').toString('utf8'));
    const skin=decoded?.textures?.SKIN;
    if(!skin?.url)return false;
    const url=new URL(skin.url);
    if(url.hostname!=='textures.minecraft.net' || !/^\/texture\/[a-f0-9]{32,128}$/i.test(url.pathname))return false;
    url.protocol='https:';
    const response=await request(url.toString(),{signal:AbortSignal.timeout(4500)});
    if(!response.ok || Number(response.headers.get('content-length')||0)>2*1024*1024)return false;
    const bytes=Buffer.from(await response.arrayBuffer());
    saveSkinHistory(userData,accountKey,bytes,{variant:skin.metadata?.model==='slim'?'slim':'classic',name:'Skin anterior de Minecraft'});
    return true;
  } catch{return false;}
}
