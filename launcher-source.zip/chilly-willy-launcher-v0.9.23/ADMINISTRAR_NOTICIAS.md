# Noticias de Chilly Willy — publicá cuando quieras, sin actualizar el launcher

## Preparar el sistema (una sola vez)

1. Abrí tu carpeta **maestra** de Google Drive, donde tenés el modpack.
2. Creá una Hoja de cálculo de Google llamada exactamente **Chilly-Willy-Noticias**, con una pestaña llamada **Noticias**.
3. En la fila 1 escribí los encabezados de las columnas A-I indicadas en la tabla de abajo. También podés importar `PLANTILLA_NOTICIAS.csv` (sus ejemplos vienen como borradores).
4. En tu Apps Script **público** actual del modpack, reemplazá el código por `APPS_SCRIPT_ACTUALIZADO/Code.gs`. Implementar → Administrar implementaciones → Editar → Nueva versión. **Conservá la URL `/exec` que usa el launcher.** Google podría solicitarte permisos para leer la hoja.
5. Probá en un navegador `TU_URL_ACTUAL_DE_APPS_SCRIPT/exec?feed=news`. Debe devolver JSON con `"version":1,"news":[]` (o tus noticias).

| Columna | Nombre | Qué significa |
|---|---|---|
| A | Publicar | `SI` para visible, `NO` para borrador |
| B | Fecha | Texto mostrado al jugador, por ejemplo `02/11/2026` |
| C | Categoría | TORNEO, SERVIDOR, EVENTO, etc. |
| D | Título | Máx. 110 caracteres |
| E | Texto | Máx. 900 caracteres |
| F | Imagen URL | URL **HTTPS pública y directa** de imagen, opcional |
| G | Enlace URL | URL HTTPS de Discord, reglas, evento, etc., opcional |
| H | Publicar desde | `AAAA-MM-DD HH:MM`, opcional |
| I | Publicar hasta | `AAAA-MM-DD HH:MM`, opcional |

Las fechas de H-I están expresadas en **hora argentina UTC−03:00**. Usá formato **texto sin reinterpretación de fechas**; por ejemplo `2026-11-03 18:00`. Si H queda vacío, la noticia puede publicarse inmediatamente al poner `SI`. Si I está vacío, no expira. Si ambas fechas están presentes, el fin debe ser posterior al inicio. Filas con formato de fecha inválido no se publican.

## Panel de administración con botones (recomendado)

Para no editar celdas directamente, instalá `ADMIN_PANEL_NOTICIAS_GOOGLE_SHEETS/Code.gs` y `Sidebar.html` **en un proyecto de Apps Script vinculado a la hoja** siguiendo `ADMIN_PANEL_NOTICIAS_GOOGLE_SHEETS/LEER_PRIMERO.md`.

Luego abrí la hoja en el navegador y elegí **Chilly Willy → Administrar noticias**. El panel permite crear, editar, eliminar, poner en borrador y programar noticias. **No es un panel público**: solo funciona para los editores de la hoja, con los permisos de Google. Este script es distinto del Apps Script público de Drive, **no mezcles sus archivos**.

## Cuándo se ven las noticias

- El launcher las consulta **al abrirse** y **cada 2 minutos mientras esté visible**.
- El botón **Actualizar noticias** pide una consulta nueva sin esperar el intervalo.
- Si el launcher estaba oculto, comprueba las novedades al volver a mostrarse, si ya venció el intervalo.
- Al estar sin conexión, muestra la última copia local disponible; las noticias caducadas se ocultan también en la copia local.
- Las nuevas publicaciones pueden tardar unos minutos en aparecer según la conexión y la disponibilidad de Google Apps Script. No hace falta actualizar el ejecutable ni los ZIP del modpack por cada noticia.
- El Apps Script público solo permite **leer** las filas con `SI` y dentro del horario. No ofrece operaciones de edición.

## Privacidad

Compartí únicamente el acceso de lectura a las noticias mediante Apps Script. **No compartas edición de la hoja ni del script de administración con jugadores.** No incluyas credenciales ni datos privados en el contenido publicado.
