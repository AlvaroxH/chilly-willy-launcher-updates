import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import { applyFreshMovesEtfDefault } from '../electron/etf-fresh-moves.mjs';
import {validateNewsFeed,loadServerNews} from '../electron/server-news.mjs';
const root=t=>{const p=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-0922-news-etf-'));t.after(()=>fs.rmSync(p,{force:true,recursive:true}));return p;};
test('ETF se configura una única vez sin borrar preferencias y respeta cambios posteriores',t=>{
  const p=root(t),cfg=path.join(p,'config','entity_texture_features.json');
  fs.mkdirSync(path.dirname(cfg),{recursive:true});
  fs.writeFileSync(cfg,JSON.stringify({skinTransparencyMode:'ETF_SKINS_ONLY',enableBlinking:false,debugLoggingMode:'None'}));
  assert.equal(applyFreshMovesEtfDefault(p).status,'updated');
  let options=JSON.parse(fs.readFileSync(cfg,'utf8'));
  assert.equal(options.skinTransparencyMode,'ALL');assert.equal(options.enableBlinking,false);
  const backup=path.join(p,'config/chilly-willy/backups/entity_texture_features.before-v0922.json');
  assert.equal(JSON.parse(fs.readFileSync(backup,'utf8')).skinTransparencyMode,'ETF_SKINS_ONLY');
  options.skinTransparencyMode='ETF_SKINS_ONLY';fs.writeFileSync(cfg,JSON.stringify(options));
  assert.equal(applyFreshMovesEtfDefault(p).status,'already-migrated');
  assert.equal(JSON.parse(fs.readFileSync(cfg,'utf8')).skinTransparencyMode,'ETF_SKINS_ONLY');
});
test('ETF crea defaults si está instalado y no crea archivos si no existe',t=>{
  const p=root(t);assert.equal(applyFreshMovesEtfDefault(p).status,'etf-not-installed');
  fs.mkdirSync(path.join(p,'mods'));fs.writeFileSync(path.join(p,'mods','entity_texture_features-fabric-1.21.1.jar'),'test');
  assert.equal(applyFreshMovesEtfDefault(p).status,'updated');
  assert.equal(JSON.parse(fs.readFileSync(path.join(p,'config/entity_texture_features.json'),'utf8')).skinTransparencyMode,'ALL');
});
test('ETF no sobrescribe un JSON inválido ni cruza enlaces simbólicos',t=>{
  const p=root(t),cfg=path.join(p,'config/entity_texture_features.json');fs.mkdirSync(path.dirname(cfg));fs.writeFileSync(cfg,'not-json');
  assert.throws(()=>applyFreshMovesEtfDefault(p));assert.equal(fs.readFileSync(cfg,'utf8'),'not-json');
  fs.rmSync(cfg);const outside=path.join(root(t),'other');fs.writeFileSync(outside,'{}');
  fs.symlinkSync(outside,cfg);assert.throws(()=>applyFreshMovesEtfDefault(p),/enlace simbólico/);
});
test('caché de noticias no muestra avisos vencidos ni futuros',async t=>{
 const p=root(t),now=Date.now(),toIso=ms=>new Date(ms).toISOString();
 const feed={version:1,news:[
  {title:'Futura',body:'Oculta',publishAt:toIso(now+3600e3)},
  {title:'Vencida',body:'Oculta',expiresAt:toIso(now-3600e3)},
  {title:'Activa',body:'Visible',publishAt:toIso(now-3600e3),expiresAt:toIso(now+3600e3)}]};
 assert.deepEqual(validateNewsFeed(feed,{now}).map(x=>x.title),['Activa']);
 let requested='';const request=async(url,opts)=>{requested=url;assert.equal(opts.cache,'no-store');return new Response(JSON.stringify(feed));};
 const result=await loadServerNews('https://script.google.com/macros/s/ABC/exec',p,{request,force:true});
 assert.equal(result.source,'online');assert.deepEqual(result.news.map(x=>x.title),['Activa']);
 assert.match(requested,/feed=news/);assert.match(requested,/_=/);
});
test('Apps Script filtra publicaciones por horario Argentina',()=>{
  const code=fs.readFileSync(new URL('../apps-script/Code.gs',import.meta.url),'utf8');
  const context={};vm.createContext(context);vm.runInContext(code,context);
  const date=context.parseNewsDate_('2026-11-02 18:30');
  assert.equal(date.ok,true);assert.equal(date.iso,'2026-11-02T21:30:00.000Z');
  assert.equal(context.parseNewsDate_('2026-02-30 18:30').ok,false);
  const sheet={getLastRow:()=>3,getRange:()=>({getDisplayValues:()=>[
    ['SI','02/11/2026','TORNEO','Abierto','Participá','','','2020-01-01 01:00',''],
    ['SI','03/11/2026','TORNEO','Programado','Todavía no','','','2099-01-01 01:00','']
  ]})};
  context.DriveApp={getFolderById:()=>({getFilesByName:()=>({hasNext:()=>true,next:()=>({getMimeType:()=> 'application/vnd.google-apps.spreadsheet',getId:()=> 'id'})})})};
  context.SpreadsheetApp={openById:()=>({getSheetByName:()=>sheet})};
  const output=context.publicNews();assert.equal(output.news.length,1);assert.equal(output.news[0].title,'Abierto');
});
test('UI recarga mientras está visible y Apps Script incluye programación',()=>{
 const ui=fs.readFileSync(new URL('../ui/app.js',import.meta.url),'utf8');
 const script=fs.readFileSync(new URL('../apps-script/Code.gs',import.meta.url),'utf8');
 const main=fs.readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
 assert.match(ui,/NEWS_POLL_MS = 120_000/);assert.match(ui,/visibilitychange/);
 assert.match(script,/parseNewsDate_/);assert.match(script,/getRange\(2,1,last-1,9\)/);
 assert.equal(main.includes('applyFreshMovesEtfDefault(launcher.config.root)'),true);
});
