import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {listSkinHistory,saveSkinHistory,readHistoricalSkin,snapshotCurrentSkin,historyDir} from '../electron/skin-history.mjs';
import {validateNewsFeed,newsFeedUrl,loadServerNews} from '../electron/server-news.mjs';

const png=()=>{const b=Buffer.alloc(80);Buffer.from([137,80,78,71,13,10,26,10]).copy(b);b.write('IHDR',12);b.writeUInt32BE(64,16);b.writeUInt32BE(64,20);return b;};
function directory(t){const dir=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-v22-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));return dir;}
test('historial guarda PNG por cuenta, permite recuperación y rechaza rutas maliciosas',t=>{
 const dir=directory(t),bytes=png();
 const first=saveSkinHistory(dir,'JugadorPremium',bytes,{variant:'slim',name:'Halloween'});
 assert.equal(first.name,'Halloween');assert.equal(listSkinHistory(dir,'JugadorPremium').length,1);
 assert.equal(listSkinHistory(dir,'OtraCuenta').length,0);
 assert.deepEqual(readHistoricalSkin(dir,'JugadorPremium',first.id).bytes,bytes);
 assert.throws(()=>readHistoricalSkin(dir,'JugadorPremium','../index.json'),/inválido/);
 assert.throws(()=>historyDir(dir,'../../x'),/inválida/);
 const changed=Buffer.from(bytes);changed[40]=1;
 saveSkinHistory(dir,'JugadorPremium',changed,{variant:'classic',name:'Nueva'});
 assert.equal(listSkinHistory(dir,'JugadorPremium').length,2);
 saveSkinHistory(dir,'JugadorPremium',bytes,{variant:'classic',name:'Otra vez'});
 assert.equal(listSkinHistory(dir,'JugadorPremium')[0].name,'Otra vez');
 assert.equal(listSkinHistory(dir,'JugadorPremium').length,2);
});
test('respaldo intenta recuperar skin anterior pública de Minecraft en dominio permitido',async t=>{
 const dir=directory(t);const bytes=png();
 const skinUrl='http://textures.minecraft.net/texture/'+'a'.repeat(64);
 const textures=Buffer.from(JSON.stringify({textures:{SKIN:{url:skinUrl,metadata:{model:'slim'}}}})).toString('base64');
 const calls=[];
 const request=async url=>{
  calls.push(url);
  if(url.includes('sessionserver'))return new Response(JSON.stringify({properties:[{name:'textures',value:textures}]}),{status:200});
  return new Response(bytes,{status:200,headers:{'content-type':'image/png'}});
 };
 assert.equal(await snapshotCurrentSkin(dir,'Jugador','a'.repeat(32),{request}),true);
 assert.equal(listSkinHistory(dir,'Jugador')[0].variant,'slim');
 assert.ok(calls[1].startsWith('https://textures.minecraft.net/'));
});
test('respaldo rechaza URL de texturas no confiable sin consultar el sitio',async t=>{
 const dir=directory(t);let hits=0;
 const textures=Buffer.from(JSON.stringify({textures:{SKIN:{url:'https://internal.local/secret'}}})).toString('base64');
 const request=async()=>{hits++;return new Response(JSON.stringify({properties:[{name:'textures',value:textures}]}));};
 assert.equal(await snapshotCurrentSkin(dir,'Jugador','a'.repeat(32),{request}),false);
 assert.equal(hits,1);
});
test('feed remoto valida estructura, HTTPS, longitud y evita campos extraños',()=>{
 const result=validateNewsFeed({version:1,news:[{title:'Evento',body:'¡Torneo!',category:'COMUNIDAD',image:'javascript:alert(1)',link:'https://example.com/evento',extra:'secreto'}]});
 assert.equal(result.length,1);assert.equal(result[0].image,'');assert.equal(result[0].link,'https://example.com/evento');
 assert.equal(Object.hasOwn(result[0],'extra'),false);
 assert.throws(()=>validateNewsFeed({version:2,news:[]}),/inválido/);
 assert.match(newsFeedUrl('https://script.google.com/macros/s/xyz/exec'),/feed=news/);
 assert.throws(()=>newsFeedUrl('https://evil.example/exec'),/inválida/);
});
test('noticias persisten y se pueden consultar offline sin bloquear el launcher',async t=>{
 const dir=directory(t);const url='https://script.google.com/macros/s/xyz/exec';
 const request=async()=>new Response(JSON.stringify({version:1,news:[{id:'1',title:'Nuevo torneo',body:'Sábado 19hs',date:'2026-11-03'}]}));
 const first=await loadServerNews(url,dir,{request,force:true});
 assert.equal(first.source,'online');assert.equal(first.news[0].title,'Nuevo torneo');
 const offline=await loadServerNews(url,dir,{request:async()=>{throw Error('sin internet');},force:true});
 assert.equal(offline.source,'offline');assert.equal(offline.news.length,1);
});
test('hay dos modelos comparables, cancelación y noticias dinámicas en la interfaz',()=>{
 const ui=fs.readFileSync(new URL('../ui/index.html',import.meta.url),'utf8');
 const code=fs.readFileSync(new URL('../ui/app.js',import.meta.url),'utf8');
 const preview=fs.readFileSync(new URL('../ui/skin-preview.js',import.meta.url),'utf8');
 const main=fs.readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
 const appsScript=fs.readFileSync(new URL('../apps-script/Code.gs',import.meta.url),'utf8');
 for(const id of ['skinCanvas-classic','skinCanvas-slim','applySkinBtn','cancelSkinBtn','skinHistoryList','serverNewsList','refreshNewsBtn'])assert.ok(ui.includes(id));
 assert.match(preview,/old=img\.naturalHeight===32/);
 for(const name of ['chooseSkinPreview','applySkinPreview','skinHistory','previewHistoricalSkin','cancelSkinPreview','serverNews'])assert.ok(code.includes(name));
 assert.match(main,/snapshotCurrentSkin/);assert.match(main,/session\?\.type!==\x27microsoft\x27/);
 assert.match(appsScript,/getFilesByName\(NEWS_SHEET_FILENAME\)/);
 assert.match(appsScript,/getDisplayValues\(\)/);
 assert.match(appsScript,/feed==='news'/);
});
