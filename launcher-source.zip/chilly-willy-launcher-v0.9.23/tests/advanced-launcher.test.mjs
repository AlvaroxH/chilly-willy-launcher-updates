import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {readPreferences,savePreferences} from '../electron/profile-store.mjs';
import {validateSkinPng,uploadPremiumSkin} from '../electron/premium-skins.mjs';

test('configuraciones nuevas persisten y validan tipos sin guardar tokens',t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-pref-new-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 savePreferences(dir,{startWithWindows:true,afterLaunch:'tray'});
 savePreferences(dir,{memoryMb:6144});
 assert.deepEqual(readPreferences(dir),{memoryMb:6144,startWithWindows:true,afterLaunch:'tray'});
 for(const value of ['disable','close',false])assert.throws(()=>savePreferences(dir,{afterLaunch:value}));
 assert.throws(()=>savePreferences(dir,{startWithWindows:'true'}));
 const text=fs.readFileSync(path.join(dir,'preferences.json'),'utf8');
 assert.doesNotMatch(text,/access_token|password/);
});
function validPng(){const b=Buffer.alloc(60);Buffer.from([137,80,78,71,13,10,26,10]).copy(b,0);b.writeUInt32BE(13,8);b.write('IHDR',12);b.writeUInt32BE(64,16);b.writeUInt32BE(64,20);return b;}
test('PNG válido, dimensiones y token premium limitados',()=>{
 const png=validPng();assert.deepEqual(validateSkinPng(png),{width:64,height:64});
 assert.throws(()=>validateSkinPng(Buffer.from('notpng')),/PNG/);
 png.writeUInt32BE(512,16);assert.throws(()=>validateSkinPng(png),/64×64/);

});
test('skin oficial se aplica con EML Skin solo a la cuenta activa (sin pasar tokens al frontend)',async t=>{
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-skin-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 const filePath=path.join(dir,'skin.png');fs.writeFileSync(filePath,validPng());
 const account={type:'microsoft',name:'Jugador_123'};
 const calls=[];
 class SkinMock{constructor(s){calls.push({account:s})} async updateSkin(blob,variant){calls.push({blob,variant})}}
 const result=await uploadPremiumSkin({account,filePath,variant:'slim',SkinClass:SkinMock});
 assert.equal(result.ok,true);
 assert.equal(calls[0].account,account);
 assert.equal(calls[1].variant,'slim');
 assert.equal(calls[1].blob.type,'image/png');
 assert.equal(calls[1].blob.size,validPng().length);
 await assert.rejects(()=>uploadPremiumSkin({account:null,filePath,variant:'slim',SkinClass:SkinMock}),/Microsoft/);
 assert.equal(calls.length,2);
});
test('UI tiene opciones reales y el preload usa IPC sin pasar tokens',()=>{
 const html=fs.readFileSync(new URL('../ui/index.html',import.meta.url),'utf8');
 const app=fs.readFileSync(new URL('../ui/app.js',import.meta.url),'utf8');
 const preload=fs.readFileSync(new URL('../electron/preload.cjs',import.meta.url),'utf8');
 for(const id of ['startWithWindowsToggle','afterLaunchSelect','changeSkinBtn','openGameFolderBtn','skinVariant'])assert.ok(html.includes(`id="${id}"`));
 for(const api of ['setStartWithWindows','setAfterLaunch','chooseSkinPreview','applySkinPreview','skinHistory','openGameFolder']) {assert.ok(preload.includes(api));assert.ok(app.includes(api));}
 assert.ok(!preload.includes('accessToken'));
});
