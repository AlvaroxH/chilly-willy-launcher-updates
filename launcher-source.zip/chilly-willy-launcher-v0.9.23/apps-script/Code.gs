/**
 * CHILLY WILLY LAUNCHER v0.9.22 — publicación SEGURA de una instalación maestra.
 * Carpeta: https://drive.google.com/drive/folders/1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM
 * AVISO: distribuye SOLO categorías explícitas. NO publica saves, logs, screenshots,
 * historial de comandos, cachés, waypoints/Xaero, Pokémon del jugador,
 * logros, progreso, datos de servidor personales ni credenciales.
 * Para publicar: Implementar > Administrar implementaciones > Editar > Nueva versión.
 * El modpack instalado se administra por EML; este script solo devuelve metadatos.
 */
const MASTER_FOLDER_ID = '1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM';
const INCLUDED_FOLDERS = new Set([
  'mods', 'config', 'resourcepacks', 'shaderpacks', 'datapacks',
  'defaultconfigs', 'cobblemon', 'data'
]);
const OMIT_MODS = new Set(['NoChatRestrictions-Fabric-MC1.21.11-v1.0.0.jar']);
const ALLOWED_ROOT_FILES = new Set(['options.txt', 'icon.png']);
const MAX_FILES = 10000;
const MAX_BYTES_JSON = 1900000;
function safeName(name) {
  return typeof name === 'string' && name.length > 0 && name.length < 230 &&
    name !== '.' && name !== '..' && !/[\\/:*?"<>|\x00-\x1F]/.test(name) &&
    !/[. ]$/.test(name) && !/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$/i.test(name);
}
function ignore(category, name, rel) {
  const lower = name.toLowerCase();
  if (!safeName(name) || name.startsWith('.') || name.endsWith('~')) return true;
  if (category === 'mods') return !lower.endsWith('.jar') || OMIT_MODS.has(name);
  // Resource packs: no filtrar ZIP por nombres 'DO NOT ENABLE' o Xray.
  // Se conserva la protección de rutas y datos privados que sigue abajo.
  // Nunca distribuir datos de identidad, progreso, favoritos individuales o cachés.
  if (/^(?:username-cache\.json|servers\.dat(?:_old)?|.*\.(?:pem|key|p12)|credentials?\..*|tokens?\..*)$/i.test(name)) return true;
  if (/(?:^|\/)(?:waypoints?|advancements?|playerdata|stats|world-map-cache|map-data|cache|visited|explored|saves)(?:\/|$)/i.test(rel)) return true;
  if (category === 'config' && (rel.startsWith('config/chilly-willy/') ||
      /^(server\.properties|ops\.json|whitelist\.json|eula\.txt|banned-.*\.json|\.env.*|.*\.(?:pem|key|p12))$/i.test(name))) return true;
  // data/ del cliente únicamente tiene los recursos predeterminados de Fabric
  if (category === 'data') return rel !== 'data/' || name !== 'fabricDefaultResourcePacks.dat';
  return false;
}
function appendFile(file, prefix, category, output) {
  const name = file.getName();
  if (ignore(category,name,prefix)) return;
  if (file.getMimeType().startsWith('application/vnd.google-apps.')) return;
  const size = Number(file.getSize());
  if (!Number.isSafeInteger(size) || size < 0 || size > 1000000000) return;
  output.push({name, path:prefix, size,
    type:category === 'mods' ? 'MOD' : 'OTHER', updated:file.getLastUpdated().getTime(),
    url:'https://drive.usercontent.google.com/download?id='+encodeURIComponent(file.getId())+'&export=download&confirm=t'
  });
  if (output.length > MAX_FILES) throw Error('Demasiados archivos: comprimí los shaderpacks en ZIP');
}
function walk(folder, prefix, category, output, depth) {
  if (depth > 12) throw Error('Demasiada profundidad: '+prefix);
  const files = folder.getFiles();
  while(files.hasNext()) appendFile(files.next(), prefix, category, output);
  const dirs = folder.getFolders();
  while(dirs.hasNext()) {
    const folder = dirs.next(); const name = folder.getName();
    if (safeName(name) && !name.startsWith('.')) walk(folder,prefix+name+'/',category,output,depth+1);
  }
}
// Hoja privada del administrador en la carpeta maestra de Drive. Quien tenga
// acceso público al Apps Script solo lee noticias publicadas; NUNCA puede editar.
const NEWS_SHEET_FILENAME = 'Chilly-Willy-Noticias';
const NEWS_TAB_NAME = 'Noticias';
function sanitizeNewsField(value,max) {
  return String(value == null ? '' : value).trim().slice(0,max);
}
function newsUrl(value) {
  const s=sanitizeNewsField(value,1024);
  return /^https:\/\/[^\s@]+$/i.test(s) ? s : '';
}
// Zona horaria del servidor: Argentina (UTC-03:00, sin horario de verano).
// Acepta AAAA-MM-DD HH:MM; las celdas de programación vacías no restringen.
function parseNewsDate_(value) {
  const text=String(value==null?'':value).trim();
  if(!text)return {ok:true,ms:null,iso:''};
  const match=/^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2})$/.exec(text);
  if(!match)return {ok:false};
  const [year,month,day,hour,minute]=match.slice(1).map(Number);
  if(year<2020||year>2100||month<1||month>12||day<1||day>31||hour>23||minute>59)return {ok:false};
  const check=new Date(Date.UTC(year,month-1,day));
  if(check.getUTCFullYear()!==year||check.getUTCMonth()!==month-1||check.getUTCDate()!==day)return {ok:false};
  const ms=Date.UTC(year,month-1,day,hour+3,minute);
  return {ok:true,ms,iso:new Date(ms).toISOString()};
}
function publicNews() {
  const folder=DriveApp.getFolderById(MASTER_FOLDER_ID);
  const sheets=folder.getFilesByName(NEWS_SHEET_FILENAME);
  if(!sheets.hasNext()) return {version:1,news:[]};
  const f=sheets.next();
  if(f.getMimeType()!=='application/vnd.google-apps.spreadsheet')
    throw Error('El archivo Chilly-Willy-Noticias debe ser una Hoja de cálculo de Google');
  const tab=SpreadsheetApp.openById(f.getId()).getSheetByName(NEWS_TAB_NAME);
  if(!tab) throw Error('Falta pestaña Noticias en la hoja de Google');
  const last=Math.min(tab.getLastRow(),201);
  if(last<2)return {version:1,news:[]};
  // A-G columnas originales; H: desde e I: hasta (hora de Argentina).
  const data=tab.getRange(2,1,last-1,9).getDisplayValues();
  const now=Date.now();
  const items=[];
  for(let i=0;i<data.length;i++) {
    const [published,date,category,title,body,image,link,fromText,toText]=data[i];
    if(!/^(si|sí|true|1|publicado)$/i.test(String(published).trim()))continue;
    if(!String(title).trim()||!String(body).trim())continue;
    const from=parseNewsDate_(fromText),until=parseNewsDate_(toText);
    // No publicar una noticia si las fechas son incorrectas o el rango está invertido.
    if(!from.ok||!until.ok||
       (from.ms!==null&&until.ms!==null&&from.ms>=until.ms)||
       (from.ms!==null&&now<from.ms)||(until.ms!==null&&now>=until.ms))continue;
    items.push({publishAt:from.iso,expiresAt:until.iso,id:'noticia-'+(i+2),date:sanitizeNewsField(date,35),
      category:sanitizeNewsField(category,28)||'COMUNIDAD',
      title:sanitizeNewsField(title,110),body:sanitizeNewsField(body,900),
      image:newsUrl(image),link:newsUrl(link)});
    if(items.length>=30)break;
  }
  return {version:1,news:items};
}
function jsonResult(body){
  return ContentService.createTextOutput(JSON.stringify(body)).setMimeType(ContentService.MimeType.JSON);
}
function doGet(e) {
  if(e && e.parameter && e.parameter.feed==='news') {
    try{return jsonResult(publicNews());}
    catch(error){return jsonResult({version:1,news:[],error:'No se pudieron leer noticias. Revisá la hoja de administración.'});}
  }
  try {
    const root = DriveApp.getFolderById(MASTER_FOLDER_ID), output=[];
    const sectionsSeen = new Set();
    const folders = root.getFolders();
    while(folders.hasNext()) {
      const folder=folders.next(), name=folder.getName();
      if (!INCLUDED_FOLDERS.has(name)) continue;
      if (sectionsSeen.has(name)) throw Error('Carpeta de modpack repetida: '+name);
      sectionsSeen.add(name);
      walk(folder,name+'/',name,output,0);
    }
    for(const required of ['mods','config','resourcepacks','shaderpacks'])
      if (!sectionsSeen.has(required)) throw Error('Falta carpeta maestra '+required);
    const rootFiles=root.getFiles(); let hasOptions=false;
    while(rootFiles.hasNext()) {
      const file=rootFiles.next();
      if (ALLOWED_ROOT_FILES.has(file.getName())) {
        appendFile(file,'presets/','presets',output);
        if (file.getName()==='options.txt') hasOptions=true;
      }
    }
    if (!hasOptions) throw Error('Falta options.txt en la raíz maestra');
    output.sort((a,b)=>(a.path+a.name).localeCompare(b.path+b.name));
    const payload=JSON.stringify({version:6,source:'cobbleverse-master',files:output});
    if (payload.length>MAX_BYTES_JSON) throw Error('Manifiesto demasiado grande para Apps Script. Comprimí shaderpacks en ZIP individuales.');
    return ContentService.createTextOutput(payload).setMimeType(ContentService.MimeType.JSON);
  } catch(error) {
    return ContentService.createTextOutput(JSON.stringify({error:'Error de manifiesto Cobbleverse',detail:String(error)})).setMimeType(ContentService.MimeType.JSON);
  }
}
