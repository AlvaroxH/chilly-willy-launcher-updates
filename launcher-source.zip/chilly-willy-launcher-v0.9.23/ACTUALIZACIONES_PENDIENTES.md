# Hoja de ruta Chilly Willy — 2026-11-02

**Incluido en esta revisión de v0.9.22 (código, falta probar en Windows):** Estudio de skins Steve/Alex con vista previa, aplicar/cancelar e historial, noticias del administrador editables sin nuevas releases, publicación programada, sondeo cada 2 minutos, botón de actualización, panel privado en Google Sheets y migración automática ETF `skinTransparencyMode: ALL` para Fresh Moves.

**Aún requiere instalación:** redeplegar el Apps Script público y crear la Hoja `Chilly-Willy-Noticias`. El panel opcional usa un Apps Script privado y vinculado a esa hoja. Hace falta compilar en GitHub Actions, probar con Minecraft y publicar la actualización.

**Pendiente futuro:** editor completo Launcher Studio (mover/crear/eliminar botones, acciones personalizadas, fondos y tarjetas). Trabajo independiente del launcher de jugadores.
