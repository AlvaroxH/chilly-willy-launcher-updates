/* Vista de la textura real de Minecraft en cuerpo Steve y Alex (frente/espalda).
 * Canvas local: la imagen NO se envía a ningún servicio hasta que el usuario aplique.
 */
(function(){
  const cache=new WeakMap();
  function drawBody(canvas,img,variant,side='front') {
    const out=canvas.getContext('2d');
    canvas.width=16;canvas.height=32;out.imageSmoothingEnabled=false;out.clearRect(0,0,16,32);
    if(!img)return;
    const old=img.naturalHeight===32;
    const slim=variant==='slim',w=slim?3:4, back=side==='back';
    const mirror=(sx,sy,sw,sh,dx,dy,dw,dh)=>{
      out.save();out.translate(dx+dw,dy);out.scale(-1,1);
      out.drawImage(img,sx,sy,sw,sh,0,0,dw,dh);out.restore();
    };
    const draw=(sx,sy,sw,sh,dx,dy,dw=sw,dh=sh)=>out.drawImage(img,sx,sy,sw,sh,dx,dy,dw,dh);
    // Piernas: en formato 64x32 no existe pierna izquierda individual.
    if(old)mirror(back?12:4,20,4,12,8,20,4,12);
    else draw(back?28:20,52,4,12,8,20);
    draw(back?12:4,20,4,12,4,20);
    if(!old){
      draw(back?12:4,36,4,12,4,20);
      draw(back?28:20,36,4,12,8,20);
    }
    // Brazos. Ajuste de 3 px para Alex y 4 px para Steve.
    if(old)mirror(back?52:44,20,4,12,12,8,w,12);
    else draw(back?(slim?43:44):36,52,w,12,12,8);
    draw(back?(slim?51:52):44,20,w,12,4-w,8);
    // Tronco y segunda capa.
    draw(back?32:20,20,8,12,4,8);
    if(!old) {
      draw(back?32:20,36,8,12,4,8);
      draw(back?(slim?59:60):52,52,w,12,12,8);
      draw(back?(slim?51:52):44,36,w,12,4-w,8);
    }
    // Cabeza: base y sombrero/segunda capa. El atlas no cambia entre modelos.
    draw(back?24:8,8,8,8,4,0);
    draw(back?56:40,8,8,8,4,0);
  }
  function showPreview(dataUrl) {
    return new Promise((resolve,reject)=>{
      const img=new Image();
      img.onload=()=>{
        if(img.naturalWidth!==64||![32,64].includes(img.naturalHeight)){
          reject(new Error('La skin debe medir 64×64 o 64×32 píxeles.'));return;
        }
        cache.set(document.getElementById('skinPreviewArea'),img);
        refresh();resolve();
      };
      img.onerror=()=>reject(new Error('El PNG no se puede mostrar. Elegí otro archivo.'));
      img.src=dataUrl;
    });
  }
  function refresh(){
    const wrapper=document.getElementById('skinPreviewArea');
    const img=cache.get(wrapper);
    const side=document.getElementById('skinBackBtn').classList.contains('active')?'back':'front';
    for(const model of ['classic','slim'])drawBody(document.getElementById(`skinCanvas-${model}`),img,model,side);
  }
  window.minecraftSkinPreview={showPreview,refresh,clear(){cache.delete(document.getElementById('skinPreviewArea'));refresh();}};
})();
