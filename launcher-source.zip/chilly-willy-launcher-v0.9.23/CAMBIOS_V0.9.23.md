# Chilly Willy Launcher v0.9.23 — corrección de resource packs

Se corrigió el problema reportado por jugadores: varios packs Pokémon instalados (por ejemplo, MissingMons, LackingMons, MundialMons, MysticMons y Planeta Cobblemon) podían quedar del lado de los desactivados aunque Drive estuviera actualizado.

## Cambios
- El launcher sigue utilizando el manifiesto de Drive para distribuir archivos, pero ahora comprueba la carpeta `resourcepacks/` real de la instancia en cada arranque y activa TODOS los ZIP presentes, incluso si no figuran en ese manifiesto.
- Se reconocen también paquetes descomprimidos que contengan `pack.mcmeta` en su carpeta raíz. No se siguen accesos simbólicos ni se activan `.zip.disabled`.
- Se conserva el orden establecido por `presets/options.txt`, en vez de sobrescribirlo en el segundo paso de activación. El pack `Chilly-Willy-Pokemon.zip` sigue teniendo prioridad superior si está instalado.
- Solo se modifican los campos `resourcePacks` e `incompatibleResourcePacks` de `options.txt`; se conservan sensibilidad, controles, volumen y preferencias del usuario.
- Se hace respaldo único en `options.txt.chilly-willy-before-rp-hotfix.bak` antes del primer cambio real.
- No se modificó Google Apps Script ni el sistema de noticias de v0.9.22.

## Diagnóstico y prueba manual obligatoria
1. Compilar y ejecutar v0.9.23 con Minecraft cerrado.
2. Desde el launcher presionar JUGAR y abrir Opciones > Paquetes de recursos.
3. Verificar que los ZIP locales Pokémon aparecen activados, y E19 conserva la prioridad planeada.
4. Cerrar Minecraft normalmente y volver a iniciar. Confirmar que siguen activos y que persisten los controles.
5. Si siguen desactivándose: enviar el `options.txt` de la instancia **sin datos privados** y el listado de `resourcepacks/` y revisar `latest.log`; podrían intervenir Default Options u otro mod al escribir opciones después del paso del launcher.

## Alcance de la verificación
177 pruebas automatizadas Node aprobadas. No se verificó todavía con Minecraft 1.21.1, Fabric, Windows ni la cuenta de un jugador real. No se publicó ninguna release.
