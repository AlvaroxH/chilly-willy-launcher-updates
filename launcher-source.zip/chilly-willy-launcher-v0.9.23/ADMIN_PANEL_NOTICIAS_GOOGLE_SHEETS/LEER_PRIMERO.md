# Panel web privado (dentro de Google Sheets)

Se agrega como **barra lateral de la propia hoja `Chilly-Willy-Noticias`**; no es una web pública ni necesita una contraseña guardada en el launcher.

1. Abrí **tu hoja** `Chilly-Willy-Noticias` en el navegador, desde la cuenta de Google con permisos de edición.
2. En **Extensiones → Apps Script**, creá o abrí el proyecto **vinculado a esa hoja** (DISTINTO del Apps Script público de tu modpack).
3. Pegá `Code.gs` en el archivo `Code.gs` del proyecto vinculado.
4. Creá un archivo HTML desde el botón **+ → HTML** llamado exactamente `Sidebar` y pegá el contenido de `Sidebar.html`.
5. Guardá y recargá la hoja. Aparecerá el menú **Chilly Willy → Administrar noticias**. Si Google pide permisos, autorizá la primera ejecución desde tu propia cuenta.
6. Desde el panel agregá, editá, publicá, programá y eliminá noticias. La hoja es el origen de datos; el Apps Script público de `APPS_SCRIPT_ACTUALIZADO/Code.gs` la lee, por lo que **NO** tenés que crear una nueva versión del launcher para cada noticia.

## Seguridad

No compartas el permiso de edición de la hoja con jugadores. No implementes este código como web app pública. Si tenés colaboradores que también pueden editar la hoja, también podrán usar el panel.

**Son dos scripts distintos:** el script público de modpack/noticias (en `APPS_SCRIPT_ACTUALIZADO/`) y el script del panel privado (en esta carpeta, vinculado a la hoja). No combines sus `Code.gs`.
