/**
 * CHILLY WILLY - PANEL PRIVADO DE NOTICIAS EN GOOGLE SHEETS
 * Instalar ÚNICAMENTE en Extensiones > Apps Script de la hoja Chilly-Willy-Noticias.
 * No reemplaza ni publica la API de Drive (APPS_SCRIPT_ACTUALIZADO/Code.gs).
 * El menú solo es accesible a los editores autorizados de esta hoja.
 */
const CW_NEWS_TAB='Noticias';
const CW_HEADERS=['Publicar','Fecha','Categoría','Título','Texto','Imagen URL','Enlace URL','Publicar desde','Publicar hasta'];
function onOpen(){SpreadsheetApp.getUi().createMenu('Chilly Willy').addItem('Administrar noticias','openChillyNewsAdmin').addToUi();}
function openChillyNewsAdmin(){
 SpreadsheetApp.getUi().showSidebar(HtmlService.createHtmlOutputFromFile('Sidebar').setTitle('Chilly Willy · Noticias').setWidth(380));
}
function cwSheet_(){
 const ss=SpreadsheetApp.getActiveSpreadsheet();
 if(!ss)throw Error('Abrí este panel desde la hoja de noticias.');
 const sheet=ss.getSheetByName(CW_NEWS_TAB);
 if(!sheet)throw Error('Falta la pestaña Noticias.');
 return sheet;
}
function cwText_(value,max){return String(value==null?'':value).trim().slice(0,max);}
function cwDate_(value){
 const text=cwText_(value,16);if(!text)return '';
 const m=/^(\d{4})-(\d{2})-(\d{2}) (\d{2}):(\d{2})$/.exec(text);
 if(!m)throw Error('Usá AAAA-MM-DD HH:MM (hora argentina).');
 const [y,mo,d,h,mi]=m.slice(1).map(Number);
 const check=new Date(Date.UTC(y,mo-1,d));
 if(y<2020||y>2100||check.getUTCFullYear()!==y||check.getUTCMonth()!==mo-1||check.getUTCDate()!==d||h>23||mi>59)
  throw Error('Fecha u hora inválida.');
 return text;
}
function cwUrl_(value){
 const s=cwText_(value,1024);if(!s)return '';
 try{const u=new URL(s);if(u.protocol==='https:'&&!u.username&&!u.password)return u.toString();}catch(e){}
 throw Error('Las imágenes y los enlaces deben usar HTTPS válido.');
}
function getChillyNewsAdmin(){
 const sheet=cwSheet_(),last=Math.min(sheet.getLastRow(),201);
 if(last<2)return [];
 return sheet.getRange(2,1,last-1,9).getDisplayValues().map((fields,i)=>({row:i+2,fields})).filter(({fields})=>fields.some(v=>String(v).trim()));
}
function saveChillyNewsAdmin(news){
 if(!news||typeof news!=='object')throw Error('Noticia inválida.');
 const sheet=cwSheet_();
 const row=Number(news.row)||0;
 const old=row>=2&&row<=sheet.getLastRow();
 if(row&&!old)throw Error('La noticia ya no existe. Recargá el panel.');
 if(sheet.getLastRow()>=201&&!old)throw Error('Alcanzaste el límite de noticias; archivá algunas primero.');
 const title=cwText_(news.title,110),body=cwText_(news.body,900);
 if(!title||!body)throw Error('El título y el texto son obligatorios.');
 const from=cwDate_(news.from),until=cwDate_(news.until);
 if(from&&until&&from>=until)throw Error('La fecha final debe ser posterior a la inicial.');
 const values=[news.published===true?'SI':'NO',cwText_(news.date,35),cwText_(news.category,28)||'COMUNIDAD',title,body,cwUrl_(news.image),cwUrl_(news.link),from,until];
 const target=old?row:sheet.getLastRow()+1;
 const range=sheet.getRange(target,1,1,9);
 range.setNumberFormat('@'); // Texto, nunca interpretar como fórmulas las noticias.
 range.setValues([values]);
 SpreadsheetApp.flush();
 return {saved:true,row:target};
}
function deleteChillyNewsAdmin(row){
 const r=Number(row),sheet=cwSheet_();
 if(!Number.isSafeInteger(r)||r<2||r>sheet.getLastRow())throw Error('Noticia inexistente.');
 sheet.deleteRow(r);return {deleted:true};
}
