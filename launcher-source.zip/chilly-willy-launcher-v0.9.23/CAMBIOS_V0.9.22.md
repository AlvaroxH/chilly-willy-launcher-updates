# Chilly Willy Launcher v0.9.22 — revisión ampliada de la misma versión

Se mantiene la numeración **0.9.22**. Además del Estudio de skins premium y el historial por cuenta, esta revisión incorpora:

## Noticias independientes del ejecutable

- Al abrir el launcher: descargar las noticias publicadas del Apps Script.
- Automático: repetir consulta cada **2 minutos** mientras la ventana esté visible.
- Botón **Actualizar noticias**: consultar inmediatamente (sin esperar el sondeo).
- Publicaciones programadas: desde/hasta (columnas H-I de la hoja) con hora Argentina UTC−03, valida fechas y evita noticias vencidas o no iniciadas.
- Copia local sin conexión y caducidad aplicada también a los avisos en caché.
- Panel privado con botones dentro del navegador de **Google Sheets**: crear, editar, publicar, dejar en borrador, programar y eliminar avisos. Instalar por separado desde `ADMIN_PANEL_NOTICIAS_GOOGLE_SHEETS` en el script vinculado a la hoja.
- Los jugadores solo tienen API pública de lectura; no existe una contraseña de admin incrustada en el ejecutable.

## Fresh Moves / Entity Texture Features

- Migración automática y **una sola vez** de `config/entity_texture_features.json`: `skinTransparencyMode` → `ALL`.
- Funciona en el primer inicio con ETF instalado y en instalaciones existentes; se aplica justo antes de arrancar Java, después de sincronizar el modpack.
- Respalda la configuración anterior si existía, cambia exclusivamente esa opción y respeta cualquier personalización posterior.
- No sobreescribe sensibilidad, controles, ajustes generales, mods ni skins. Si el JSON está corrupto lo conserva y registra aviso (el juego sigue iniciando).

## Para distribuir

1. Instalá y republicá el Apps Script público (una sola vez) con `APPS_SCRIPT_ACTUALIZADO/Code.gs`.
2. Creá la hoja de noticias (A-I) y, opcionalmente, instalá el panel de administrador dentro de la hoja.
3. Ejecutá `INICIAR_COMPILACION_NUBE.cmd` para enviar **v0.9.22** a GitHub Actions, luego probá el Setup y el Portable.
4. Si la release `v0.9.22` **ya existe en GitHub**, el script evitará sobrescribirla; en ese caso habrá que usar un nuevo número de versión antes de publicar.

## Verificación

Las pruebas automatizadas de Node verifican la programación, los filtros de noticias, la migración ETF y las funciones anteriores. Falta validar el renderizado de Fresh Moves y la integración de Google Sheets y Windows con clientes reales.
