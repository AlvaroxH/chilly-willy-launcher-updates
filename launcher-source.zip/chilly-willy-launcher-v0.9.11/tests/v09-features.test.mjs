import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,statSync} from 'node:fs';
const root=new URL('../', import.meta.url);
const read=(f)=>readFileSync(new URL(f,root),'utf8');
const main=read('electron/main.mjs'),ui=read('ui/index.html'),app=read('ui/app.js'),status=read('electron/minecraft-status.mjs'),script=read('apps-script/Code.gs');
test('el logo .ico compartido está incorporado a electron-builder y al UI',()=>{
  const pkg=JSON.parse(read('package.json'));
  assert.equal(pkg.build.win.icon,'build/cobbleverse.ico');
  assert.ok(statSync(new URL('build/cobbleverse.ico',root)).size>1000);
  assert.ok(statSync(new URL('ui/assets/cobbleverse-mark.png',root)).size>1000);
  assert.match(ui,/cobbleverse-mark\.png/);
  assert.match(main,/cobbleverse\.ico/);
});
test('la GUI sin consola se abre desde un archivo VBS y entrega en la carpeta raíz',()=>{
  assert.match(read('GENERAR_EXE.vbs'),/WindowStyle Hidden/);
  const ps=read('build/GENERADOR_GUI.ps1');
  assert.match(ps,/System\.Windows\.Forms/);
  assert.match(ps,/ProgressBar/);
  assert.match(ps,/CreateNoWindow=\$true/);
  assert.match(ps,/Copy-Item -LiteralPath \$s -Destination \$exeSetup/);
  assert.match(ps,/Copy-Item -LiteralPath \$p -Destination \$exePortable/);
});
test('cabezas de skin en cuenta y lista visible del servidor',()=>{
  assert.match(ui,/id="accountAvatar"/);
  assert.match(ui,/id="miniPlayerAvatar"/);
  assert.match(app,/function setAvatar/);
  assert.match(app,/window\.cobble\.skinHead/);
  assert.match(app,/skin-fallback\.png/);
  assert.match(status,/uuid:/);
});
test('publica rutas conservando carpetas y exige nuevo Apps Script antes de jugar',()=>{
  for(const x of ["'mods'","'config'","'resourcepacks'","'datapacks'","'shaderpacks'"]) assert.ok(script.includes(x));
  assert.match(script,/file\.getLastUpdated\(\)/);
  assert.match(main,/if \(!pack\.fullPack\)/);
});
