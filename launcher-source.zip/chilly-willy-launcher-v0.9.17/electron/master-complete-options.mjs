/**
 * Sincronización de options.txt fiel al maestro Cobbleverse.
 * v0.9.12: importar TODAS las opciones maestras en la primera apertura,
 * mantener ajustes personalizados posteriores y conservar datos propios del equipo.
 * Nunca leer/copiar progreso de jugador, waypoints ni mundo explorado.
 */
import fs from 'node:fs';
import path from 'node:path';

const MAX_BYTES = 1024 * 1024;
const STATE_REL = 'config/chilly-willy/master-complete-options-v0912.json';
const VALID_KEY = /^[A-Za-z0-9_.-]{1,160}$/;
const PRIVATE_OR_DEVICE = /^(?:lastServer|lastSeen.*|lastKnown.*|joinedFirstServer|fullscreenResolution|soundDevice|.*(?:token|session|password|secret|uuid|playerdata|statistic|advancement|waypoint).*)$/i;

function limitedRead(p, limit=MAX_BYTES) {
  const st=fs.statSync(p);
  if(!st.isFile()||st.size>limit)throw new Error('Archivo de preferencias inválido o demasiado grande.');
  return fs.readFileSync(p,'utf8');
}
function parse(s) {
  const bom=s.startsWith('\uFEFF')?'\uFEFF':'';
  const data=bom?s.slice(1):s;
  const eol=data.includes('\r\n')?'\r\n':'\n';
  const options=new Map();
  for(const line of data.split(/\r?\n/)) {
    if(!line)continue;
    const colon=line.indexOf(':');
    if(colon<=0)continue;
    const key=line.slice(0,colon);
    const value=line.slice(colon+1);
    if(!VALID_KEY.test(key)||value.includes('\0')||value.length>20000)continue;
    options.set(key,value);
  }
  return {bom,eol,options};
}
function atomic(p,text){
  fs.mkdirSync(path.dirname(p),{recursive:true});
  const tmp=p+`.tmp-${process.pid}-${Date.now()}`;
  try{fs.writeFileSync(tmp,text,{flag:'wx',encoding:'utf8'});fs.renameSync(tmp,p);}finally{try{fs.unlinkSync(tmp)}catch{}}
}
export function applyMasterCompleteOptions(instanceRoot) {
  if(typeof instanceRoot!=='string'||!path.isAbsolute(instanceRoot))throw new Error('Ruta inválida de la instancia de Minecraft.');
  const preset=path.join(instanceRoot,'presets','options.txt');
  if(!fs.existsSync(preset))throw new Error('Falta el options.txt del modpack maestro.');
  const master=parse(limitedRead(preset));
  if(master.options.size<30||master.options.get('version')!=='3955')throw new Error('El options.txt maestro está vacío, incompleto o no es de Minecraft 1.21.1.');
  const target=path.join(instanceRoot,'options.txt');
  const existed=fs.existsSync(target);
  const original=existed?limitedRead(target):'';
  const current=parse(original);
  const stateFile=path.join(instanceRoot,STATE_REL);
  const first=!fs.existsSync(stateFile);
  let old={};
  if(!first) {
    const data=JSON.parse(limitedRead(stateFile,256*1024));
    if(data?.schema!==1||!data.managed||typeof data.managed!=='object'||Array.isArray(data.managed))throw new Error('Estado de opciones maestro inválido. No se modificarán los ajustes.');
    old=data.managed;
  }
  // Cada actualización completa restablece las opciones maestras y elimina
  // opciones heredadas que ya no figuran en el modpack. Datos privados locales intactos.
  const merged=new Map();
  let applied=0,preserved=0;
  const managed={};
  for(const [key,value] of master.options) {
    if(PRIVATE_OR_DEVICE.test(key)) continue;
    if(current.options.get(key)!==value) applied++;
    merged.set(key,value);
    managed[key]=value;
  }
  for(const [key,value] of current.options){
    if(PRIVATE_OR_DEVICE.test(key)) {merged.set(key,value);preserved++;}
  }
  // No se incorporan claves de identidad/progreso procedentes del maestro.
  const formatted=current.bom+[...merged].map(([key,value])=>`${key}:${value}`).join(current.eol)+current.eol;
  let backupFile=null;
  if(original!==formatted) {
    if(existed&&first) {
      backupFile=path.join(instanceRoot,'config','chilly-willy','backups','options-before-full-master-v0912.txt');
      fs.mkdirSync(path.dirname(backupFile),{recursive:true});
      if(!fs.existsSync(backupFile))fs.copyFileSync(target,backupFile,fs.constants.COPYFILE_EXCL);
    }
    atomic(target,formatted);
  }
  atomic(stateFile,JSON.stringify({schema:1,managed},null,2)+'\n');
  return {first,applied,preserved,total:master.options.size,backupFile};
}

/** Distribuir el icono del modpack, nunca los saves ni datos de perfil. */
export function copyMasterPackIcon(instanceRoot){
  if(typeof instanceRoot!=='string'||!path.isAbsolute(instanceRoot))throw new Error('Ruta inválida.');
  const src=path.join(instanceRoot,'presets','icon.png');
  if(!fs.existsSync(src))return {copied:false};
  const st=fs.statSync(src);
  if(!st.isFile()||st.size<100||st.size>8*1024*1024)throw new Error('Icono maestro inválido.');
  const head=Buffer.alloc(8);const fd=fs.openSync(src,'r');try{fs.readSync(fd,head,0,8,0);}finally{fs.closeSync(fd);}
  if(!head.equals(Buffer.from([137,80,78,71,13,10,26,10])))throw new Error('El icono maestro no es PNG.');
  const dst=path.join(instanceRoot,'icon.png');
  const marker=path.join(instanceRoot,'config','chilly-willy','master-icon-v0912.done');
  if(fs.existsSync(marker))return {copied:false};
  if(fs.existsSync(dst)) {
    const backup=path.join(instanceRoot,'config','chilly-willy','backups','icon-before-master-v0912.png');
    fs.mkdirSync(path.dirname(backup),{recursive:true});
    if(!fs.existsSync(backup))fs.copyFileSync(dst,backup,fs.constants.COPYFILE_EXCL);
  }
  fs.copyFileSync(src,dst);
  atomic(marker,'ok\n');
  return {copied:true};
}
