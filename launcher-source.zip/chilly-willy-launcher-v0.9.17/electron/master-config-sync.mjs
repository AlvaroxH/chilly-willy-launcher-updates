/**
 * Importa la configuración íntegra del modpack maestro, SIN copiar progresos.
 * El manifiesto de Google Apps Script aplica el filtro de privacidad y este
 * módulo repite una allowlist de rutas y controles antes de escribir nada.
 * Stage async ANTES de eml.launch(); copy sync en evento launch_launch
 * (después de descarga de EML, justo antes de arrancar Java).
 */
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';

const PREFIXES = new Set(['config','defaultconfigs','cobblemon','data','presets']);
const FORBIDDEN = /(?:^|\/)(?:saves|waypoints?|advancements?|playerdata|stats|explored|visited|world-map-cache|map-data|cache|screenshots|logs)(?:\/|$)/i;
const PRIVATE = /(?:^|\/)(?:username-cache\.json|servers\.dat(?:_old)?|tokens?\.[^/]*|credentials?\.[^/]*|.*\.(?:pem|key|p12))(?:$)/i;
const MARKER_REL = 'config/chilly-willy/master-config-v0913.json';
const NAME = /^[^\\/:*?"<>|\x00-\x1f]{1,230}$/;
const MAX_ITEM = 30 * 1024 * 1024;
const MAX_TOTAL = 250 * 1024 * 1024;
const MAX_FILE_COUNT = 1800;

function validRelative(rel) {
  if (typeof rel !== 'string' || rel.length > 680 || rel.startsWith('/') || rel.includes('\\')) return false;
  const parts = rel.split('/');
  if (parts.length < 2 || !PREFIXES.has(parts[0]) || FORBIDDEN.test('/'+rel) || PRIVATE.test('/'+rel)) return false;
  return parts.every(x => NAME.test(x) && x !== '.' && x !== '..' && !/[. ]$/.test(x));
}
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
function safePath(root, rel) {
  if (!validRelative(rel) || !path.isAbsolute(root)) throw new Error('Ruta maestra no permitida.');
  const full = path.resolve(root, ...rel.split('/'));
  if (!full.startsWith(path.resolve(root) + path.sep)) throw new Error('Ruta fuera de la instancia.');
  return full;
}
function checkNoSymlink(root, rel) {
  const parts=rel.split('/');
  let node=path.resolve(root);
  // La raíz de Minecraft PUEDE ser una junction oficial de Windows cuando el usuario
  // mueve el juego a D:. Se permiten enlaces sólo en la raíz elegida; nunca dentro.
  // La validación de path y descendientes evita escapes o trampas en config/. 
  for (const part of parts) {
    node=path.join(node,part);
    if (fs.existsSync(node) && fs.lstatSync(node).isSymbolicLink()) throw new Error('Acceso mediante enlace simbólico no permitido.');
  }
}
const atomicWrite = (file, content) => {
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const tmp=file+`.tmp-${process.pid}-${Date.now()}`;
  try { fs.writeFileSync(tmp,content,{flag:'wx'});fs.renameSync(tmp,file); }
  finally {try{fs.unlinkSync(tmp)}catch{}}
};
function selectFiles(files) {
  if (!Array.isArray(files)) throw new Error('Falta la lista de configuraciones del manifiesto.');
  const result=[];
  const seen=new Set();
  let total=0;
  for (const f of files) {
    const rel=`${f.path ?? ''}${f.name ?? ''}`;
    if (!validRelative(rel)) throw new Error('El manifiesto incluye un archivo de configuración no permitido.');
    if (seen.has(rel.toLowerCase())) throw new Error('Configuración duplicada: '+rel);
    seen.add(rel.toLowerCase());
    if (!Number.isSafeInteger(f.size) || f.size<0 || f.size>MAX_ITEM) throw new Error('Configuración demasiado grande: '+rel);
    total+=f.size;
    if (total>MAX_TOTAL || result.length>=MAX_FILE_COUNT) throw new Error('Demasiadas configuraciones para sincronizar.');
    const u=new URL(f.url);
    if (u.protocol!=='https:'||u.hostname!=='drive.usercontent.google.com'||u.pathname!=='/download'||!u.searchParams.get('id'))
      throw new Error('Origen remoto no permitido: '+rel);
    result.push({rel,url:f.url,size:f.size,updated: f.updated??0});
  }
  return result;
}

async function download(item,{request,timeoutMs=90000,retries=2}={}) {
  for(let attempt=0;attempt<=retries;attempt++){
    try {
      const res=await request(item.url,{redirect:'follow',signal:AbortSignal.timeout(timeoutMs)});
      if(!res.ok) throw new Error(`HTTP ${res.status}`);
      if(Number(res.headers?.get('content-length') || 0)>Math.max(item.size+65536,MAX_ITEM))throw new Error('El servidor envió demasiado contenido.');
      const buffer=Buffer.from(await res.arrayBuffer());
      if(buffer.byteLength!==item.size) throw new Error(`Tamaño incorrecto (${buffer.length} en vez de ${item.size}).`);
      const type=(res.headers?.get('content-type') || '').toLowerCase();
      if(type.includes('text/html') || (buffer.subarray(0,64).toString('utf8').trimStart().startsWith('<!DOCTYPE html'))) throw new Error('Google devolvió HTML en lugar del archivo.');
      return buffer;
    }catch(e){
      if(attempt===retries)throw new Error(`No se pudo copiar ${item.rel}: ${e.message}`);
    }
  }
}

export async function stageMasterConfig({files,cacheRoot,request=fetch,progress=()=>{},concurrency=6}) {
  const selected=selectFiles(files);
  if (!path.isAbsolute(cacheRoot)) throw new Error('Caché de configuración inválida.');
  const snapshot=new Array(selected.length);
  let current=0, next=0;
  const errors=[];
  const workers=Array.from({length:Math.max(1,Math.min(8,concurrency,selected.length||1))},async()=>{
    while(next<selected.length) {
      const i=next++;
      const item=selected[i];
      const target=safePath(cacheRoot,item.rel);
      checkNoSymlink(cacheRoot,item.rel);
      let valid=false;
      if(fs.existsSync(target)) {
        const st=fs.statSync(target);
        valid=st.isFile()&&st.size===item.size && (!item.updated || Math.abs(st.mtimeMs-item.updated)<2000);
      }
      try {
        if(!valid) {
          const bytes=await download(item,{request});
          atomicWrite(target,bytes);
          if(item.updated>0) {const mtime=new Date(item.updated);fs.utimesSync(target,mtime,mtime);}
        }
        snapshot[i]={rel:item.rel,source:target,sha256:digest(fs.readFileSync(target))};
      } catch(error) { errors.push({file:item.rel,reason:String(error?.message ?? error)}); }
      progress(++current,selected.length);
    }
  });
  await Promise.all(workers);
  const ready=snapshot.filter(Boolean);
  ready.errors=errors;
  ready.requested=selected.length;
  return ready;
}

export function applyMasterConfig({instanceRoot,snapshot}) {
  if(!path.isAbsolute(instanceRoot)||!Array.isArray(snapshot))throw new Error('Snapshot inválido.');
  const statePath=safePath(instanceRoot,MARKER_REL);
  checkNoSymlink(instanceRoot,MARKER_REL);
  let previous={};
  let first=!fs.existsSync(statePath);
  if(!first){
    const parsed=JSON.parse(fs.readFileSync(statePath,'utf8'));
    if(parsed.schema!==1||typeof parsed.managed!=='object'||!parsed.managed||Array.isArray(parsed.managed))throw new Error('Estado del perfil maestro no válido.');
    previous=parsed.managed;
  }
  let applied=0,preserved=0;
  const managed={...previous};
  for(const entry of snapshot){
    if(!validRelative(entry.rel)||!path.isAbsolute(entry.source))throw new Error('Snapshot contiene ruta inválida.');
    const target=safePath(instanceRoot,entry.rel);
    checkNoSymlink(instanceRoot,entry.rel);
    const contents=fs.readFileSync(entry.source);
    if(digest(contents)!==entry.sha256) throw new Error('La copia caché fue alterada.');
    const existing=fs.existsSync(target) ? fs.readFileSync(target):null;
    const previousHash=previous[entry.rel];
    if(existing&&digest(existing)===entry.sha256) {managed[entry.rel]=entry.sha256;continue;}
    // v0.9.17: el maestro es autoritativo cuando hay sincronización completa.
    // Esto corrige perfiles Xaero, menús FancyMenu y Splash Screen que antes
    // quedaban anclados a valores viejos o modificados en las versiones 0.9.1x.
    // Conservamos un respaldo del archivo anterior para recuperarlo si hace falta.
    if(existing){
      const backup=safePath(instanceRoot,'config/chilly-willy/backups/v0913/'+entry.rel);
      if(!fs.existsSync(backup)) {
        checkNoSymlink(instanceRoot,'config/chilly-willy/backups/v0913/'+entry.rel);
        fs.mkdirSync(path.dirname(backup),{recursive:true});
        fs.copyFileSync(target,backup,fs.constants.COPYFILE_EXCL);
      }
    }
    atomicWrite(target,contents);
    managed[entry.rel]=entry.sha256;
    applied++;
  }
  atomicWrite(statePath,Buffer.from(JSON.stringify({schema:1,managed,updatedAt:new Date().toISOString()},null,2)));
  const mandatory=[
    'config/xaero/minimap/client.cfg',
    'config/xaero/minimap/profiles/cobbleverse.cfg',
    'config/xaero/world-map/profiles/cobbleverse.cfg',
    'config/fancymenu/options.txt',
    'config/fancymenu/customization/cobbleverse_main.txt',
    'config/customsplashscreen/background.png'
  ];
  const critical=mandatory.filter(rel=>!fs.existsSync(safePath(instanceRoot,rel)));
  return {first,applied,preserved,total:snapshot.length,critical};
}
