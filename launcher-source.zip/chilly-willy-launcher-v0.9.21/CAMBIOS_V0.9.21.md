# Chilly Willy Launcher v0.9.21 — Resource packs, skins y Windows

## Cambios implementados

1. **Todos los ZIP del modpack:** se seleccionan TODOS los archivos ZIP del manifiesto bajo `resourcepacks/`, incluso los que llevan `DO NOT ENABLE`, `Credits Only`, etc. Los archivos `.rpo` no se activan: no son resource packs ZIP de Minecraft. La nueva comprobación rápida reactiva los ZIP oficiales realmente descargados antes de abrir Java. Se mantiene la prioridad del pack del Pokémon en último lugar.
2. **Incompatibilidad de formato:** los ZIP del manifiesto se incluyen en `incompatibleResourcePacks` para aceptar la advertencia de formato y en `resourcePacks` para activarlos. **Esto no repara packs dañados ni garantiza que se puedan cargar.** Si un pack produce fallos, quitá o corregí el ZIP en el Drive maestro y volvé a sincronizar.
3. **Skin premium (tu propia cuenta):** apartado de Cuenta con botón de archivo PNG y variante clásica/delgada. Solo se habilita tras iniciar sesión con Microsoft. Valida el formato 64×64/64×32 y tamaño máximo 2 MB, pide confirmación y utiliza `new Skin(account).updateSkin` de EML. Los tokens no se envían a la pantalla.
4. **Inicio con Windows:** interruptor en Configuración que registra o elimina la aplicación de inicio mediante Electron, solo en Windows empaquetado. Desactivado hasta que el jugador lo habilite. Si se usa Portable y se mueve su archivo, hay que revisar la configuración de inicio.
5. **Comportamiento al jugar:** conservar la ventana, minimizarla o enviarla a bandeja de sistema. Si estaba oculta en la bandeja, vuelve a mostrarse cuando termina Minecraft.
6. **Acceso directo a la carpeta de Minecraft:** abre la ruta real de la instalación sin tener que buscarla manualmente.
7. **Preferencias intactas:** se preservan teclas, sensibilidad, sonido, gráficos y servidores personales; la lógica anterior de sincronización segura sigue presente.

## Acción OBLIGATORIA del administrador: republicar Google Apps Script

El script `apps-script/Code.gs` v0.9.21 ahora **incluye** los resourcepacks con nombres `DO NOT ENABLE` o Xray. El Apps Script v6 anteriormente desplegado los omitía; **sin esta nueva implementación, los jugadores jamás los descargarán**, aunque usen la v0.9.21 del launcher. En Google Apps Script, reemplazá el contenido de `Code.gs` por el archivo incluido en `APPS_SCRIPT_ACTUALIZADO/Code.gs`, guardá y elegí **Implementar → Administrar implementaciones → Editar (implementación web actual) → Versión: Nueva versión → Implementar**. No crees una nueva implementación si querés conservar la URL /exec actual. Confirmá que responde con el manifiesto v6 y contiene los nombres ZIP antes excluidos. Luego recompilá y probá el launcher.

**No se deben poner en Drive datos privados:** el script conserva el filtrado de playerdata, saves, credenciales, etc. El Xray puede afectar las reglas de juego del servidor; la inclusión responde a la instrucción de habilitar todos los ZIP.

## Pendiente de prueba real (no afirmamos haberlo probado en Windows)

- Confirmar el inicio automático con el Setup y con el Portable en Windows 11.
- Iniciar sesión premium y cargar una PNG real; EML v2.7.4 ofrece la API, pero hay que validar el funcionamiento del servicio oficial y el refresco de la skin.
- Republicar Apps Script y descargar todo el modpack real de Drive; comprobar que incluso los ZIP marcados DO NOT ENABLE aparecen activados. **Advertencia:** algunos packs de créditos podrían ser incompatibles o romper recursos; respetar el pedido de habilitarlos todos supone ese riesgo.
- Verificar Fresh Moves/ETF: el ajuste `Allow skin transparency = All skins` sigue pendiente de migración automática porque falta una muestra real de `entity_texture_features.json`.
- Launcher Studio: editor visual de botones, funciones, fondos y tarjetas sigue siendo un proyecto distinto.

## Compilación GitHub Actions

Extraer `Chilly-Willy-v0.9.21-GitHub.zip` y ejecutar `INICIAR_COMPILACION_NUBE.cmd` tras iniciar sesión en GitHub CLI. El script **pedirá confirmación explícita** antes de subir el ZIP de código al repositorio público `AlvaroxH/chilly-willy-launcher-updates`; no ejecuta la publicación de una release. Revisar el borrador y probar el ejecutable antes de publicar a los jugadores.

No incluye Java, Minecraft, credenciales, el pack del Pokémon ni ejecutables de Windows compilados.
