/** Edición exclusiva de la skin de la cuenta Microsoft ACTIVA, mediante EML Skin.
 * Nunca se trasladan tokens al frontend ni se obtiene acceso a otros jugadores.
 */
import { readFileSync, statSync } from 'node:fs';
export function validateSkinPng(bytes) {
  if (!Buffer.isBuffer(bytes) || bytes.length < 33 || bytes.length > 2*1024*1024) throw new Error('La skin PNG debe ocupar como máximo 2 MB.');
  if (!bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) throw new Error('El archivo no es un PNG válido.');
  if (bytes.toString('ascii',12,16) !== 'IHDR') throw new Error('PNG sin cabecera IHDR.');
  const width = bytes.readUInt32BE(16), height = bytes.readUInt32BE(20);
  if (width !== 64 || ![32,64].includes(height)) throw new Error('La skin debe medir 64×64 píxeles (o 64×32 antigua).');
  return {width,height};
}
export async function uploadPremiumSkin({account,filePath,variant,SkinClass}) {
  if (!account || typeof account !== 'object') throw new Error('Iniciá sesión con una cuenta Microsoft.');
  if (variant !== 'classic' && variant !== 'slim') throw new Error('Modelo de skin inválido.');
  if (typeof SkinClass !== 'function') throw new Error('La biblioteca de skins no está disponible.');
  if (statSync(filePath).size > 2*1024*1024) throw new Error('Skin demasiado grande.');
  const bytes = readFileSync(filePath);
  validateSkinPng(bytes);
  // EML Lib dispone de un método para la cuenta autenticada, sin adivinar
  // campos del token que podrían cambiar de formato entre versiones.
  const skin = new SkinClass(account);
  await skin.updateSkin(new Blob([bytes],{type:'image/png'}),variant);
  return {ok:true,variant};
}
