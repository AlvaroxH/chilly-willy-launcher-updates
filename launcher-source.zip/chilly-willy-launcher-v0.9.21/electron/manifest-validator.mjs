import { createHash } from 'node:crypto';
// Manifest seguro del modpack. El archivo JSON puede estar publicado para cualquier cliente,
// por tanto cada ruta y cada URL debe verificarse ANTES de pasarse a EML.
const GOOD_NAME = /^[^\\/:*?"<>|\x00-\x1f]{1,230}$/;
const RESERVED = new Set(['CON','PRN','AUX','NUL',...Array.from({length:9}, (_,i)=>`COM${i+1}`),...Array.from({length:9}, (_,i)=>`LPT${i+1}`)]);
const SECTIONS = ['mods', 'config', 'resourcepacks', 'datapacks', 'shaderpacks', 'defaultconfigs', 'cobblemon', 'data', 'presets'];
export function validateManifest(data) {
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Manifiesto inválido.');
  if (data.error) throw new Error(`Error de Apps Script: ${String(data.detail || data.error).slice(0,240)}`);
  if (!Array.isArray(data.files) || !data.files.length) throw new Error('El manifiesto está vacío.');
  if (data.files.length > 12000) throw new Error('Demasiados archivos en el manifiesto (máximo 12000).');
  const counts = Object.fromEntries(SECTIONS.map(section => [section, 0]));
  const totals = Object.fromEntries(SECTIONS.map(section => [section, 0]));
  const seen = new Set();
  const resourcepackFiles = [];
  const shaderFiles = [];
  const configurationFiles = [];
  const modFiles = [];
  const fingerprint = createHash('sha256');
  for (const f of data.files) {
    if (!f || typeof f !== 'object') throw new Error('Registro de archivo inválido.');
    if (typeof f.name !== 'string' || !GOOD_NAME.test(f.name) || f.name === '.' || f.name === '..' || f.name.endsWith('.') || f.name.endsWith(' ') || RESERVED.has(f.name.split('.')[0].toUpperCase())) throw new Error(`Nombre inválido: ${String(f.name).slice(0,80)}`);
    if (typeof f.path !== 'string' || f.path.length > 600 || !f.path.endsWith('/')) throw new Error(`Carpeta inválida para ${f.name}.`);
    const segments = f.path.split('/'); segments.pop();
    const category = segments[0];
    if (!SECTIONS.includes(category) || segments.some(s => !s || !GOOD_NAME.test(s) || s === '.' || s === '..' || s.endsWith('.') || s.endsWith(' ') || RESERVED.has(s.split('.')[0].toUpperCase()))) throw new Error(`Ruta no permitida para ${f.name}.`);
    if (category === 'presets' && (f.path !== 'presets/' || !['options.txt','icon.png'].includes(f.name))) throw new Error('Preset no permitido.');
    if (/^(?:username-cache\.json|servers\.dat(?:_old)?)$/i.test(f.name)) throw new Error('Datos individuales no permitidos en el modpack.');
    if (/(?:^|\/)(?:waypoints?|advancements?|playerdata|stats|map-data|world-map-cache|cache|visited|explored|saves)(?:\/|$)/i.test(f.path)) throw new Error('Datos de jugador o exploración no permitidos.');
    if (category === 'data' && (f.path !== 'data/' || f.name !== 'fabricDefaultResourcePacks.dat')) throw new Error('Archivo data/ no permitido.');
    // Ningún ZIP se excluye por su nombre, aunque diga DO NOT ENABLE.
    if (category === 'mods' && (!f.name.toLowerCase().endsWith('.jar') || f.type !== 'MOD')) throw new Error(`Mod inválido: ${f.name}.`);
    if (category !== 'mods' && f.type !== 'OTHER') throw new Error(`Tipo inválido: ${f.name}.`);
    if (!Number.isSafeInteger(f.size) || f.size < 0 || f.size > 1000000000 || (category === 'mods' && f.size === 0)) throw new Error(`Tamaño inválido: ${f.name}.`);
    if (f.updated != null && (!Number.isSafeInteger(f.updated) || f.updated < 0)) throw new Error(`Fecha inválida: ${f.name}.`);
    let u;
    try { u = new URL(f.url); } catch { throw new Error(`URL inválida: ${f.name}`); }
    if (u.protocol !== 'https:' || u.hostname !== 'drive.usercontent.google.com' || u.pathname !== '/download' || !u.searchParams.get('id') || u.username || u.password) throw new Error(`Origen de descarga no permitido: ${f.name}.`);
    const key = `${f.path}${f.name}`.toLocaleLowerCase('en-US');
    if (seen.has(key)) throw new Error(`Archivo duplicado: ${key}`);
    seen.add(key); counts[category] += 1; totals[category] += f.size;
    fingerprint.update([f.path, f.name, String(f.size), String(f.updated ?? 0), u.searchParams.get('id')].join('\0') + '\n');
    if (category === 'mods') modFiles.push({name:f.name,size:f.size});
    // Solo nombres/rutas previamente validados; no exponer URLs innecesarias.
    if (category === 'resourcepacks') resourcepackFiles.push({ name: f.name, path: f.path });
    if (category === 'shaderpacks') shaderFiles.push({ name: f.name, path: f.path });
    if (['config','defaultconfigs','cobblemon','data','presets'].includes(category)) configurationFiles.push({ name:f.name, path:f.path, size:f.size, updated:f.updated, url:f.url });
  }
  if (counts.mods === 0) throw new Error('No se encontraron mods. Revisá el Apps Script.');
  const fullPack = counts.config > 0 && counts.resourcepacks > 0 && counts.datapacks > 0;
  const completeMaster = data.version >= 5 && data.source === 'cobbleverse-master' && counts.presets >= 1 && data.files.some(f => f.path === 'presets/' && f.name === 'options.txt');
  const fullShaderPack = shaderFiles.some(f => (f.path === 'shaderpacks/' && f.name.toLowerCase().endsWith('.zip')) || f.path.startsWith('shaderpacks/COBBLEVERSE - Shaders/shaders/') || f.path.startsWith('shaderpacks/COBBLEVERSE - Shaders (High Quality)/shaders/'));
  return {
    ok: true, fullPack, fullShaderPack, completeMaster, version: data.version || 1,
    fingerprint: fingerprint.digest('hex'), modFiles,
    count: counts.mods, counts, resourcepackFiles, shaderFiles, configurationFiles, totalMiB: Math.round(totals.mods/1048576*10)/10,
    totalPackMiB: Math.round(Object.values(totals).reduce((a,b)=>a+b,0)/1048576*10)/10,
    warnings: fullPack ? [fullShaderPack ? completeMaster ? 'Modpack maestro encontrado; verificar descarga íntegra antes de distribuir.' : 'Falta publicar Apps Script v0.9.10.' : 'El servicio de Apps Script aún no incluye shaderpacks. Publicá Code.gs v0.9.10.'] : ['El Apps Script publicado aún devuelve solo mods. Actualizá y reimplementá Code.gs (v0.9) para incluir config, resourcepacks y datapacks.']
  };
}
