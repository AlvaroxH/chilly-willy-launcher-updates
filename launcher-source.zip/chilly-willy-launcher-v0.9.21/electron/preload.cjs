const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('cobble', {
  state: () => ipcRenderer.invoke('launcher:state'),
  serverStatus: () => ipcRenderer.invoke('launcher:server-status'),
  skinHead: (identity) => ipcRenderer.invoke('launcher:skin-head', identity),
  copyIp: () => ipcRenderer.invoke('launcher:copy-ip'),
  setMemory: (mb) => ipcRenderer.invoke('launcher:set-memory', mb),
  setStartWithWindows: (enabled) => ipcRenderer.invoke('launcher:set-start-with-windows', enabled),
  setAfterLaunch: (choice) => ipcRenderer.invoke('launcher:set-after-launch', choice),
  openGameFolder: () => ipcRenderer.invoke('launcher:open-game-folder'),
  changePremiumSkin: (variant) => ipcRenderer.invoke('launcher:change-premium-skin', variant),
  gameLocation: () => ipcRenderer.invoke('launcher:game-location'),
  chooseGameLocation: () => ipcRenderer.invoke('launcher:choose-game-location'),
  useDefaultGameLocation: () => ipcRenderer.invoke('launcher:default-game-location'),
  windowAction: (action) => ipcRenderer.invoke('launcher:window-action', action),
  loginMicrosoft: () => ipcRenderer.invoke('launcher:login-microsoft'),
  loginGuest: (name) => ipcRenderer.invoke('launcher:login-guest', name),
  logout: () => ipcRenderer.invoke('launcher:logout'),
  play: () => ipcRenderer.invoke('launcher:play'),
  checkManifest: (forceRemote = false) => ipcRenderer.invoke('launcher:check-manifest', forceRemote),
  forceModpackSync: () => ipcRenderer.invoke('launcher:force-modpack-sync'),
  updatesState: () => ipcRenderer.invoke('launcher:updates-state'),
  checkUpdates: () => ipcRenderer.invoke('launcher:check-updates'),
  installUpdate: () => ipcRenderer.invoke('launcher:install-update'),
  discordPresenceState: () => ipcRenderer.invoke('launcher:discord-presence-state'),
  setDiscordPresence: (enabled) => ipcRenderer.invoke('launcher:set-discord-presence', enabled),
  onUpdate: (callback) => {
    const handler = (_event, data) => callback(data);
    ipcRenderer.on('launcher:update-status', handler);
    return () => ipcRenderer.removeListener('launcher:update-status', handler);
  },
  onProgress: (callback) => {
    const handler = (_event, data) => callback(data);
    ipcRenderer.on('launcher:progress', handler);
    return () => ipcRenderer.removeListener('launcher:progress', handler);
  }
});
