# Chilly Willy Launcher v0.9.20 — Pokémon personalizado con resource pack automático

## Incluido en esta versión

- Todo ZIP elegible agregado a `resourcepacks/` en el Drive maestro se sigue descargando y habilitando en el primer lanzamiento posterior a detectar el cambio de manifiesto. No se requiere abrir el menú de Paquetes de recursos.
- Nuevo campo `priorityResourcePacks` en `config/server.json`. El archivo `Chilly-Willy-Pokemon.zip` (nombre acordado para este paquete; se puede cambiar en el JSON) se pone **al final** de la lista `resourcePacks` de Minecraft, es decir, sobre otros resource packs visuales.
- En **inicio rápido**, si un jugador desactivó accidentalmente ese pack obligatorio, se habilita otra vez justo antes de iniciar Java. No se reactivan otros packs que el usuario haya apagado.
- Si el ZIP todavía no existe en el manifiesto de Drive o no está descargado en el cliente, el inicio rápido NO inventa un pack ni lo marca como activo. Se notifica el problema sin impedir que Minecraft inicie.
- Las preferencias del jugador (sensibilidad, teclas, volumen, gráficos, otros resource packs) siguen protegidas por la corrección v0.9.19.
- Los servidores de Minecraft continúan agregándose automáticamente a la lista Multijugador.

## Qué debe hacer el administrador ANTES de publicar

1. Preparar un ZIP de **resource pack del cliente**, válido para la versión del modpack. Dentro del ZIP debe haber `pack.mcmeta` y `assets/` al nivel raíz. El datapack es **diferente**, normalmente contiene `data/`.
2. Nombrar el resource pack **`Chilly-Willy-Pokemon.zip`**. Si preferís otro nombre, cambiar el campo `priorityResourcePacks` en `config/server.json` **ANTES de compilar**.
3. Subir el ZIP a la carpeta `resourcepacks/` (raíz de dicha carpeta) dentro del Google Drive maestro que ya sincroniza el launcher.
4. Instalar el **datapack** en `world/datapacks/` del mundo activo del servidor Cobbleverse y reiniciar el servidor o usar `/reload` de forma controlada. Confirmar con `/datapack list enabled`. El launcher **no** instala datapacks en el servidor.
5. Compilar Setup y Portable para Windows desde el script `INICIAR_COMPILACION_NUBE.cmd`. Los archivos ZIP de este paquete no incluyen ejecutables compilados.
6. Probar con Minecraft cerrado: primera sincronización, menú de Paquetes de recursos, y el Pokémon ya renderizado al conectarse. Cerrar y reiniciar para probar inicio rápido. Cambiar sensibilidad y teclas y verificar que se conserven.

## Restricciones y observaciones

- Este paquete fuente NO trae todavía el ZIP de textura/modelo del Pokémon; no fue proporcionado. El archivo debe subirse a Drive por separado.
- Aún no hay prueba real de la descarga en Drive ni de Minecraft/Fabric/Windows; solo comprobaciones automatizadas de código.
- Los resource packs pueden entrar en conflicto si contienen modelos con rutas idénticas. Priorizar el del Pokémon resuelve el orden de carga, pero no garantiza que todos los modelos/animaciones estén bien construidos.
- No se ha modificado el Apps Script v6 ni el servidor Minecraft.

## Pendientes acumulados, NO implementados aquí

- **ETF / Fresh Moves (ojos negros):** confirmada la solución manual `Allow skin transparency = All skins`. Para aplicarla automáticamente sin afectar preferencias ajenas, falta comprobar la clave/valor exacto del archivo `config/entity_texture_features.json` que genera la versión de ETF del modpack; exportar primero el archivo de un cliente donde ya funciona. No forzar un campo JSON desconocido.
- **Launcher Studio visual avanzado:** mover/reordenar/agregar/quitar botones y asignarles acciones, fondos y tarjetas configurables desde el editor. Es un proyecto separado; v0.9.20 no lo incluye.

