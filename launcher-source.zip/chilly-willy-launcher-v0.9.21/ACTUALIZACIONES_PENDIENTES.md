# Chilly Willy — hoja de ruta (2026-11-02)

**v0.9.21 preparada para pruebas:** activación de todos los resourcepacks ZIP en cada inicio, cambio de skin premium de la cuenta autenticada, iniciar con Windows, conducta de la ventana tras jugar y abrir carpeta del juego. La corrección de controles y de la lista Multijugador proviene de v0.9.19. La prioridad del pack Pokémon proviene de v0.9.20.

**Pendiente:** aplicar ETF `Allow skin transparency = All skins` para solucionar ojos negros de Fresh Moves de forma segura y sin machacar preferencias; necesitamos el ejemplo de `config/entity_texture_features.json` de un cliente donde funciona.

**Pendiente importante (Launcher Studio):** mover botones, agregarlos/eliminarlos, definir acciones, editar fondos y tarjetas, reordenar componentes y configurarlos visualmente; requiere evolución independiente de Launcher Studio, NO está incluida en v0.9.21.
