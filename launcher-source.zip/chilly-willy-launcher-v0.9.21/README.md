# Versión v0.9.20: resource pack del Pokémon activado automáticamente

Ver [CAMBIOS_V0.9.20.md](CAMBIOS_V0.9.20.md) y [ACTUALIZACIONES_PENDIENTES.md](ACTUALIZACIONES_PENDIENTES.md).

# Versión v0.9.19: preferencias persistentes y servidor en Multijugador

Ver [CAMBIOS_V0.9.19.md](CAMBIOS_V0.9.19.md) para detalles y pruebas.

Consultá CAMBIOS_V0.9.12.md y usá Code.gs v6 (reimplementación existente) para sincronización segura.

# Chilly Willy Launcher v0.9.12 — Configuración completa del modpack maestro

**Nuevo origen oficial:** https://drive.google.com/drive/folders/1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM

Esta versión ahora sincroniza la lista segura de carpetas maestras. No transmite partidas, capturas, logs ni mapas privados.
**Acción obligatoria:** actualizar e implementar `apps-script/Code.gs` (versión de manifiesto 5), luego generar el nuevo Setup con `GENERAR_EXE.vbs`.
La v0.9.12 agrega sincronización completa y exclusiva de opciones maestras. Debe probarse en Windows antes de publicar la Release.
La eliminación de mods obsoletos sigue desactivada para evitar pérdida de archivos del jugador.

---

# Chilly Willy Launcher v0.9.12 — Auto-Updater

**Novedad:** actualizaciones del launcher por GitHub Releases, independientes del modpack de Drive.

**IMPORTANTE:** para publicar la versión e iniciar las actualizaciones para todos, leé **`PUBLICAR_ACTUALIZACIONES_GITHUB.md`**.

El código fuente todavía debe compilarse en tu Windows mediante `GENERAR_EXE.vbs`; aquí no se incluye un `Setup.exe` compilado. El repositorio GitHub aún no tiene por qué contener Releases publicadas.

---

# CHILLY WILLY LAUNCHER v0.9.8 — Hecho por Chilly Willy

## 1) Primero: activá las cinco carpetas de Google Drive (OBLIGATORIO)

La implementación Apps Script v0.9.6 **todavía no publica shaderpacks/**. Cambiar el ZIP del launcher **NO puede modificar por sí solo un Apps Script publicado en tu cuenta**.

1. Abrí el **proyecto Apps Script original** que ya publicaste (el que contiene la URL `/exec` de Cobbleverse).
2. Reemplazá TODO su código por el archivo `apps-script/Code.gs` de este ZIP.
3. Elegí **Implementar → Administrar implementaciones → Editar (lápiz) → Versión: Nueva versión → Implementar**. **No crees otra implementación** si querés conservar la misma URL `/exec`.
4. Abrí la URL `/exec` en una ventana de incógnito: el JSON debería empezar con `{"version":4,"files":[...]}` y contener rutas `mods/`, `config/`, `resourcepacks/`, `datapacks/`, `shaderpacks/`.
5. Abrí el launcher y seleccioná Mods → **Volver a comprobar Drive**: debe mostrar cantidades de las cinco carpetas. Si ves «solo mods», la implementación antigua sigue activa.

El Apps Script usa DriveApp en las cinco carpetas que compartiste y sus subcarpetas. No enumera ni comparte el Drive entero. **No pongas contraseñas ni información privada allí**; los metadatos se publican para todos los jugadores. Debés tener permisos para redistribuir el contenido.

## 2) Generar Windows EXE sin ventana CMD

1. Extraé este ZIP en una carpeta fuera de OneDrive, por ejemplo `C:\Proyectos\CobbleverseLauncher`.
2. En TU PC de creador (no en la de tus jugadores), instalá Node.js LTS una sola vez.
3. Hacé doble clic en **`GENERAR_EXE.vbs`**. Abrirá un panel gráfico de generación; **no aparece CMD**. La barra animada indica que hay trabajo en curso y muestra en qué etapa está, no un porcentaje inventado.
4. Cuando termine verás, **junto a `GENERAR_EXE.vbs`**, los archivos:

   - `Chilly-Willy-Launcher-Setup-0.9.12.exe` (el que pasás a tus amigos)
   - `Chilly-Willy-Launcher-Portable-0.9.12.exe` (ejecutable independiente)
   - `PARA_JUGADORES_PORTABLE/` con un acceso alternativo `.bat`.

Si hay un problema, usá **VER REGISTRO** en el panel. `GENERAR_EXE.bat` se conserva solo como acceso alternativo, pero podría mostrar un destello de consola. **Para cero consola usá el VBS**.

En desarrollo (solo creador): `npm.cmd install`, `npm.cmd run dev`, `npm.cmd run test:manifest`.

**Este ZIP contiene el proyecto fuente, NO los ejecutables de Windows ya compilados.** La GUI de compilación está diseñada para Windows y no ha sido probada en esta sesión sobre Windows real.

## 3) Qué sincroniza el launcher

- **`mods/`**: `.jar` elegibles. Mods `.jar.disabled` quedan excluidos; mod identificado como 1.21.11 se excluye preventivamente.
- **`config/`**: configuraciones y subcarpetas para la instancia aislada del jugador. Se excluyen patrones explícitos de archivos sensibles de servidor como `ops.json`, `server.properties`, claves y `.env`.
- **`resourcepacks/`**: todos los archivos compartidos, incluidos los `.zip`, `.rpo` y carpetas. Ahora el launcher activa los ZIP elegibles automáticamente en `options.txt` al presionar JUGAR, inmediatamente antes de lanzar Minecraft; no incluye archivos `.rpo` ni ZIP cuyo nombre diga `DO NOT ENABLE`. Si un pack es incompatible, Minecraft podría mostrar un aviso.
- **`datapacks/`**: se descargan como **copia local de referencia dentro de la instancia**, conservando su estructura. **Minecraft multijugador NO carga esos datapacks desde el cliente**: para que tengan efecto deben estar en el mundo del servidor (`world/datapacks`), activados en Crafty/servidor. El launcher no los instala en el servidor ni modifica mundos locales ajenos.

La comparación y descarga se realiza mediante EML Lib antes de iniciar Minecraft. La limpieza sigue desactivada (`cleaning.enabled=false`) para no borrar archivos personales, lo que significa que **archivos retirados de Drive pueden quedar instalados**. El manifiesto proporciona fecha modificada (`updated`) pero **no SHA1**, por lo que la detección de reemplazos del mismo tamaño o cambios de archivos no está garantizada. Google Drive puede bloquear descargas públicas grandes o intensivas. Verificá una instalación real antes de repartirlo.

## 4) Skin en las cuentas y lista online

- Al iniciar Microsoft, el launcher usa el UUID oficial de la sesión (si la biblioteca lo devuelve) para mostrar su cabeza. Alternativamente consulta la skin pública por nick; nunca expone tokens de sesión a la interfaz.
- Los jugadores en línea aparecen **solo si el servidor los publica en la respuesta de estado**; es una muestra, no una lista completa. Las cabezas se obtienen de servicios públicos (MCHeads / MCskin / Crafatar) con una cabeza pixelada genérica de respaldo si el jugador no tiene una skin pública disponible. En servidores con UUID offline se busca primero por nick; skins privadas de mods del servidor no son accesibles automáticamente.
- Invitado: ahora puede pulsar JUGAR con un nick (`allowGuest=true`) usando autenticación offline local; **el servidor debe permitir y proteger ese acceso**, o rechazará la conexión. El modo invitado no sustituye una licencia ni proporciona identidad oficial. Para el servidor, leé `CONFIGURAR_INVITADOS_SERVIDOR.md`. La skin del invitado sigue siendo genérica.

## 5) Nuevo acceso invitado (v0.9.4)

El modo invitado deja de estar bloqueado en el cliente. No se cambia `server.properties` ni los mods del servidor; para aceptar invitados hace falta preparar autenticación segura en Fabric. **Leé `CONFIGURAR_INVITADOS_SERVIDOR.md` y probá el servidor** antes de repartir los EXE.

## 6) El nick de invitado se recuerda automáticamente (v0.9.4)

- Cuando seleccionás **Invitado** e introducís un nick válido, el launcher lo guarda en `preferences.json` dentro de la carpeta de datos de usuario de Electron (en Windows, normalmente `%APPDATA%\chilly-willy-launcher` o la ruta equivalente del nombre de app).
- Al volver a abrir **el portable o el instalador en la misma PC y usuario de Windows**, se restablece automáticamente ese perfil, sin tener que escribir el nick de nuevo.
- **Cerrar sesión** elimina el nick guardado; iniciar sesión con Microsoft reemplaza la preferencia de invitado. No se guardan contraseñas ni tokens Microsoft.
- Si venías de 0.9.3, tendrás que introducir el nick **una última vez** en v0.9.4 para que quede guardado. Cambiar el nombre o la carpeta del `.exe` no debería eliminar los datos asociados a ese mismo perfil de Windows.
- Para actualizar a v0.9.4, hay que generar un nuevo portable/instalador: el `.exe` viejo no recibe actualizaciones de código desde Drive.

## 7) Configuración fija

- **Minecraft**: 1.21.1
- **Fabric Loader**: 0.20.1
- **Java**: 21 administrado automáticamente por EML
- **Servidor**: `146.181.33.25:25565`
- **Drive**: carpeta y Apps Script previamente indicados.
- **Icono**: `build/cobbleverse.ico` proviene del `.ico` entregado por el creador; también se usa en ventana, instalador y portable.

### Estado de pruebas

Pruebas unitarias y de sintaxis en entorno Linux. Pendiente comprobar: compilación NSIS/Portable de Windows con la GUI, Microsoft real, instalación de Java/Minecraft de cero, todos los archivos de Drive y arranque/conexión real. No lo distribuyas masivamente antes de esa prueba.

## 8) Corrección de Google Apps Script, incluida desde v0.9.3

Se amplió el tiempo máximo de espera a 90 s y se reintentan fallos temporales una vez. Lee `CAMBIOS_V0.9.4.md` para diagnóstico. Si Google Apps Script no es accesible en el navegador, el cliente no puede arreglar sus permisos.

## 9) Novedad v0.9.5 — resource packs automáticos

- Los `.zip` de `resourcepacks/` publicados en Drive se activan automáticamente en cada inicio del juego, **sin intervención del usuario**.
- Se omiten los archivos `.rpo` y ZIP con `DO NOT ENABLE` en el nombre (son recursos de créditos).
- Se modifica exclusivamente la entrada `resourcePacks:` de `options.txt` **de la instancia aislada de Cobbleverse**; se preservan sonido, teclas, gráficos y ajustes personales.
- Si publicás otro ZIP válido en la carpeta de Drive, aparecerá activado desde la siguiente ejecución tras actualizarse el manifiesto. No hace falta cambiar Apps Script si ya publica las cinco carpetas.
- Orden: los nuevos packs se agregan en orden alfabético; dentro de Minecraft, los packs colocados más arriba prevalecen. Si hay conflictos visuales entre paquetes, podría ser necesaria una prioridad específica o editar nombres.
- Paquetes que requieran versiones específicas de Minecraft o dependencias de mods pueden no cargar a pesar de seleccionarse; la activación no repara incompatibilidades.
- Para probar: generá el portable con `GENERAR_EXE.vbs`, iniciá el juego, abrí Minecraft → Opciones → Paquetes de recursos: deberían figurar en **Seleccionados**.

Las pruebas locales no sustituyen una ejecución completa del juego en Windows.

## 10) v0.9.6 — Controles de teclado de Cobbleverse

El modpack ya contiene `config/defaultoptions/keybindings.txt` y `config/defaultoptions/options.txt` (Default Options). La v0.9.6 aplica el preset al primer inicio y mantiene los cambios propios del jugador en futuros inicios. Esto se hace junto a la activación automática de resource packs, sobre el `options.txt` de la instancia aislada. Si ya existían controles personalizados al actualizar, se guarda una copia previa de `options.txt` en `options.txt.chilly-willy-before-keybindings.bak`. Ver `CAMBIOS_V0.9.6.md`.

## 11) v0.9.8 — Shaders automáticos

- Drive contiene `shaderpacks/COBBLEVERSE - Shaders/`, `shaderpacks/COBBLEVERSE - Shaders (High Quality)/` y `ComplementaryUnbound_r5.8.1.zip`.
- Este launcher elige la variante normal del shader Cobbleverse como predeterminada; también descarga High Quality como alternativa.
- Actualiza el archivo `config/iris.properties` antes de iniciar Minecraft si todavía no hay una elección manual de shader.
- No altera otras preferencias del usuario y guarda copia de respaldo de la configuración anterior.
- Para que EML descargue shaders, es **obligatorio reemplazar Code.gs y publicar una nueva versión** de la implementación Apps Script original.
- **Advertencia de rendimiento:** los dos packs personalizados están descomprimidos en Drive, con muchas carpetas y archivos; Google Drive y Apps Script podrían tardar demasiado o bloquear descargas masivas. Para rendimiento estable conviene volver a subir ambos como archivos ZIP dentro de shaderpacks/ y omitir las carpetas descomprimidas.
- **No se incluye un instalador compilado:** la compilación de Windows debe ejecutarse en un entorno que tenga acceso a Electron/electron-builder; si lo hacés en Windows, abrí `GENERAR_EXE.vbs`.


## v0.9.8
Ver `CAMBIOS_V0.9.11.md`: corrección de ajustes visuales, prioridad de resourcepacks y activación inicial de Iris.


### Actualizaciones del programa desde v0.9.16
La versión instalada (Setup NSIS) **avisa** cuando hay una actualización pública. Al pulsar **Actualizar** una vez, descarga el instalador en segundo plano, muestra el porcentaje y, una vez completado, sale brevemente, aplica NSIS en modo silencioso y vuelve a abrir el launcher. No se descarga ni instala sin ese clic. El Portable no ofrece actualizaciones automáticas. La transición desde 0.9.15 puede conservar el instalador interactivo anterior por ejecutarse su código instalado.
