import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {validateManifest} from '../electron/manifest-validator.mjs';
import {applyPackKeybindings} from '../electron/keybindings-options.mjs';
import {activateResourcePacks} from '../electron/resourcepack-options.mjs';
const url='https://drive.usercontent.google.com/download?id=abc123&export=download&confirm=t';
const f=(name,path,type='OTHER')=>({name,path,type,size:123,url});
const entries=[f('Cobblemon.jar','mods/','MOD'),f('client.json','config/cobblemon/'),f('COBBLEVERSE RP.zip','resourcepacks/'),f('PokeCenter.zip','datapacks/'),f('shaders.properties','shaderpacks/COBBLEVERSE - Shaders/shaders/'),f('options.txt','presets/'),f('riding_perspectives.json','cobblemon/'),f('fabricDefaultResourcePacks.dat','data/')];
test('manifiesto maestro seguro y completo',()=>{const m=validateManifest({version:5,source:'cobbleverse-master',files:entries});assert.equal(m.completeMaster,true);assert.equal(m.counts.presets,1);assert.equal(m.counts.cobblemon,1);assert.equal(m.counts.data,1);});
test('versión anterior no se confunde con instalación maestra',()=>{const m=validateManifest({version:4,files:entries.filter(x=>x.path!=='presets/')});assert.equal(m.completeMaster,false);});
test('evita distribuir saves o logs',()=>assert.throws(()=>validateManifest({version:5,files:[...entries,f('world.dat','saves/')]}),/no permitida/));
test('admite todos los resource packs incluso Xray y DO NOT ENABLE',()=>{
 const m=validateManifest({version:6,source:'cobbleverse-master',files:[...entries,f('Xray_Ultimate_26.X_v5.4.4.zip','resourcepacks/'),f('DO NOT ENABLE - Credits.zip','resourcepacks/')]});
 assert.equal(m.counts.resourcepacks,3);
 const script=fs.readFileSync(new URL('../apps-script/Code.gs',import.meta.url),'utf8');
 assert.doesNotMatch(script,/OMIT_RESOURCEPACKS/);
 assert.doesNotMatch(script,/\/do\[ _-\]\*not/);
});
test('evita otros archivos fuera de options.txt en presets',()=>assert.throws(()=>validateManifest({version:5,files:[...entries,f('tokens.txt','presets/')]}),/Preset no permitido/));
test('instalación limpia utiliza options.txt de la raíz maestra y orden oficial de resourcepacks',(t)=>{
 const root=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-master-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
 fs.mkdirSync(path.join(root,'presets'),{recursive:true});fs.mkdirSync(path.join(root,'config','defaultoptions'),{recursive:true});
 fs.writeFileSync(path.join(root,'presets','options.txt'),'version:3955\nguiScale:2\nresourcePacks:["vanilla","file/B.zip","file/A.zip"]\n');
 fs.writeFileSync(path.join(root,'config','defaultoptions','keybindings.txt'),'key_key.forward:key.keyboard.w\n'+Array.from({length:10},(_,i)=>`key_key.hotbar.${i}:key.keyboard.${i}`).join('\n'));
 const r=applyPackKeybindings(root);assert.equal(r.first,true);
 activateResourcePacks(root,[{name:'A.zip',path:'resourcepacks/'},{name:'B.zip',path:'resourcepacks/'}]);
 const text=fs.readFileSync(path.join(root,'options.txt'),'utf8');assert.match(text,/guiScale:2/);assert.match(text,/resourcePacks:\["vanilla","file\/B.zip","file\/A.zip"\]/);
});
test('script omite explícitamente carpetas personales',()=>{
 const script=fs.readFileSync(new URL('../apps-script/Code.gs',import.meta.url),'utf8');
 for(const name of ['mods','config','resourcepacks','shaderpacks','datapacks','defaultconfigs','cobblemon','data'])assert.ok(script.includes(`'${name}'`));
 for(const name of ['saves','logs','screenshots'])assert.ok(!/INCLUDED_FOLDERS[^;]*;/.test('') || !new RegExp(`'${name}'`).test(script.match(/const INCLUDED_FOLDERS = new Set\(\[([\s\S]*?)\]\)/)?.[1]||''));
});
