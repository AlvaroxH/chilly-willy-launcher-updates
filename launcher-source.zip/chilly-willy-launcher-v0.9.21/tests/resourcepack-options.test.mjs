import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { enabledPackIdsFromManifest, activateResourcePacks, ensurePriorityResourcePacks, ensureAllResourcePacks, priorityPackIds } from '../electron/resourcepack-options.mjs';
import { validateManifest } from '../electron/manifest-validator.mjs';

const rp = names => names.map(name => ({ name, path: 'resourcepacks/' }));
const packs = rp([
  'COBBLEVERSE RP.zip',
  'Fresh Animations.zip',
  'COBBLEVERSE Soundtrack.zip',
  'z DO NOT ENABLE z [CavsCobbleMons - Credits Only].zip',
  'Cobblemon Interface.zip.rpo',
  'Cobblemon Interface Modded.zip.rpo'
]);

test('activa todos los zip aunque digan DO NOT ENABLE, pero no los .rpo', () => {
  const ids = enabledPackIdsFromManifest(packs);
  assert.deepEqual(ids, ['file/COBBLEVERSE RP.zip', 'file/COBBLEVERSE Soundtrack.zip', 'file/Fresh Animations.zip', 'file/z DO NOT ENABLE z [CavsCobbleMons - Credits Only].zip']);
  assert.ok(ids.some(id => id.includes('DO NOT ENABLE')));
  assert.ok(ids.every(id => !id.endsWith('.rpo')));
});

test('rechaza subcarpetas, nombres no zip e inyeccion de rutas', () => {
  assert.deepEqual(enabledPackIdsFromManifest([
    ...rp(['Readme.txt', 'Evil\\..\\file.zip', 'foo/../../evil.zip']),
    { path: 'resourcepacks/sub/', name: 'sub.zip' },
    { path: 'resourcepacks/', name: 'Good.zip' }
  ]), ['file/Good.zip']);
});

test('instala options.txt inicial con la versión correcta y packs seleccionados', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chilly-rp-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const result = activateResourcePacks(dir, packs);
  assert.equal(result.enabledCount, 4);
  const text = fs.readFileSync(path.join(dir, 'options.txt'), 'utf8');
  assert.match(text, /^version:3955\n/);
  assert.deepEqual(JSON.parse(text.match(/^resourcePacks:(.+)$/m)[1]), enabledPackIdsFromManifest(packs));
  assert.deepEqual(JSON.parse(text.match(/^incompatibleResourcePacks:(.+)$/m)[1]), enabledPackIdsFromManifest(packs));
  assert.equal(activateResourcePacks(dir, packs).changed, false);
});

test('preserva volumen, teclas, fps, preferencias personales y añade packs nuevos en cada inicio', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chilly-rp-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  fs.writeFileSync(path.join(dir, 'options.txt'), [
    'version:3955', 'soundCategory_master:0.17', 'maxFps:143',
    'resourcePacks:["vanilla","fabric","file/MiPackPersonal.zip"]',
    'key_key.forward:key.keyboard.up', 'incompatibleResourcePacks:["file/Legacy.zip"]', ''
  ].join('\r\n'));
  const result = activateResourcePacks(dir, [...packs, ...rp(['New Pack.zip'])]);
  assert.equal(result.enabledCount, 5);
  const contents = fs.readFileSync(path.join(dir, 'options.txt'), 'utf8');
  assert.match(contents, /soundCategory_master:0\.17\r\n/);
  assert.match(contents, /key_key.forward:key.keyboard.up\r\n/);
  assert.match(contents, /maxFps:143\r\n/);
  assert.deepEqual(JSON.parse(contents.match(/^incompatibleResourcePacks:(.+)$/m)[1]), ['file/Legacy.zip',...enabledPackIdsFromManifest([...packs,...rp(['New Pack.zip'])])]);
  assert.deepEqual(JSON.parse(contents.match(/^resourcePacks:(.+)$/m)[1]), [
    'vanilla', 'fabric', 'file/MiPackPersonal.zip', ...enabledPackIdsFromManifest([...packs,...rp(['New Pack.zip'])])
  ]);
});

test('conserva DO NOT ENABLE manuales y habilita los ZIP oficiales con esa marca', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chilly-rp-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  fs.writeFileSync(path.join(dir, 'options.txt'), 'version:3955\nresourcePacks:["vanilla","file/z DO NOT ENABLE z [Credits Only].zip"]\n');
  const r=activateResourcePacks(dir, packs);
  assert.equal(r.enabledCount,4);
  assert.match(fs.readFileSync(path.join(dir, 'options.txt'),'utf8'), /DO NOT ENABLE/);
});

test('manifest seguro expone nombres de resourcepacks para activar y cuenta los modpacks', () => {
  const f=(name,path,type)=>({name,path,type,size:100,url:'https://drive.usercontent.google.com/download?id=abcdefghijklmn&export=download&confirm=t'});
  const data={version:3,files:[f('fabric-api.jar','mods/','MOD'),f('settings.json','config/','OTHER'),f('COBBLEVERSE RP.zip','resourcepacks/','OTHER'),f('COBBLEVERSE-DP.zip','datapacks/','OTHER')]};
  const checked=validateManifest(data);
  assert.equal(checked.fullPack,true);
  assert.deepEqual(checked.resourcepackFiles,[{name:'COBBLEVERSE RP.zip',path:'resourcepacks/'}]);
});

test('el proceso principal activa paquetes DESPUES de descargar y ANTES del spawn', () => {
  const main=fs.readFileSync(new URL('../electron/main.mjs', import.meta.url), 'utf8');
  const ix=main.indexOf("launcher.on('launch_launch'");
  assert.ok(ix>main.indexOf('new Launcher('));
  assert.match(main.slice(ix,ix+5000),/activateResourcePacks\(launcher\.config\.root, pack\.resourcepackFiles/);
  assert.match(main,/await launcher\.launch\(\)/);
});


test('pack prioritario del Pokémon se activa arriba del pack maestro, sin tocar sensibilidad', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(),'chilly-priority-'));
  t.after(() => fs.rmSync(root,{recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'presets'),{recursive:true});
  fs.mkdirSync(path.join(root,'resourcepacks'),{recursive:true});
  fs.writeFileSync(path.join(root,'resourcepacks','Chilly-Willy-Pokemon.zip'),Buffer.from('PK\x03\x04','binary'));
  fs.writeFileSync(path.join(root,'presets','options.txt'), 'version:3955\nresourcePacks:["vanilla","file/Cobbleverse.zip"]\n');
  fs.writeFileSync(path.join(root,'options.txt'), 'version:3955\nmouseSensitivity:0.43\nresourcePacks:["vanilla","file/MiPack.zip"]\n');
  const files = rp(['Cobbleverse.zip','Chilly-Willy-Pokemon.zip']);
  const result = activateResourcePacks(root, files, {priorityPackNames:['Chilly-Willy-Pokemon.zip']});
  assert.equal(result.enabledCount, 2);
  const data=fs.readFileSync(path.join(root,'options.txt'),'utf8');
  const order=JSON.parse(data.match(/^resourcePacks:(.+)$/m)[1]);
  assert.equal(order.at(-1),'file/Chilly-Willy-Pokemon.zip');
  assert.ok(order.indexOf('file/Cobbleverse.zip') < order.indexOf('file/Chilly-Willy-Pokemon.zip'));
  assert.match(data,/mouseSensitivity:0\.43/);
});

test('inicio rápido reactiva únicamente pack obligatorio, sin otros packs desactivados', t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(),'chilly-priority-'));
  t.after(() => fs.rmSync(root,{recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'resourcepacks'),{recursive:true});
  fs.writeFileSync(path.join(root,'resourcepacks','Chilly-Willy-Pokemon.zip'),Buffer.from([80,75,3,4]));
  const file=path.join(root,'options.txt');
  fs.writeFileSync(file,'version:3955\nkey_key.attack:key.mouse.left\nresourcePacks:["vanilla","file/Chilly-Willy-Pokemon.zip","file/Personal.zip"]\n');
  const selected=rp(['Chilly-Willy-Pokemon.zip','Desactivado.zip']);
  const result=ensurePriorityResourcePacks(root,selected,['Chilly-Willy-Pokemon.zip']);
  assert.equal(result.enabledCount,1);
  assert.equal(result.changed,true);
  const data=fs.readFileSync(file,'utf8');
  assert.match(data,/key_key.attack:key.mouse.left/);
  assert.deepEqual(JSON.parse(data.match(/^resourcePacks:(.+)$/m)[1]),['vanilla','file/Personal.zip','file/Chilly-Willy-Pokemon.zip']);
  assert.equal(ensurePriorityResourcePacks(root,selected,['Chilly-Willy-Pokemon.zip']).changed,false);
  assert.doesNotMatch(data,/Desactivado/);
});

test('no inventa packs ni reescribe preferencias cuando el ZIP todavía no fue subido', t => {
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-priority-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.writeFileSync(path.join(root,'options.txt'),'version:3955\nmouseSensitivity:0.9\n');
  const r=ensurePriorityResourcePacks(root,rp(['Chilly-Willy-Pokemon.zip']),['Chilly-Willy-Pokemon.zip']);
  assert.equal(r.changed,false);
  assert.deepEqual(r.missing,['Chilly-Willy-Pokemon.zip']);
  assert.equal(fs.readFileSync(path.join(root,'options.txt'),'utf8'),'version:3955\nmouseSensitivity:0.9\n');
  assert.deepEqual(priorityPackIds(rp(['COBBLEVERSE.zip']),['Chilly-Willy-Pokemon.zip']),[]);
});

test('bloquea nombres de paquetes maliciosos en la configuración', () => {
  assert.throws(() => priorityPackIds([],['../../otro.zip']));
  assert.deepEqual(priorityPackIds(rp(['z DO NOT ENABLE test.zip']),['z DO NOT ENABLE test.zip']),['file/z DO NOT ENABLE test.zip']);
});

test('main incluye la activación obligatoria también en inicio rápido', () => {
  const main=fs.readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
  const section=main.slice(main.indexOf("launcher.on('launch_launch'"));
  assert.match(section,/if \(fastLaunch\) [\s\S]*?ensureAllResourcePacks\(/);
});

test('inicio rápido fuerza todos los ZIP descargados sin tocar controles y conserva prioridades',t => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(),'chilly-all-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'resourcepacks'));
  for (const name of ['Regular.zip','z DO NOT ENABLE - Credits.zip','Chilly-Willy-Pokemon.zip'])
    fs.writeFileSync(path.join(root,'resourcepacks',name),Buffer.from([80,75,3,4]));
  fs.writeFileSync(path.join(root,'options.txt'), 'version:3955\nmouseSensitivity:0.35\nkey_key.jump:key.keyboard.space\nresourcePacks:["vanilla","file/Personal.zip"]\n');
  const files = rp(['Regular.zip','z DO NOT ENABLE - Credits.zip','Chilly-Willy-Pokemon.zip','Missing.zip']);
  const r = ensureAllResourcePacks(root,files,['Chilly-Willy-Pokemon.zip']);
  assert.equal(r.enabledCount,3);
  assert.deepEqual(r.missing,['Missing.zip']);
  const txt=fs.readFileSync(path.join(root,'options.txt'),'utf8');
  assert.match(txt,/mouseSensitivity:0.35/);
  assert.match(txt,/key_key.jump:key.keyboard.space/);
  const selected=JSON.parse(txt.match(/^resourcePacks:(.+)$/m)[1]);
  assert.ok(selected.includes('file/z DO NOT ENABLE - Credits.zip'));
  assert.equal(selected.at(-1),'file/Chilly-Willy-Pokemon.zip');
  assert.ok(!selected.includes('file/Missing.zip'));
  const approved=JSON.parse(txt.match(/^incompatibleResourcePacks:(.+)$/m)[1]);
  assert.ok(approved.includes('file/z DO NOT ENABLE - Credits.zip'));
  assert.equal(ensureAllResourcePacks(root,files,['Chilly-Willy-Pokemon.zip']).changed,false);
});
