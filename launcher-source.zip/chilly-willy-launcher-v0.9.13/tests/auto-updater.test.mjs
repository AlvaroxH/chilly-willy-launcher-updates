import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventEmitter } from 'node:events';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import { updaterSupported, createUpdateManager, updatePercent, UPDATE_REPOSITORY } from '../electron/auto-updates.mjs';
const pkg=JSON.parse(readFileSync(new URL('../package.json', import.meta.url),'utf8'));
test('Repositorio y proveedor de actualizaciones apuntan a AlvaroxH',()=>{
  assert.equal(UPDATE_REPOSITORY.owner, 'AlvaroxH');
  assert.equal(pkg.version,'0.9.13');
  assert.equal(pkg.build.publish[0].repo,'chilly-willy-launcher-updates');
  assert.equal(pkg.build.publish[0].owner,'AlvaroxH');
  assert.ok(pkg.dependencies['electron-updater']);
  assert.equal(pkg.build.appId,'com.cobbleverse.launcher');
  assert.match(pkg.scripts['build:win'],/--publish never/);
});
test('Updater solo activo en Setup empaquetado de Windows',()=>{
  assert.equal(updaterSupported({isPackaged:true},{},'win32'),true);
  assert.equal(updaterSupported({isPackaged:true},{PORTABLE_EXECUTABLE_FILE:'C:/Launcher.exe'},'win32'),false);
  assert.equal(updaterSupported({isPackaged:false},{},'win32'),false);
  assert.equal(updaterSupported({isPackaged:true},{},'linux'),false);
});
test('Descarga con progreso, instalada solo cuando el usuario lo elige',async()=>{
  let installs=0;
  let checkCalls=0;
  let block=false;
  const fake=new EventEmitter();
  fake.checkForUpdates=async()=>{checkCalls++;fake.emit('checking-for-update');fake.emit('update-available',{version:'0.9.11'});fake.emit('download-progress',{percent:61.2});fake.emit('update-downloaded',{version:'0.9.11'});};
  fake.quitAndInstall=()=>{installs++;};
  const states=[];
  const m=createUpdateManager({app:{isPackaged:true,getVersion:()=> '0.9.9'},platform:'win32',env:{},loadUpdater:async()=>fake,isBusy:()=>block,emit:s=>states.push(s)});
  await m.check();
  assert.equal(checkCalls,1);
  assert.equal(installs,0);
  assert.equal(m.getState().phase,'ready');
  assert.equal(m.getState().version,'0.9.11');
  assert.ok(states.some(s=>s.percent===61));
  await m.check({force:true});assert.equal(checkCalls,1);
  block=true;assert.throws(()=>m.install(),/Esperá/);
  block=false;assert.deepEqual(m.install(),{ok:true});assert.equal(installs,1);
});
test('Error no impide el juego, reintento manual posible',async()=>{
 const fake=new EventEmitter(); let calls=0;fake.checkForUpdates=async()=>{if(++calls===1)throw Error('offline');fake.emit('update-not-available');};fake.quitAndInstall=()=>{};
 const m=createUpdateManager({app:{isPackaged:true,getVersion:()=> '0.9.9'},platform:'win32',env:{},loadUpdater:async()=>fake});
 await m.check();assert.equal(m.getState().phase,'error');
 await m.check({force:true});assert.equal(m.getState().phase,'current');assert.equal(calls,2);
});
test('Porcentaje acotado y modo portable protegido',async()=>{
 assert.equal(updatePercent({percent:202}),100);
 assert.equal(updatePercent({percent:-5}),0);
 assert.equal(updatePercent({}),null);
 const m=createUpdateManager({app:{isPackaged:true},platform:'win32',env:{PORTABLE_EXECUTABLE_FILE:'launcher.exe'},loadUpdater:async()=>{throw Error('should not call')}});
 assert.equal((await m.check()).phase,'unsupported');
 assert.throws(()=>m.install(),/Todavía no hay/);
});
