import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const main = readFileSync(new URL('../electron/main.mjs', import.meta.url), 'utf8');
const ui = readFileSync(new URL('../ui/app.js', import.meta.url), 'utf8');

test('valida mods al abrir el launcher',()=>{
  assert.match(ui, /async function initializeLauncher\(\)/);
  assert.match(ui, /await checkModsManifest\(\)/);
  assert.match(ui, /initializeLauncher\(\);/);
});
test('reconsulta Drive antes de jugar',()=>{
  assert.match(main,/ipcMain\.handle\('launcher:play'/);
  assert.match(main,/const pack = await fetchManifest\(\)/);
});
test('Java 21 automático',()=>assert.match(main,/java: \{ install: 'auto' \}/));
test('acceso no bloqueado por comprobacion manual',()=>{
  assert.match(ui, /window\.cobble\.play\(\)/);
  assert.match(ui,/window\.cobble\.checkManifest\(\)/);
});
