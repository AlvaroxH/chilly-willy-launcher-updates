import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const text = (name) => readFileSync(new URL('../'+name,import.meta.url),'utf8');
test('Banner visible del auto-updater y botón en Ajustes',()=>{
  const html=text('ui/index.html');const app=text('ui/app.js');const css=text('ui/style.css');
  for(const id of ['updaterBanner','updaterTitle','updaterDescription','updaterTrack','updaterFill','updaterPrimary','updaterCheckBtn','updaterSettingsText']){
    assert.match(html,new RegExp(`id="${id}"`));
  }
  assert.match(html,/Instalar y reiniciar/);
  assert.match(app,/window\.cobble\.installUpdate\(\)/);
  assert.match(app,/window\.cobble\.checkUpdates\(\)/);
  assert.match(css,/\.updater-banner/);
});
test('IPC separa actualizaciones del juego vs programa',()=>{
  const main=text('electron/main.mjs');const pre=text('electron/preload.cjs');
  for(const channel of ['launcher:updates-state','launcher:check-updates','launcher:install-update','launcher:update-status']){
    assert.ok(main.includes(channel) || channel==='launcher:update-status');
    assert.ok(pre.includes(channel));
  }
  assert.match(main,/launcher\.on\('launch_launch'/);
  assert.match(main,/loadMicrosoftSession/);
});
