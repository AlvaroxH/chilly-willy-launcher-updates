// Auto-Updater para instaladores NSIS de Chilly Willy Launcher.
// GitHub Releases público: AlvaroxH/chilly-willy-launcher-updates.
// No lleva contraseñas ni tokens de GitHub dentro del ejecutable.
export const UPDATE_REPOSITORY = Object.freeze({owner: 'AlvaroxH', repo: 'chilly-willy-launcher-updates'});
export function updaterSupported(app, env = process.env, platform = process.platform) {
  return Boolean(app.isPackaged && platform === 'win32' && !env.PORTABLE_EXECUTABLE_FILE);
}
export function updatePercent(progress) {
  const value = Number(progress?.percent);
  return Number.isFinite(value) ? Math.max(0, Math.min(100, Math.round(value))) : null;
}
export function createUpdateManager({app, isBusy = () => false, emit = () => {}, env = process.env, platform = process.platform, loadUpdater = async () => {
  const mod = await import('electron-updater');
  return mod.autoUpdater ?? mod.default?.autoUpdater;
}}) {
  const supported = updaterSupported(app, env, platform);
  let updater = null;
  let initialized = false;
  let checking = null;
  let state = {
    phase: supported ? 'idle' : 'unsupported',
    supported,
    version: null,
    percent: null,
    message: supported ? 'Buscando actualizaciones en GitHub Releases…' :
      'La actualización automática funciona en el Setup instalado de Windows. En desarrollo o portable no está disponible.'
  };
  const send = (patch) => { state = {...state, ...patch}; emit({...state}); return {...state}; };
  async function setup() {
    if (!supported || initialized) return;
    const candidate = await loadUpdater();
    if (!candidate) throw new Error('No se pudo cargar electron-updater.');
    updater = candidate;
    updater.autoDownload = true;
    updater.autoInstallOnAppQuit = false; // Se instala al elegir explícitamente «Instalar y reiniciar».
    updater.allowPrerelease = false;
    updater.allowDowngrade = false;
    updater.on('checking-for-update', () => send({phase:'checking', message:'Buscando una actualización…', percent:null}));
    updater.on('update-available', (info) => send({phase:'downloading', version:info?.version ?? null,percent:0,message:`Nueva versión ${info?.version ?? ''}. Descargando…`}));
    updater.on('update-not-available', () => send({phase:'current',version:app.getVersion(),percent:null,message:`Estás usando la versión más reciente (${app.getVersion()}).`}));
    updater.on('download-progress', (info) => send({phase:'downloading',percent:updatePercent(info),message:'Descargando actualización del launcher…'}));
    updater.on('update-downloaded', (info) => send({phase:'ready',version:info?.version ?? state.version,percent:100,message:`Versión ${info?.version ?? 'nueva'} lista para instalar. Reiniciá cuando termines de jugar.`}));
    updater.on('error', (e) => {
      // Jamás mostrar claves ni URLs con credenciales.
      send({phase:'error',percent:null,message:'No se pudo consultar o descargar la actualización. Revisá tu conexión y que GitHub tenga una versión publicada con latest.yml.'});
      console.warn('Fallo de autoactualización:', e?.message ? String(e.message).slice(0,180) : 'error desconocido');
    });
    initialized = true;
  }
  return {
    getState: () => ({...state}),
    async check({force = false} = {}) {
      if (!supported) return {...state};
      if (state.phase === 'ready' || state.phase === 'downloading') return {...state};
      if (checking) return checking;
      if (!force && state.phase === 'current') return {...state};
      checking = (async () => {
        try {
          await setup();
          send({phase:'checking',percent:null,message:'Buscando actualizaciones en GitHub…'});
          await updater.checkForUpdates(); // autoDownload=true gestiona la descarga.
        } catch (e) {
          send({phase:'error',percent:null,message:'No se pudo consultar GitHub Releases. Comprobá tu conexión y que haya una Release estable con latest.yml.'});
          console.warn('Comprobación de actualización:', e?.message ? String(e.message).slice(0,180) : 'falló');
        } finally { checking = null; }
        return {...state};
      })();
      return checking;
    },
    install() {
      if (!supported || state.phase !== 'ready') throw new Error('Todavía no hay una actualización descargada para instalar.');
      if (isBusy()) throw new Error('Esperá a que termine de iniciar Minecraft antes de actualizar.');
      send({phase:'installing',message:'Cerrando el launcher para instalar la actualización…'});
      updater.quitAndInstall(false, true);
      return {ok: true};
    }
  };
}
