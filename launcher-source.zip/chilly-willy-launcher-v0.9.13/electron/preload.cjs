const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('cobble', {
  state: () => ipcRenderer.invoke('launcher:state'),
  serverStatus: () => ipcRenderer.invoke('launcher:server-status'),
  skinHead: (identity) => ipcRenderer.invoke('launcher:skin-head', identity),
  copyIp: () => ipcRenderer.invoke('launcher:copy-ip'),
  setMemory: (mb) => ipcRenderer.invoke('launcher:set-memory', mb),
  windowAction: (action) => ipcRenderer.invoke('launcher:window-action', action),
  loginMicrosoft: () => ipcRenderer.invoke('launcher:login-microsoft'),
  loginGuest: (name) => ipcRenderer.invoke('launcher:login-guest', name),
  logout: () => ipcRenderer.invoke('launcher:logout'),
  play: () => ipcRenderer.invoke('launcher:play'),
  checkManifest: () => ipcRenderer.invoke('launcher:check-manifest'),
  updatesState: () => ipcRenderer.invoke('launcher:updates-state'),
  checkUpdates: () => ipcRenderer.invoke('launcher:check-updates'),
  installUpdate: () => ipcRenderer.invoke('launcher:install-update'),
  onUpdate: (callback) => {
    const handler = (_event, data) => callback(data);
    ipcRenderer.on('launcher:update-status', handler);
    return () => ipcRenderer.removeListener('launcher:update-status', handler);
  },
  onProgress: (callback) => {
    const handler = (_event, data) => callback(data);
    ipcRenderer.on('launcher:progress', handler);
    return () => ipcRenderer.removeListener('launcher:progress', handler);
  }
});
