# Chilly Willy Launcher v0.9.19 — Preferencias personales + servidor en Multijugador

## Corregido

- El launcher ya NO vuelve a aplicar las opciones maestras sobre `options.txt` en cada sincronización completa.
- Se conserva la sensibilidad del mouse, las asignaciones de teclas, el sonido, el idioma, los gráficos y las demás opciones que el jugador ya haya configurado.
- Si el archivo `options.txt` no existe, se inicializa con los valores permitidos del modpack; si existe, solo se agregan claves que aún faltan.
- El preset `config/defaultoptions/keybindings.txt` ahora rellena teclas faltantes sin reemplazar controles personalizados preexistentes.
- La capa de sincronización de configuraciones conserva los archivos locales modificados en vez de reemplazarlos con el contenido de Drive. Los archivos locales intactos pueden recibir actualizaciones del modpack.

## Agregado

- Registro automático de `Chilly Willy | Cobbleverse` (`146.181.33.25:25565`) en `servers.dat`, la lista de servidores de Minecraft Multijugador.
- Funciona tanto en inicio rápido como en sincronización completa; no es necesario cerrar Minecraft después de desconectarse para encontrar el servidor.
- Evita entradas duplicadas (también detecta el mismo servidor con otro nombre), actualiza la IP si cambia una entrada oficial y preserva los demás servidores, iconos y metadatos NBT.
- Crea un respaldo `servers.dat.chilly-willy.bak` antes del primer cambio a una lista existente; si el archivo es inválido, no lo sobrescribe ni impide iniciar Minecraft.

## Compatibilidad y seguridad

- Continúa utilizando la instancia aislada `.cobbleverse` o su ubicación redirigida a otra unidad. No modifica el `.minecraft` global, los saves, los waypoints, los Pokémon ni las cuentas.
- Conserva inicio rápido `--quickPlayMultiplayer`, Discord Rich Presence, Fabric 1.21.1 y manifest v6 del Apps Script.
- No es necesario cambiar el servidor de Minecraft ni volver a desplegar Apps Script si el manifiesto v6 ya funciona.
- 152 tests automatizados aprobados en Node.js 22. No se ha validado aún el instalador real ni una sesión completa de Minecraft en Windows; probar antes de publicar.
- v0.9.19 es una actualización funcional del launcher, NO incluye todavía el rediseño de Launcher Studio/editor visual avanzado (trabajo pendiente).

## Importante para la prueba

1. Con Minecraft cerrado, instalar o iniciar la nueva versión del launcher.
2. En Minecraft modificar sensibilidad y una tecla; cerrar Minecraft por completo.
3. Volver a abrir con JUGAR, sin sincronización forzada y luego con una sincronización completa. Verificar que ambos valores sigan igual.
4. En Multijugador verificar la entrada `Chilly Willy | Cobbleverse`, salir del servidor SIN cerrar Minecraft y reingresar desde la lista.
5. No distribuir los nuevos ejecutables hasta completar estas pruebas con un usuario real.
