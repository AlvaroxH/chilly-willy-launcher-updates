const $ = (id) => document.getElementById(id);
let gameLocation = null;
let cfg = null;
let account = null;
let running = false;
let checking = false;
let manifestCheck = null;
let detectedJavaVersion = null;
let toastTimer;
let serverInfo = null;
let activeView = 'home';
let updateState = null;
let updateDismissed = false;

// Las imágenes públicas se resuelven en el proceso principal mediante proveedores
// alternativos. El UUID de un servidor offline puede NO ser el UUID Mojang;
// para jugadores del status se prioriza el nick. La UI no expone tokens.
function setAvatar(element, player) {
  element.replaceChildren();
  const fallback = document.createElement('img');
  fallback.src = './assets/skin-fallback.png';
  fallback.alt = 'Cabeza genérica de Minecraft';
  fallback.className = 'fallback-skin';
  element.append(fallback);
  const name = player?.name;
  element.title = name ? `Skin de ${name} (si está disponible públicamente)` : 'Avatar de jugador';
  const requestKey = [player?.type ?? '', player?.source ?? '', name ?? '', player?.uuid ?? ''].join(':');
  element.dataset.avatarKey = requestKey;
  if (!name || player?.type === 'guest') return; // No atribuir pieles oficiales al invitado.
  window.cobble.skinHead({ name, uuid: player?.uuid ?? null, type: player?.type ?? 'player', source: player?.source ?? 'server' })
    .then(dataUrl => {
      if (!dataUrl || element.dataset.avatarKey !== requestKey || !element.isConnected) return;
      const img = document.createElement('img');
      img.alt = `Cabeza de ${name}`;
      img.className = 'player-skin';
      img.onload = () => {
        if (element.dataset.avatarKey === requestKey && element.isConnected) element.replaceChildren(img);
      };
      img.onerror = () => {}; // Mantiene la cabeza genérica.
      img.src = dataUrl;
    }).catch(() => {}); // El launcher y la lista online siguen funcionando sin ese servicio.
}
const icon = (name) => `<svg aria-hidden="true"><use href="#i-${name}"/></svg>`;

function toast(message) {
  const el = $('toast');
  el.textContent = String(message);
  el.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.add('hidden'), 9000);
}
function status(message, percent) {
  $('statusText').textContent = message;
  if (Number.isFinite(percent)) {
    const value = Math.max(0, Math.min(100, percent));
    $('progressPct').textContent = `${value}%`;
    $('progressFill').style.width = `${value}%`;
  } else {
    $('progressPct').textContent = '';
    $('progressFill').style.width = '0%';
  }
}
function switchScreen(view) {
  activeView = view;
  for (const name of ['home', 'account', 'mods', 'news', 'settings', 'help']) {
    $(`screen-${name}`).classList.toggle('hidden', name !== view);
    $(`nav-${name}`).classList.toggle('active', name === view);
  }
  $('mainScroll').scrollTop = 0;
}
function paint() {
  const display = account?.name || 'aventurero';
  $('accountBadge').textContent = account ? display : 'Elegir cuenta';
  const avatarIdentity = account ? account.name + ':' + (account.uuid || '') : '';
  if ($('miniPlayerAvatar').dataset.identity !== avatarIdentity) {
    $('miniPlayerAvatar').dataset.identity = avatarIdentity;
    $('accountAvatar').dataset.identity = avatarIdentity;
    setAvatar($('miniPlayerAvatar'), account && {...account, source: 'account'});
    setAvatar($('accountAvatar'), account && {...account, source: 'account'});
  }
  $('welcomeName').textContent = display;
  $('loginOptions').classList.toggle('hidden', !!account);
  $('loggedIn').classList.toggle('hidden', !account);
  if (account) {
    $('playerName').textContent = account.name;
    $('playerType').textContent = account.type === 'microsoft' ? 'Cuenta Microsoft oficial' : 'Invitado · identidad no verificada';
  }
  $('loaderText').textContent = `Fabric ${cfg?.fabricLoaderVersion ?? '—'}`;
  $('javaText').textContent = detectedJavaVersion ? `Java ${detectedJavaVersion} · listo` : 'Java 21 · automático';
  $('serverText').textContent = cfg?.serverAddress || 'Sin configurar';
  $('manifestText').textContent = manifestCheck?.ok ? String(manifestCheck.count) : (checking ? '…' : '—');
  $('cardModText').textContent = manifestCheck?.ok
    ? (manifestCheck.completeMaster && manifestCheck.fullPack && manifestCheck.fullShaderPack ? `${manifestCheck.count} mods, recursos y shaders · ${manifestCheck.totalPackMiB} MiB.` : `${manifestCheck.count} mods. Falta el manifiesto maestro de Apps Script v5 para completar la instalación maestra.`)
    : checking ? 'Buscando actualizaciones en Drive…' : 'La comprobación se reintentará antes de jugar.';
  const guestBlocked = account?.type === 'guest' && !cfg?.allowGuest;
  $('playBtn').disabled = running;
  $('playLabel').textContent = running ? 'PREPARANDO…' : !account ? 'JUGAR AHORA' : guestBlocked ? 'ACCESO PROTEGIDO' : 'JUGAR AHORA';
  $('playBtn').title = guestBlocked ? 'El servidor debe permitir cuentas offline y proteger los nombres.' : !account ? 'Elegí una cuenta para jugar' : 'Abrir Minecraft';
  $('msBtn').disabled = running;
  $('guestBtn').disabled = running;
  $('logoutBtn').disabled = running;
  $('checkManifestBtn').disabled = running || checking || !cfg?.hasManifest;
  $('forceModpackSyncBtn').disabled = running;
  for (const b of document.querySelectorAll('[data-memory]')) {
    b.classList.toggle('active', Number(b.dataset.memory) === cfg?.memoryMb);
    b.disabled = running;
  }
}
async function operation(work) {
  if (running) return;
  running = true; paint();
  try { await work(); }
  catch (err) {
    const message = err?.message ?? String(err);
    toast(message);
    status(`Error: ${message}`);
  } finally { running = false; paint(); }
}
async function checkModsManifest(showSuccess = false) {
  if (checking) return;
  checking = true; paint();
  $('manifestDetails').textContent = 'Consultando listado en Google Drive…';
  try {
    const result = await window.cobble.checkManifest(showSuccess);
    manifestCheck = result;
    $('manifestDetails').textContent = result.fullPack
      ? `${result.counts.mods} mods · ${result.counts.config} config · ${result.counts.resourcepacks} resourcepacks · ${result.counts.datapacks} datapacks · ${result.counts.shaderpacks ?? 0} archivos de shaders (${result.totalPackMiB} MiB).`
      : `${result.count} mods detectados. FALTA publicar el Code.gs v0.9 en Apps Script para sincronizar las otras 3 carpetas.`;
    $('packFolderSummary').textContent = result.fullPack
      ? `mods/: ${result.counts.mods} · config/: ${result.counts.config} · resourcepacks/: ${result.counts.resourcepacks} · datapacks/: ${result.counts.datapacks} · shaderpacks/: ${result.counts.shaderpacks ?? 0}. Los datapacks solo afectan al servidor si están instalados en él.`
      : 'Pendiente: actualizar Code.gs y redeplegar la MISMA aplicación web para incluir config, resourcepacks y datapacks.';
    if (showSuccess) status(result.fullShaderPack ? 'Modpack y shaders comprobados.' : 'Falta publicar la nueva versión del manifiesto para incluir shaders.');
    return result;
  } catch (err) {
    manifestCheck = null;
    $('manifestDetails').textContent = `Error de consulta: ${err?.message || String(err)}. Se reintentará antes de jugar.`;
    if (showSuccess) throw err;
    return null;
  } finally { checking = false; paint(); }
}

function renderServerInfo(info) {
  serverInfo = info;
  const online = info?.online === true;
  const dotClass = online ? 'online' : 'offline';
  $('serverLed').className = `status-indicator ${dotClass}`;
  $('topConnection').replaceChildren();
  const dot = document.createElement('span'); dot.className = `status-indicator ${dotClass}`;
  $('topConnection').append(dot, document.createTextNode(online ? 'Servidor online' : 'Servidor sin respuesta'));
  $('serverStatusText').textContent = online ? 'En línea' : 'Sin respuesta';
  $('serverPing').textContent = online && Number.isFinite(info.latencyMs) ? `${info.latencyMs} ms` : '—';
  $('heroServerText').textContent = online ? 'EN LÍNEA' : 'SIN RESPUESTA';
  $('heroServerCaption').textContent = online ? `${info.playersOnline} / ${info.playersMax} jugadores` : 'Intentá más tarde';
  const led = document.querySelector('.hero-stat .led');
  led.className = `led ${dotClass}`;
  $('playerCount').textContent = online ? String(info.playersOnline) : '—';
  $('populationProgress').style.width = online && info.playersMax > 0
    ? `${Math.max(0, Math.min(100, Math.round(100 * info.playersOnline / info.playersMax)))}%` : '0%';
  const list = $('onlinePlayerList'); list.replaceChildren();
  if (!online) {
    const empty = document.createElement('div'); empty.className = 'empty-state';
    empty.innerHTML = `${icon('server')}<p>El servidor no respondió al consultar su estado.</p>`;
    list.append(empty);
    $('sampleCaption').textContent = 'No disponible';
    return;
  }
  if (!info.sample?.length) {
    const empty = document.createElement('div'); empty.className = 'empty-state';
    empty.innerHTML = `${icon('users')}<p>El servidor no comparte la lista de nombres.</p>`;
    list.append(empty);
    $('sampleCaption').textContent = `${info.playersOnline} conectados`;
    return;
  }
  $('sampleCaption').textContent = `Mostrando ${info.sample.length}`;
  for (const player of info.sample) {
    const nickname = typeof player === 'string' ? player : player.name;
    const row = document.createElement('div'); row.className = 'online-player';
    const avatar = document.createElement('div'); avatar.className = 'player-pixel'; setAvatar(avatar, typeof player === 'string' ? { name: player, source: 'server' } : {...player, source: 'server'});
    const label = document.createElement('strong'); label.textContent = nickname;
    const onlineLed = document.createElement('span'); onlineLed.className = 'player-on';
    row.append(avatar, label, onlineLed); list.append(row);
  }
}
async function updateServerInfo() {
  if (!cfg?.serverAddress) return;
  try { renderServerInfo(await window.cobble.serverStatus()); }
  catch { renderServerInfo({ online: false }); }
}

for (const b of document.querySelectorAll('[data-screen]')) {
  b.addEventListener('click', () => switchScreen(b.dataset.screen));
}
$('heroAccountBtn').addEventListener('click', () => switchScreen('account'));
$('openNewsBtn').addEventListener('click', () => switchScreen('news'));
$('openModsSide').addEventListener('click', () => switchScreen('mods'));
$('openHelpSide').addEventListener('click', () => switchScreen('help'));
$('statusDetailsButton').addEventListener('click', () => switchScreen('mods'));
$('msBtn').addEventListener('click', () => operation(async () => {
  status('Abriendo Microsoft…');
  account = await window.cobble.loginMicrosoft();
  paint(); switchScreen('home');
  status(`¡Listo, ${account.name}! Ya podés pulsar JUGAR.`);
}));
$('guestBtn').addEventListener('click', () => operation(async () => {
  account = await window.cobble.loginGuest($('guestName').value);
  paint(); switchScreen('home');
  toast('Nick invitado guardado en esta PC. La próxima vez el launcher lo recordará. El servidor debe aceptar invitados para poder entrar.');
}));
$('guestName').addEventListener('keydown', (event) => { if (event.key === 'Enter') $('guestBtn').click(); });
$('logoutBtn').addEventListener('click', () => operation(async () => {
  await window.cobble.logout(); account = null;
  paint(); status('Sesión desconectada. Elegí una cuenta para volver a jugar.');
}));
$('playBtn').addEventListener('click', () => {
  if (!account) { switchScreen('account'); toast('Primero seleccioná Microsoft o Invitado.'); return; }
  if (account.type === 'guest' && !cfg?.allowGuest) {
    toast('El modo invitado no está disponible en esta instalación del launcher.');
    switchScreen('account'); return;
  }
  operation(async () => { status('Comprobando archivos e iniciando Minecraft…'); await window.cobble.play(); });
});
$('forceModpackSyncBtn').addEventListener('click', () => operation(async () => {
  const result = await window.cobble.forceModpackSync();
  toast(result.message);
  status('Próximo inicio: revisión completa del modpack.');
}));
$('checkManifestBtn').addEventListener('click', () => operation(async () => {
  await checkModsManifest(true);
}));
$('communityPlayersTab').addEventListener('click', () => {
  $('communityPlayers').classList.remove('hidden'); $('communityInfo').classList.add('hidden');
  $('communityPlayersTab').classList.add('active'); $('communityInfoTab').classList.remove('active');
});
$('communityInfoTab').addEventListener('click', () => {
  $('communityPlayers').classList.add('hidden'); $('communityInfo').classList.remove('hidden');
  $('communityPlayersTab').classList.remove('active'); $('communityInfoTab').classList.add('active');
});
$('copyIpBtn').addEventListener('click', async () => {
  try { await window.cobble.copyIp(); toast('IP de Cobbleverse copiada.'); }
  catch (e) { toast(e?.message || 'No se pudo copiar la IP.'); }
});
for (const b of document.querySelectorAll('[data-memory]')) {
  b.addEventListener('click', () => operation(async () => {
    const updated = await window.cobble.setMemory(Number(b.dataset.memory));
    cfg.memoryMb = updated.memoryMb;
    $('memoryHint').textContent = `Guardado: ${cfg.memoryMb / 1024} GB para Minecraft. Dejá RAM libre para Windows.`;
    paint();
  }));
}
function refreshLocationDisplay(location) {
  gameLocation = location;
  $('gameLocationPath').textContent = location?.path || 'Carpeta no disponible';
  $('gameLocationHint').textContent = location?.cleanupNeeded
    ? `Los archivos nuevos están en el disco elegido. El anterior quedó en: ${location.oldLocation}; verificá el juego antes de borrar ese respaldo.`
    : (location?.custom ? 'Minecraft está en la carpeta elegida. Los archivos nuevos se descargarán allí.' : 'Ubicación predeterminada de Minecraft. Se puede cambiar sin descargar todo otra vez.');
  $('chooseGameLocationBtn').disabled = running;
  $('firstRunLocation').classList.toggle('hidden', Boolean(location?.installed || location?.acknowledged));
}
async function selectMinecraftDirectory() {
  if (running) return;
  running = true; paint();
  $('chooseGameLocationBtn').disabled = true;
  $('firstRunChooseGameLocation').disabled = true;
  try {
    const result = await window.cobble.chooseGameLocation();
    if (result.cancelled) return;
    refreshLocationDisplay(result);
    if (result.warning) toast(result.warning);
    else toast('La carpeta de Minecraft se cambió correctamente.');
  } catch (err) {
    toast(err?.message || String(err));
  } finally {
    running = false; paint();
    $('chooseGameLocationBtn').disabled = false;
    $('firstRunChooseGameLocation').disabled = false;
  }
}
$('chooseGameLocationBtn').addEventListener('click', selectMinecraftDirectory);
$('firstRunChooseGameLocation').addEventListener('click', selectMinecraftDirectory);
$('firstRunUseDefault').addEventListener('click', async () => {
  try {
    await window.cobble.useDefaultGameLocation();
    refreshLocationDisplay(await window.cobble.gameLocation());
  } catch (err) { toast(err?.message || String(err)); }
});
$('minimizeWindow').addEventListener('click', () => window.cobble.windowAction('minimize'));
$('maximizeWindow').addEventListener('click', () => window.cobble.windowAction('maximize'));
$('closeWindow').addEventListener('click', () => window.cobble.windowAction('close'));
// Estado de actualizaciones del programa. Nunca mezcla la barra con las descargas de mods.
function renderLauncherUpdate(state) {
  updateState = state;
  if (!state) return;
  const phase = state.phase;
  const banner = $('updaterBanner');
  const active = ['available', 'downloading', 'ready', 'installing', 'error'].includes(phase);
  const showBanner = active && (!updateDismissed || ['downloading', 'ready', 'installing'].includes(phase));
  banner.classList.toggle('hidden', !showBanner);
  $('updaterTitle').textContent = phase === 'available' ? `Nueva versión ${state.version || ''} disponible` :
    phase === 'downloading' ? `Actualizando Chilly Willy ${state.version || ''}` :
    phase === 'ready' ? 'Descarga completa' :
    phase === 'installing' ? 'Aplicando actualización…' :
    phase === 'error' ? 'No se pudo completar la actualización' : 'Actualizaciones del launcher';
  $('updaterDescription').textContent = state.message || '';
  const hasProgress = ['downloading', 'ready', 'installing'].includes(phase) && Number.isFinite(state.percent);
  const value = hasProgress ? Math.max(0, Math.min(100, Math.round(state.percent))) : 0;
  $('updaterTrack').classList.toggle('hidden', !hasProgress);
  $('updaterFill').style.width = `${value}%`;
  $('updaterTrack').setAttribute('aria-valuenow', String(value));
  $('updaterPercent').textContent = `${value}%`;
  $('updaterPercent').classList.toggle('hidden', !hasProgress);
  const btn = $('updaterPrimary');
  btn.textContent = phase === 'available' ? 'Actualizar' :
    phase === 'ready' ? 'Finalizar actualización' :
    phase === 'error' ? 'Reintentar' :
    phase === 'installing' ? 'Reiniciando…' : 'Descargando…';
  btn.disabled = !['available', 'ready', 'error'].includes(phase) || (['available','ready'].includes(phase) && running);
  $('updaterDismiss').disabled = ['downloading', 'ready', 'installing'].includes(phase);
  $('updaterDismiss').classList.toggle('hidden', ['downloading', 'ready', 'installing'].includes(phase));
  $('updaterSettingsText').textContent = state.message || 'Comprobando versión del launcher…';
  $('updaterCheckBtn').disabled = !state.supported || ['checking', 'available', 'downloading', 'ready', 'installing'].includes(phase);
}
window.cobble.onUpdate((next) => {
  if (['available', 'downloading', 'ready'].includes(next.phase) && updateState?.phase !== next.phase) updateDismissed = false;
  renderLauncherUpdate(next);
});
$('updaterPrimary').addEventListener('click', async () => {
  try {
    if (['available', 'ready'].includes(updateState?.phase)) await window.cobble.installUpdate();
    else if (updateState?.phase === 'error') { updateDismissed = false; await window.cobble.checkUpdates(); }
  } catch (e) { toast(e?.message || String(e)); }
});
$('updaterDismiss').addEventListener('click', () => {
  if (['downloading', 'ready', 'installing'].includes(updateState?.phase)) return;
  updateDismissed = true;
  $('updaterBanner').classList.add('hidden');
});
$('discordPresenceToggle').addEventListener('change', async (event) => {
  const requested = Boolean(event.target.checked);
  try {
    const state = await window.cobble.setDiscordPresence(requested);
    $('discordPresenceHint').textContent = state.enabled
      ? 'Discord Rich Presence activado. Discord Desktop debe estar abierto y permitir compartir actividad.'
      : 'Discord Rich Presence desactivado. No se publicará actividad del launcher.';
  } catch (error) {
    event.target.checked = !requested;
    toast(error?.message || String(error));
  }
});
$('updaterCheckBtn').addEventListener('click', async () => {
  try { updateDismissed = false; renderLauncherUpdate(await window.cobble.checkUpdates()); }
  catch (e) { toast(e?.message || String(e)); }
});
window.cobble.onProgress(({ message, percent, javaVersion }) => {
  if (javaVersion) { detectedJavaVersion = javaVersion; paint(); }
  status(message, percent);
});

async function initializeLauncher() {
  try {
    renderLauncherUpdate(await window.cobble.updatesState());
    cfg = await window.cobble.state();
    $('discordPresenceToggle').checked = cfg.discordPresenceEnabled !== false;
    refreshLocationDisplay(await window.cobble.gameLocation());
    account = cfg.account;
    if (cfg.savedGuestName) $('guestName').value = cfg.savedGuestName;
    paint();
    $('memoryHint').textContent = `Asignación actual: ${cfg.memoryMb / 1024} GB. Dejá memoria libre para Windows.`;
    status('Revisando actualizaciones de Cobbleverse…');
    // No bloqueamos la lectura del estado online mientras Drive responde.
    void updateServerInfo();
    if (cfg.hasManifest) await checkModsManifest();
    status(manifestCheck?.ok
      ? (manifestCheck.completeMaster && manifestCheck.fullPack && manifestCheck.fullShaderPack ? 'Cobbleverse listo. JUGAR usará los archivos locales si no hay cambios.' : 'Falta el manifiesto maestro de Apps Script v6.')
      : 'No se pudo comprobar Drive. Se reintentará antes de jugar.');
    setInterval(() => { if (!document.hidden) void updateServerInfo(); }, 60000);
  } catch (e) { toast(e?.message || String(e)); status('Error al iniciar el launcher.'); }
}
initializeLauncher();
