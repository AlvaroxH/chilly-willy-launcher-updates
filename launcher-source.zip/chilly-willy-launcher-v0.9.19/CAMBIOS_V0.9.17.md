# Chilly Willy Launcher 0.9.17 — Fabric 1.21.1

- **Cada clic en JUGAR** consulta el manifiesto remoto real de Google Drive antes de lanzar Java. No reutiliza la consulta guardada en el botón Jugar.
- Si el manifiesto es idéntico al paquete ya instalado, continúa con inicio rápido sin descargar todo otra vez.
- Si hay archivos nuevos, sustituidos o faltantes, ejecuta sincronización integral antes de jugar.
- Si un mod oficial desaparece de Drive, se retira de `mods/` **sólo** si estaba en el inventario anterior guardado por el launcher y coincide su tamaño, y **sólo después** de verificar que todos los mods actuales están descargados. Se mueve a `.chilly-willy/removed-mods/` dentro de Minecraft como respaldo; los mods personales se conservan.
- Si Drive no responde, devuelve una lista incompleta o falla la sincronización, no elimina ningún mod. Ante caída remota puede seguir jugando con el modpack local completo anterior.
- Las sincronizaciones completas reponen las opciones maestras, perfiles de Xaero, FancyMenu y pantalla de carga, conservando datos privados y respaldo de configuraciones anteriores.
- Mantiene Fabric 1.21.1, iconos del pingüino/C, ubicaciones personalizadas y actualizador silencioso.
- No modifica mundos, Pokémon, mapas explorados, waypoints, estadísticas ni logros.

## Notas

La eliminación automática de mods retirados necesita un inventario local previo. Si algún jugador nunca completó una sincronización con Chilly Willy que guardara ese inventario, sus .jar antiguos no identificados se conservarán por seguridad.

**No requiere redeplegar Apps Script** si ya devuelve el manifiesto maestro v6 completo. Publicar el ZIP del launcher no cambia por sí solo los mods de Drive ni el servidor Fabric.

Probar primero con release en borrador; los tests unitarios no verifican por sí solos el ejecutable de Windows.
