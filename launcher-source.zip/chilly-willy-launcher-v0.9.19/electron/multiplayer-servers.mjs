/**
 * Añade Cobbleverse a Minecraft Multijugador (servers.dat, NBT comprimido).
 * Mantiene INTACTOS los demás servidores, iconos, estados y etiquetas NBT.
 * Funciona sin dependencias externas y también con instancias en otra unidad.
 */
import fs from 'node:fs';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';

const MAX_FILE = 8 * 1024 * 1024;
const MAX_NBT = 16 * 1024 * 1024;
const MAX_ITEMS = 50000;
const SERVER_NAME = 'Chilly Willy | Cobbleverse';
const ADDRESS = /^[a-zA-Z0-9._-]+(?::\d{1,5})?$/;

function word(text) {
  const b = Buffer.from(text, 'utf8');
  if (b.length > 65535) throw new Error('Cadena de servidor demasiado larga.');
  const out = Buffer.alloc(2 + b.length);
  out.writeUInt16BE(b.length, 0);
  b.copy(out, 2);
  return out;
}
function int(n) {const b = Buffer.alloc(4); b.writeInt32BE(n); return b;}
function namedString(name, value) {return Buffer.concat([Buffer.from([8]), word(name), word(value)]);}
function record(name, ip) {return Buffer.concat([namedString('name', name), namedString('ip', ip), Buffer.from([0])]);}
function list(name, ip) {return Buffer.concat([Buffer.from([9]), word('servers'), Buffer.from([10]), int(1), record(name,ip)]);}
function fresh(name, ip) {return Buffer.concat([Buffer.from([10]), word(''), list(name,ip), Buffer.from([0])]);}
function sameIP(ip) {
  const s = String(ip).trim().toLowerCase();
  return s.endsWith(':25565') ? s.slice(0,-6) : s;
}

/** Interpreta y valida longitudes antes de permitir modificar un archivo NBT. */
class NbtReader {
  constructor(bytes) {this.bytes = bytes; this.pos = 0; this.visits = 0;}
  require(n) {if (!Number.isSafeInteger(n) || n < 0 || n > this.bytes.length - this.pos) throw new Error('servers.dat contiene NBT truncado o inválido.');}
  u8() {this.require(1); return this.bytes[this.pos++];}
  u16() {this.require(2); const n=this.bytes.readUInt16BE(this.pos); this.pos+=2; return n;}
  i32() {this.require(4); const n=this.bytes.readInt32BE(this.pos); this.pos+=4; return n;}
  skip(n) {this.require(n); this.pos+=n;}
  str() {const length=this.u16();this.require(length);const value=this.bytes.toString('utf8',this.pos,this.pos+length);this.pos+=length;return value;}
  payload(type, depth = 0) {
    if (depth > 48 || ++this.visits > MAX_ITEMS) throw new Error('servers.dat contiene NBT demasiado complejo.');
    switch (type) {
      case 1: this.skip(1);break;
      case 2: this.skip(2);break;
      case 3: case 5: this.skip(4);break;
      case 4: case 6: this.skip(8);break;
      case 7: this.skipArray(1);break;
      case 8: this.str();break;
      case 9: {
        const typeInner=this.u8(), count=this.i32();
        if (count < 0 || count > MAX_ITEMS || (typeInner===0 && count!==0)) throw new Error('Lista NBT inválida.');
        for (let i=0;i<count;i++) this.payload(typeInner,depth+1);
        break;
      }
      case 10: {
        for (;;) {
          const kind=this.u8();if(kind===0)break;
          this.str();this.payload(kind,depth+1);
        }
        break;
      }
      case 11: this.skipArray(4);break;
      case 12: this.skipArray(8);break;
      default: throw new Error('Tipo de etiqueta NBT inválido.');
    }
  }
  skipArray(size) {const count=this.i32(); if (count < 0 || count > MAX_NBT/size) throw new Error('Array NBT inválido.');this.skip(count*size);}
  serverEntry() {
    let name = null, ip = null, ipSpan = null;
    for (;;) {
      const type = this.u8();
      if (type===0) break;
      const field = this.str();
      if (type===8 && (field==='name' || field==='ip')) {
        const from=this.pos;
        const value=this.str();
        if (field==='name') name=value;
        else {ip=value;ipSpan={from,to:this.pos};}
      } else this.payload(type, 1);
    }
    return {name,ip,ipSpan};
  }
  inspect() {
    if (this.u8()!==10) throw new Error('servers.dat no contiene un compuesto NBT raíz.');
    this.str();
    let serverList=null;
    for (;;) {
      const type=this.u8();
      if (type===0) break;
      const name=this.str();
      if (name==='servers') {
        if (serverList || type!==9) throw new Error('servers.dat tiene una lista servers inválida.');
        const inner=this.u8();
        const countAt=this.pos;
        const count=this.i32();
        if (count < 0 || count > MAX_ITEMS || (inner!==10 && !(inner===0 && count===0))) throw new Error('Lista servers de tipo incompatible.');
        const entries=[];
        for(let i=0;i<count;i++) entries.push(this.serverEntry());
        serverList={count,countAt,end:this.pos,entries,emptyType:inner===0};
      } else this.payload(type,1);
    }
    if (this.pos !== this.bytes.length) throw new Error('servers.dat tiene datos inesperados al final.');
    return {serverList, rootEnd:this.pos-1};
  }
}
function insert(bytes, pos, value) {return Buffer.concat([bytes.subarray(0,pos),value,bytes.subarray(pos)]);}
function edit(bytes, info, name, ip) {
  if (!info.serverList) return {data:insert(bytes,info.rootEnd,list(name,ip)),status:'added'};
  const collection=info.serverList;
  if (collection.entries.some(x=>x.ip!==null && sameIP(x.ip)===sameIP(ip))) return {data:bytes,status:'existing'};
  const owned=collection.entries.find(x=>x.name===name && x.ipSpan);
  if (owned) {
    const {from,to}=owned.ipSpan;
    return {data:Buffer.concat([bytes.subarray(0,from),word(ip),bytes.subarray(to)]),status:'updated'};
  }
  if(collection.count>=MAX_ITEMS)throw new Error('La lista de servidores está llena.');
  const next=insert(bytes,collection.end,record(name,ip));
  // La longitud de la lista se encuentra antes del punto de inserción.
  if (collection.emptyType) next[collection.countAt-1]=10;
  next.writeInt32BE(collection.count+1,collection.countAt);
  return {data:next,status:'added'};
}
function atomic(file, bytes) {
  const temp=file+`.chilly-${process.pid}-${Date.now()}.tmp`;
  try{fs.writeFileSync(temp,bytes,{flag:'wx'});fs.renameSync(temp,file);}
  finally{try{fs.unlinkSync(temp);}catch{}}
}

export function ensureCobbleverseServer(instanceRoot, serverAddress, serverName = SERVER_NAME) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('La instancia de Minecraft no tiene una ruta válida.');
  const port = typeof serverAddress === 'string' && serverAddress.includes(':') ? Number(serverAddress.split(':')[1]) : 25565;
  if (typeof serverAddress !== 'string' || !ADDRESS.test(serverAddress) || !Number.isInteger(port) || port < 1 || port > 65535) throw new Error('La dirección del servidor no es válida.');
  if (typeof serverName !== 'string' || !serverName.trim() || Buffer.byteLength(serverName,'utf8')>120) throw new Error('Nombre de servidor inválido.');
  const file=path.join(instanceRoot,'servers.dat');
  if(fs.existsSync(file)&&fs.lstatSync(file).isSymbolicLink())throw new Error('servers.dat no puede ser un enlace simbólico.');
  const exists=fs.existsSync(file);
  let bytes, gzip=true;
  if(exists) {
    const st=fs.statSync(file);
    if(!st.isFile()||st.size>MAX_FILE)throw new Error('servers.dat no es un archivo válido.');
    const raw=fs.readFileSync(file);
    gzip=raw[0]===0x1f && raw[1]===0x8b;
    try {bytes=gzip?gunzipSync(raw,{maxOutputLength:MAX_NBT}):raw;}
    catch {throw new Error('servers.dat está dañado; no fue modificado.');}
  } else bytes=fresh(serverName,serverAddress);
  if(bytes.length>MAX_NBT)throw new Error('servers.dat excede el tamaño seguro.');
  const info=new NbtReader(bytes).inspect();
  const result=exists?edit(bytes,info,serverName,serverAddress):{data:bytes,status:'added'};
  if(result.status==='existing')return {status:'existing',file,backup:null};
  const packed=gzipSync(result.data);
  if(packed.length>MAX_FILE)throw new Error('servers.dat es demasiado grande para guardarse.');
  fs.mkdirSync(instanceRoot,{recursive:true});
  let backup=null;
  if(exists) {
    backup=file+'.chilly-willy.bak';
    if(!fs.existsSync(backup)) fs.copyFileSync(file,backup,fs.constants.COPYFILE_EXCL);
  }
  atomic(file,packed);
  return {status:result.status,file,backup};
}
