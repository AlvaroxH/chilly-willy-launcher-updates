/**
 * Retira sólo .jar que el launcher había instalado previamente y que el
 * manifiesto REMOTO válido ya no contiene. Nunca escanea/borrar "extras".
 * Las copias de seguridad quedan FUERA de mods/ pero en el mismo disco.
 * Este módulo no consulta Internet: sólo acepta un manifiesto ya validado.
 */
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const JAR = /^[^\\/:*?"<>|\x00-\x1f]{1,230}\.jar$/i;
const MAX_MANAGED = 2000;
const valid = files => Array.isArray(files) && files.length <= MAX_MANAGED && files.every(
  f => f && typeof f.name === 'string' && JAR.test(f.name) &&
    f.name !== '.' && f.name !== '..' && Number.isSafeInteger(f.size) && f.size > 0
);

function actualFile(filename, expectedSize) {
  try {
    const stat = fs.lstatSync(filename);
    return stat.isFile() && !stat.isSymbolicLink() && stat.size === expectedSize;
  } catch {return false;}
}

export function retireRemovedManagedMods({instanceRoot, previousCache, currentPack, settings}) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) {
    throw new Error('Ruta de Minecraft no confiable: no se eliminarán mods.');
  }
  if (!currentPack?.fullPack || !currentPack?.completeMaster || !currentPack?.fullShaderPack ||
      currentPack?.version < 6 || !valid(currentPack.modFiles) || currentPack.modFiles.length === 0) {
    throw new Error('Manifiesto nuevo incompleto: no se eliminarán mods.');
  }
  const modsDir = path.join(instanceRoot, 'mods');
  const modsStat = fs.lstatSync(modsDir);
  if (!modsStat.isDirectory() || modsStat.isSymbolicLink()) {
    throw new Error('La carpeta mods no es segura: no se eliminarán mods.');
  }
  // Verificar todos los mods activos ANTES de retirar cualquiera anterior.
  // Si Google Drive o EML dejaron una descarga incompleta, abortar sin pérdidas.
  for (const mod of currentPack.modFiles) {
    if (!actualFile(path.join(modsDir, mod.name),mod.size)) {
      throw new Error(`La descarga de ${mod.name} no está íntegra. Se conservan los mods antiguos.`);
    }
  }
  const removed = [], preserved = [];
  // Sólo un estado previo exitoso tiene permiso para identificar mods anteriores.
  const old = previousCache?.pack?.modFiles;
  if (!valid(old) || !old.length || !previousCache?.instanceRoot ||
      path.resolve(previousCache.instanceRoot).toLowerCase() !== path.resolve(instanceRoot).toLowerCase() ||
      previousCache?.settings?.modpackManifestUrl !== settings?.modpackManifestUrl ||
      previousCache?.settings?.minecraftVersion !== settings?.minecraftVersion ||
      previousCache?.settings?.fabricLoaderVersion !== settings?.fabricLoaderVersion) {
    return {removed, preserved, reason: 'sin inventario anterior compatible'};
  }
  const currentNames = new Set(currentPack.modFiles.map(f => f.name.toLowerCase()));
  const toRemove = old.filter(f => !currentNames.has(f.name.toLowerCase()));
  if (!toRemove.length) return {removed, preserved};
  // No dejar un archivo en mods con extensión .jar y nombre de backup. Se mueven
  // atomícamente a otra carpeta (mismo disco que Minecraft) y se pueden recuperar.
  const quarantine = path.join(instanceRoot, '.chilly-willy', 'removed-mods',
    new Date().toISOString().replace(/[:.]/g, '-') + '-' + randomUUID().slice(0,8));
  if (fs.existsSync(path.join(instanceRoot,'.chilly-willy')) &&
      fs.lstatSync(path.join(instanceRoot,'.chilly-willy')).isSymbolicLink()) {
    throw new Error('Ruta de copia de seguridad insegura: no se eliminarán mods.');
  }
  if (fs.existsSync(path.join(instanceRoot,'.chilly-willy','removed-mods')) &&
      fs.lstatSync(path.join(instanceRoot,'.chilly-willy','removed-mods')).isSymbolicLink()) {
    throw new Error('Carpeta de respaldo enlazada: no se eliminarán mods.');
  }
  const seen = new Set();
  for (const item of toRemove) {
    const key = item.name.toLowerCase();
    if (seen.has(key)) throw new Error('Duplicados en inventario anterior: no se eliminarán mods.');
    seen.add(key);
    const source = path.join(modsDir,item.name);
    if (!actualFile(source,item.size)) {preserved.push(item.name);continue;}
    fs.mkdirSync(quarantine,{recursive:true});
    const destination = path.join(quarantine,item.name);
    // Usar rename sin overwrite: no borrar una copia anterior ni la del usuario.
    if (fs.existsSync(destination)) throw new Error('Conflicto de copia de seguridad: no se eliminarán mods.');
    fs.renameSync(source,destination);
    removed.push(item.name);
  }
  return {removed,preserved,quarantine:removed.length?quarantine:null};
}
