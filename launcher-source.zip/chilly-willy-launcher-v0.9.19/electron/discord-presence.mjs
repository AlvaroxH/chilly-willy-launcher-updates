// Integración local y opcional con Discord Desktop: no utiliza bot tokens ni OAuth.
// Rich Presence se publica solo si el usuario lo permite y Discord está abierto.
export const DISCORD_APPLICATION_ID = '1564380095164981279';

export function presencePayload(phase, startedAt = Date.now()) {
  const assets = {
    largeImageKey: 'chilly_pinguino', largeImageText: 'Chilly Willy Launcher',
    smallImageKey: 'chilly_emblema', smallImageText: 'Cobbleverse · Fabric 1.21.1'
  };
  if (phase === 'playing') return {
    ...assets, details: 'Jugando Cobbleverse', state: 'Minecraft 1.21.1 · Fabric',
    startTimestamp: new Date(startedAt), instance: false
  };
  if (phase === 'preparing') return {
    ...assets, details: 'Preparando Minecraft', state: 'Sincronizando Cobbleverse', instance: false
  };
  return {...assets, details: 'En el launcher', state: 'Preparándose para jugar', instance: false};
}

export function createDiscordPresence({
  clientId = DISCORD_APPLICATION_ID,
  clientFactory = async () => {
    const {Client} = await import('@xhayper/discord-rpc');
    return new Client({clientId});
  },
  retryMs = 20000
} = {}) {
  let enabled = false;
  let phase = 'idle';
  let startedAt = null;
  let client = null;
  let ready = false;
  let connecting = false;
  let stopping = false;
  let interval = null;
  let connectionGeneration = 0;

  async function showActivity() {
    if (!enabled || !ready || !client?.user) return;
    try { await client.user.setActivity(presencePayload(phase, startedAt || Date.now())); }
    catch (error) { console.warn('[Discord RPC] No se pudo cambiar la actividad:', String(error?.message ?? error)); }
  }
  async function connect() {
    if (!enabled || connecting || ready || stopping) return;
    connecting = true;
    const generation = ++connectionGeneration;
    let fresh = null;
    try {
      fresh = await clientFactory();
      if (!enabled || stopping || generation !== connectionGeneration) {
        fresh?.destroy?.(); return;
      }
      client = fresh;
      fresh.on('ready', () => {
        if (generation !== connectionGeneration || !enabled || stopping) return;
        connecting = false; ready = true; void showActivity();
      });
      const lost = () => {
        if (generation !== connectionGeneration) return;
        ready = false; connecting = false; client = null;
      };
      fresh.on('disconnected', lost);
      fresh.on('close', lost);
      fresh.on('error', () => {});
      await fresh.login();
    } catch (error) {
      if (generation === connectionGeneration) {
        connecting = false; ready = false; client = null;
      }
      console.warn('[Discord RPC] Discord Desktop no está disponible:', String(error?.message ?? error));
      try { fresh?.destroy?.(); } catch {}
    }
  }
  function setEnabled(next) {
    if (typeof next !== 'boolean') throw new Error('Preferencia de Discord inválida.');
    if (stopping) return;
    enabled = next;
    if (!enabled) {
      connectionGeneration++;
      ready = false; connecting = false;
      const previous = client;
      client = null;
      try { Promise.resolve(previous?.user?.clearActivity?.()).catch(() => {}).finally(() => {
        try { previous?.destroy?.(); } catch {}
      }); } catch { try { previous?.destroy?.(); } catch {} }
      if (interval) clearInterval(interval);
      interval = null;
      return;
    }
    if (!interval) {
      interval = setInterval(() => { void connect(); }, retryMs);
      interval.unref?.();
    }
    void connect();
  }
  function setPhase(next) {
    if (!['idle','preparing','playing'].includes(next)) return;
    if (next === 'playing' && phase !== 'playing') startedAt = Date.now();
    if (next !== 'playing') startedAt = null;
    phase = next;
    void showActivity();
  }
  function stop() {
    if (stopping) return;
    setEnabled(false);
    stopping = true;
  }
  return {setEnabled, setPhase, stop, getState: () => ({enabled, connected: ready, phase})};
}
