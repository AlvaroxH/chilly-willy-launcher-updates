/**
 * Opciones de Cobbleverse: el preset maestro SOLO proporciona valores iniciales.
 * Desde v0.9.19, nunca se restauran en cada inicio la sensibilidad, teclas,
 * volumen, interfaz, gráficos ni otras preferencias personales.
 * Las instalaciones antiguas se migran sin borrar opciones desconocidas.
 */
import fs from 'node:fs';
import path from 'node:path';

const MAX_BYTES = 1024 * 1024;
const STATE_REL = 'config/chilly-willy/master-complete-options-v0912.json';
const VALID_KEY = /^[A-Za-z0-9_.-]{1,160}$/;
const PRIVATE_OR_DEVICE = /^(?:lastServer|lastSeen.*|lastKnown.*|joinedFirstServer|fullscreenResolution|soundDevice|.*(?:token|session|password|secret|uuid|playerdata|statistic|advancement|waypoint).*)$/i;

function limitedRead(p, limit = MAX_BYTES) {
  const st = fs.statSync(p);
  if (!st.isFile() || st.size > limit) throw new Error('Archivo de preferencias inválido o demasiado grande.');
  return fs.readFileSync(p, 'utf8');
}
function parse(source) {
  const bom = source.startsWith('\uFEFF') ? '\uFEFF' : '';
  const raw = bom ? source.slice(1) : source;
  const eol = raw.includes('\r\n') ? '\r\n' : '\n';
  const values = new Map();
  for (const line of raw.split(/\r?\n/)) {
    const colon = line.indexOf(':');
    if (colon <= 0) continue;
    const key = line.slice(0, colon);
    const value = line.slice(colon + 1);
    if (VALID_KEY.test(key) && value.length <= 20000 && !value.includes('\0')) values.set(key, value);
  }
  return {bom, eol, values};
}
function atomic(file, data) {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  const temp = `${file}.tmp-${process.pid}-${Date.now()}`;
  try {fs.writeFileSync(temp, data, {flag:'wx', encoding:'utf8'}); fs.renameSync(temp, file);}
  finally {try {fs.unlinkSync(temp);} catch {}}
}
export function applyMasterCompleteOptions(instanceRoot) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('Ruta inválida de la instancia de Minecraft.');
  const preset = path.join(instanceRoot, 'presets', 'options.txt');
  if (!fs.existsSync(preset)) throw new Error('Falta el options.txt del modpack maestro.');
  const master = parse(limitedRead(preset));
  if (master.values.size < 30 || master.values.get('version') !== '3955') {
    throw new Error('El options.txt maestro está vacío, incompleto o no es de Minecraft 1.21.1.');
  }
  const target = path.join(instanceRoot, 'options.txt');
  const existed = fs.existsSync(target);
  const original = existed ? limitedRead(target) : '';
  const current = parse(original);
  const stateFile = path.join(instanceRoot, STATE_REL);
  const first = !fs.existsSync(stateFile);
  const additions = [];
  let preserved = 0;
  // Nunca eliminar ni modificar claves ya presentes en options.txt, aunque
  // vengan de una versión anterior o sean añadidas por un mod.
  for (const [key, value] of master.values) {
    if (PRIVATE_OR_DEVICE.test(key)) continue;
    if (current.values.has(key)) {preserved++; continue;}
    additions.push(`${key}:${value}`);
  }
  const separator = original && !/\r?\n$/.test(original) ? current.eol : '';
  const formatted = original + (additions.length ? separator + additions.join(current.eol) + current.eol : '');
  let backupFile = null;
  if (formatted !== original) {
    if (existed && first) {
      backupFile = path.join(instanceRoot, 'config', 'chilly-willy', 'backups', 'options-before-full-master-v0912.txt');
      fs.mkdirSync(path.dirname(backupFile), {recursive:true});
      if (!fs.existsSync(backupFile)) fs.copyFileSync(target, backupFile, fs.constants.COPYFILE_EXCL);
    }
    atomic(target, formatted);
  }
  // Se acepta el marcador de v0.9.12 sin reinterpretar sus valores: en la
  // edición anterior representaban opciones que se forzaban en cada inicio.
  // No actualizarlo en cada partida (evita escrituras innecesarias).
  if (first) atomic(stateFile, JSON.stringify({schema:2,policy:'preserve-player-options'}, null, 2) + '\n');
  return {first, applied:additions.length, preserved, total:master.values.size, backupFile};
}

/** Distribuir el icono del modpack, nunca los saves ni datos de perfil. */
export function copyMasterPackIcon(instanceRoot){
  if(typeof instanceRoot!=='string'||!path.isAbsolute(instanceRoot))throw new Error('Ruta inválida.');
  const src=path.join(instanceRoot,'presets','icon.png');
  if(!fs.existsSync(src))return {copied:false};
  const st=fs.statSync(src);
  if(!st.isFile()||st.size<100||st.size>8*1024*1024)throw new Error('Icono maestro inválido.');
  const head=Buffer.alloc(8);const fd=fs.openSync(src,'r');try{fs.readSync(fd,head,0,8,0);}finally{fs.closeSync(fd);}
  if(!head.equals(Buffer.from([137,80,78,71,13,10,26,10])))throw new Error('El icono maestro no es PNG.');
  const dst=path.join(instanceRoot,'icon.png');
  const marker=path.join(instanceRoot,'config','chilly-willy','master-icon-v0912.done');
  if(fs.existsSync(marker))return {copied:false};
  if(fs.existsSync(dst)) {
    const backup=path.join(instanceRoot,'config','chilly-willy','backups','icon-before-master-v0912.png');
    fs.mkdirSync(path.dirname(backup),{recursive:true});
    if(!fs.existsSync(backup))fs.copyFileSync(dst,backup,fs.constants.COPYFILE_EXCL);
  }
  fs.copyFileSync(src,dst);
  atomic(marker,'ok\n');
  return {copied:true};
}
