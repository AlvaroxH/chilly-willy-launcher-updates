// Persistencia local de preferencias. Nunca guardar tokens, contraseñas o cuentas Microsoft.
import path from 'node:path';
import { existsSync, readFileSync, mkdirSync, writeFileSync, renameSync, unlinkSync } from 'node:fs';
import { randomUUID } from 'node:crypto';

export const validGuestName = (value) => typeof value === 'string' && /^[A-Za-z0-9_]{3,16}$/.test(value);
const validMemory = value => [2048, 4096, 6144, 8192, 12288].includes(value);

export function readPreferences(userDataDir) {
  try {
    const file = path.join(userDataDir, 'preferences.json');
    if (!existsSync(file)) return {};
    const parsed = JSON.parse(readFileSync(file, 'utf8'));
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return {};
    // Lista blanca de propiedades: impide conservar tokens de autenticación por accidente.
    return {
      ...(validMemory(parsed.memoryMb) ? { memoryMb: parsed.memoryMb } : {}),
      ...(validGuestName(parsed.guestName) ? { guestName: parsed.guestName } : {}),
      ...(parsed.storageChoiceMade === true ? { storageChoiceMade: true } : {}),
      ...(parsed.forceModpackSync === true ? { forceModpackSync: true } : {}),
      ...(typeof parsed.discordPresenceEnabled === 'boolean' ? { discordPresenceEnabled: parsed.discordPresenceEnabled } : {})
    };
  } catch {
    // Un fichero dañado nunca debe impedir abrir el launcher.
    return {};
  }
}

export function savePreferences(userDataDir, updates) {
  const state = readPreferences(userDataDir);
  if (Object.hasOwn(updates, 'memoryMb')) {
    if (!validMemory(updates.memoryMb)) throw new Error('Asignación de RAM inválida');
    state.memoryMb = updates.memoryMb;
  }
  if (Object.hasOwn(updates, 'storageChoiceMade')) {
    if (updates.storageChoiceMade !== true) throw new Error('Selección de ubicación inválida.');
    state.storageChoiceMade = true;
  }
  if (Object.hasOwn(updates, 'forceModpackSync')) {
    if (typeof updates.forceModpackSync !== 'boolean') throw new Error('Opción de reparación inválida.');
    if (updates.forceModpackSync) state.forceModpackSync = true;
    else delete state.forceModpackSync;
  }
  if (Object.hasOwn(updates, 'discordPresenceEnabled')) {
    if (typeof updates.discordPresenceEnabled !== 'boolean') throw new Error('Opción Discord inválida.');
    state.discordPresenceEnabled = updates.discordPresenceEnabled;
  }
  if (Object.hasOwn(updates, 'guestName')) {
    if (updates.guestName === null) delete state.guestName;
    else if (validGuestName(updates.guestName)) state.guestName = updates.guestName;
    else throw new Error('El nick debe tener 3 a 16 caracteres: letras, números o guion bajo.');
  }
  mkdirSync(userDataDir, { recursive: true });
  const target = path.join(userDataDir, 'preferences.json');
  const temp = path.join(userDataDir, `.preferences-${process.pid}-${randomUUID()}.tmp`);
  try {
    writeFileSync(temp, JSON.stringify(state, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
    renameSync(temp, target);
  } finally {
    if (existsSync(temp)) unlinkSync(temp);
  }
  return state;
}
