# Chilly Willy Launcher v0.9.18 — Discord Rich Presence

- Discord Application ID: `1564380095164981279` (público).
- Discord Desktop recibe actividad `En el launcher`, `Preparando Minecraft`, `Jugando Cobbleverse` y tiempo de juego.
- Imágenes opcionales en Discord Developer Portal: `chilly_pinguino` (grande) y `chilly_emblema` (pequeña).
- Ajustes: interruptor para desactivar la actividad; la preferencia persiste entre sesiones.
- Mientras Minecraft esté abierto, cerrar la ventana minimiza el launcher a la bandeja; la conexión Discord permanece y la aplicación termina cuando el juego termina.
- Solo usa RPC local; nunca envía contraseñas, tokens Microsoft, nickname o IP a Discord.
- No se ha probado aún la integración en una sesión real de Discord Desktop en Windows.

## Requisitos para mostrarlo en Discord

1. Crear y guardar el Application ID de Discord usado arriba.
2. En Discord Developer Portal, subir las imágenes PNG a Rich Presence / Art Assets usando las claves exactas: `chilly_pinguino` y `chilly_emblema`.
3. Iniciar Discord Desktop, activar la visualización de actividad en sus ajustes y ejecutar el instalador Chilly Willy.
4. Probar apertura y cierre de Minecraft.

Este ZIP compila los ejecutables en GitHub Actions; no instala dependencias en la PC del usuario.
