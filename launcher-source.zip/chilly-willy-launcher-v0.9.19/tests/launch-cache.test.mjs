import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import os from 'node:os';
import {mkdtempSync, mkdirSync, writeFileSync, rmSync, unlinkSync, readFileSync} from 'node:fs';
import {readPreferences, savePreferences} from '../electron/profile-store.mjs';
import {readLaunchCache, installedPackIntact, launchMode, saveFullLaunch,
  markRemoteChecked, REMOTE_CHECK_MS, FULL_RECHECK_MS, cacheFile} from '../electron/launch-cache.mjs';

const settings = {minecraftVersion:'1.21.1',fabricLoaderVersion:'0.20.1',modpackManifestUrl:'https://script.google.com/macros/s/demo/exec'};
const pack = {fingerprint:'sha256-a',fullPack:true,fullShaderPack:true,completeMaster:true,
  count:2,counts:{mods:2,resourcepacks:1},totalPackMiB:6,version:6,
  resourcepackFiles:[{name:'COBBLEVERSE RP.zip',path:'resourcepacks/'}],
  modFiles:[{name:'a.jar',size:4},{name:'b.jar',size:7}]};
function fixture(t) {
  const userData=mkdtempSync(path.join(os.tmpdir(),'chilly-fast-'));
  t.after(()=>rmSync(userData,{recursive:true,force:true}));
  const instanceRoot=path.join(userData,'minecraft');
  mkdirSync(path.join(instanceRoot,'mods'),{recursive:true});
  writeFileSync(path.join(instanceRoot,'mods','a.jar'),'aaaa');
  writeFileSync(path.join(instanceRoot,'mods','b.jar'),'bbbbbbb');
  writeFileSync(path.join(instanceRoot,'options.txt'),'version:3955\n');
  return {userData,instanceRoot};
}
test('inicio posterior utiliza los archivos existentes y evita Drive',t=>{
  const x=fixture(t),now=Date.now();
  assert.equal(saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot,now}),true);
  const c=readLaunchCache(x.userData);
  assert.equal(installedPackIntact(c,settings),true);
  assert.equal(launchMode({entry:c,settings,now:now+20_000}),'fast');
  assert.equal(launchMode({entry:c,settings,now:now+REMOTE_CHECK_MS+2}),'check-remote');
  assert.equal(launchMode({entry:c,settings,now:now+FULL_RECHECK_MS+2}),'full');
});
test('detecta mod ausente o incompleto y evita caché insegura',t=>{
  const x=fixture(t);saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot});
  unlinkSync(path.join(x.instanceRoot,'mods','b.jar'));
  assert.equal(launchMode({entry:readLaunchCache(x.userData),settings}),'full');
  assert.equal(saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot}),false);
});
test('manifest nuevo, reparación manual o cambio de Fabric fuerzan sincronización',t=>{
  const x=fixture(t);saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot});
  const c=readLaunchCache(x.userData);
  assert.equal(launchMode({entry:c,settings,remotePack:{fingerprint:'sha256-b'}}),'full');
  assert.equal(launchMode({entry:c,settings,force:true}),'full');
  assert.equal(launchMode({entry:c,settings:{...settings,fabricLoaderVersion:'0.20.2'}}),'full');
  assert.equal(launchMode({entry:c,settings,remotePack:pack}),'fast');
});
test('revisión manual recuerda una actualización pendiente aunque se cierre el launcher',t=>{
  const x=fixture(t);saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot});
  const entry=readLaunchCache(x.userData);
  assert.equal(markRemoteChecked(x.userData,entry,{fingerprint:'sha256-b'}),false);
  assert.equal(launchMode({entry:readLaunchCache(x.userData),settings}),'full');
});
test('manifiesto sin cambios renueva plazo sin reinstalar',t=>{
  const x=fixture(t);const now=Date.now();saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot,now:now-REMOTE_CHECK_MS-1000});
  assert.equal(markRemoteChecked(x.userData,readLaunchCache(x.userData),pack,now),true);
  assert.equal(launchMode({entry:readLaunchCache(x.userData),settings,now}),'fast');
});
test('no copia partidas ni credenciales a la caché ni altera carpetas de usuario',t=>{
  const x=fixture(t);mkdirSync(path.join(x.instanceRoot,'saves'),{recursive:true});
  writeFileSync(path.join(x.instanceRoot,'saves','world.dat'),'mi mundo');
  saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot});
  const txt=readFileSync(cacheFile(x.userData),'utf8');
  assert.doesNotMatch(txt,/mi mundo|password|accessToken|refreshToken/);
  assert.equal(readFileSync(path.join(x.instanceRoot,'saves','world.dat'),'utf8'),'mi mundo');
});
test('estado de caché corrupto o faltante inicia sincronización normal',t=>{
  const x=fixture(t);
  assert.equal(readLaunchCache(x.userData),null);
  writeFileSync(cacheFile(x.userData),'{');
  assert.equal(readLaunchCache(x.userData),null);
  assert.equal(launchMode({entry:null,settings}),'full');
});
test('actualizador y UI de reparación incluyen las rutas rápidas',()=>{
  const main=readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
  const ui=readFileSync(new URL('../ui/index.html',import.meta.url),'utf8');
  assert.match(main,/fastLaunch \? \{\} : \{modpackUrl:/);
  assert.match(ui,/id="forceModpackSyncBtn"/);
});

test('reparación se guarda en preferencias de la PC hasta la sincronización completa',t=>{
  const x=fixture(t);savePreferences(x.userData,{forceModpackSync:true});
  assert.equal(readPreferences(x.userData).forceModpackSync,true);
  savePreferences(x.userData,{memoryMb:4096});
  assert.equal(readPreferences(x.userData).forceModpackSync,true);
  savePreferences(x.userData,{forceModpackSync:false});
  assert.equal(readPreferences(x.userData).forceModpackSync,undefined);
});

test('una instalación 0.9.16 fuerza una única migración de perfiles visuales al usar JUGAR',t=>{
 const x=fixture(t);saveFullLaunch(x.userData,{pack,settings,instanceRoot:x.instanceRoot});
 const prior=readLaunchCache(x.userData); delete prior.masterRevision;
 assert.equal(launchMode({entry:prior,settings,remotePack:pack}),'full');
 assert.equal(launchMode({entry:readLaunchCache(x.userData),settings,remotePack:pack}),'fast');
});
