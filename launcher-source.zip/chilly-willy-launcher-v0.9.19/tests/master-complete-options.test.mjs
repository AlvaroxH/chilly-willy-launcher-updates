import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {applyMasterCompleteOptions,copyMasterPackIcon} from '../electron/master-complete-options.mjs';
import {validateManifest} from '../electron/manifest-validator.mjs';

function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'cw-master-complete-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'presets'),{recursive:true});
  const opts=['version:3955','fov:0.25','guiScale:3','gamma:1.0','soundCategory_master:0.6','soundCategory_music:0.0','lang:es_es','renderDistance:13','resourcePacks:["vanilla","fabric","file/Pack.zip"]','key_key.jump:key.keyboard.space','key_key.inventory:key.keyboard.e','fullscreenResolution:1920x1080','lastServer:PRIVATE_HOST'];
  for(let i=0;i<35;i++)opts.push(`modOption_${i}:value_${i}`);
  fs.writeFileSync(path.join(root,'presets','options.txt'),opts.join('\n')+'\n');
  return root;
}
test('completa opciones faltantes y conserva ajustes personalizados anteriores',t=>{
  const root=fixture(t);
  fs.writeFileSync(path.join(root,'options.txt'),'version:3955\nfov:0.99\nsoundCategory_music:1.0\nmodOption_stale:true\nfullscreenResolution:1366x768\nlastServer:LOCAL_PRIVATE\n');
  const r=applyMasterCompleteOptions(root);
  assert.equal(r.first,true);
  assert.ok(r.applied>30);
  assert.ok(r.total>=40);
  const o=fs.readFileSync(path.join(root,'options.txt'),'utf8');
  assert.match(o,/fov:0.99/);assert.match(o,/soundCategory_music:1.0/);
  assert.match(o,/key_key.jump:key.keyboard.space/);assert.match(o,/modOption_34:value_34/);
  assert.match(o,/modOption_stale:true/);
  assert.match(o,/fullscreenResolution:1366x768/);
  assert.match(o,/lastServer:LOCAL_PRIVATE/);
  assert.doesNotMatch(o,/PRIVATE_HOST/);
  assert.ok(fs.existsSync(r.backupFile));
});
test('no restaura preferencias personales aunque haya una sincronización completa',t=>{
 const root=fixture(t);applyMasterCompleteOptions(root);
 const f=path.join(root,'options.txt'); fs.writeFileSync(f,fs.readFileSync(f,'utf8').replace('guiScale:3','guiScale:2').replace('soundCategory_music:0.0','soundCategory_music:0.8'));
 const p=path.join(root,'presets','options.txt');fs.writeFileSync(p,fs.readFileSync(p,'utf8').replace('renderDistance:13','renderDistance:14'));
 const r=applyMasterCompleteOptions(root);
 assert.equal(r.first,false);assert.ok(r.preserved>30);
 const o=fs.readFileSync(f,'utf8');assert.match(o,/guiScale:2/);assert.match(o,/soundCategory_music:0.8/);assert.match(o,/renderDistance:13/);
});
test('no incorpora datos identificables, waypoints, ni datos de progreso como opciones',t=>{
 const root=fixture(t);const p=path.join(root,'presets','options.txt');
 fs.appendFileSync(p,'accountToken:SECRET_123\nwaypointSecret:45,-7,45\nadvancementProgress:99\n');
 applyMasterCompleteOptions(root);
 const o=fs.readFileSync(path.join(root,'options.txt'),'utf8');
 assert.doesNotMatch(o,/SECRET_123|waypointSecret|advancementProgress|PRIVATE_HOST/);
});
test('soporta migrar directamente desde el estado anterior v0.9.11 sin borrar backups',t=>{
 const root=fixture(t);const p=path.join(root,'config','chilly-willy');fs.mkdirSync(p,{recursive:true});
 fs.writeFileSync(path.join(p,'master-visual-state.json'),JSON.stringify({schema:1,managed:{fov:'0.25'}}));
 const o=path.join(root,'options.txt');fs.writeFileSync(o,'fov:0.7\nsoundCategory_music:0.5\n');
 assert.equal(applyMasterCompleteOptions(root).first,true);
 assert.match(fs.readFileSync(o,'utf8'),/soundCategory_music:0.5/);
 assert.ok(fs.existsSync(path.join(p,'master-visual-state.json')));
});
test('copia el icono legítimo sin tocar saves ni mapas, con respaldo',t=>{
 const root=fixture(t);const src=path.join(root,'presets','icon.png');const png=Buffer.from([137,80,78,71,13,10,26,10,...new Array(110).fill(0)]);
 fs.writeFileSync(src,png);fs.writeFileSync(path.join(root,'icon.png'),Buffer.from('original'));
 const r=copyMasterPackIcon(root);assert.equal(r.copied,true);assert.ok(fs.readFileSync(path.join(root,'icon.png')).equals(png));assert.equal(copyMasterPackIcon(root).copied,false);
});
test('manifiesto v6 permite el icono y rechaza almacenamiento personal',()=>{
 const files=[['mods/','abc.jar','MOD',123],['config/','sodium-options.json','OTHER',123],['resourcepacks/','Cobbleverse.zip','OTHER',456],['datapacks/','Cobbleverse.zip','OTHER',456],['shaderpacks/','ComplementaryUnbound_r5.8.1.zip','OTHER',456],['presets/','options.txt','OTHER',123],['presets/','icon.png','OTHER',400]];
 const items=files.map(([p,n,type,size],i)=>({path:p,name:n,type,size,updated:123456,url:`https://drive.usercontent.google.com/download?id=file${i}&export=download&confirm=t`}));
 const x=validateManifest({version:6,source:'cobbleverse-master',files:items});assert.equal(x.completeMaster,true);assert.equal(x.counts.presets,2);
 assert.throws(()=>validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],name:'username-cache.json'}]}),/individuales/);
 const preferences=validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],path:'config/roughlyenoughitems/',name:'favorites.json5'},{...items[1],path:'config/voicechat/',name:'player-volumes.properties'},{...items[1],path:'config/fancymenu/',name:'user_variables.db'}]});
 assert.equal(preferences.counts.config,4);
 assert.throws(()=>validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],path:'xaero/waypoints/'}]}));
 assert.throws(()=>validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],path:'config/xaero/waypoints/'}]}),/exploración/);
});

test('sensibilidad y controles personalizados sobreviven varios arranques', t => {
 const root=fixture(t);const f=path.join(root,'options.txt');
 const personal='version:3955\nmouseSensitivity:0.327\nkey_key.jump:key.keyboard.k\nsoundCategory_master:0.42\ncustom_mod_setting:player\n';
 fs.writeFileSync(f,personal);
 applyMasterCompleteOptions(root);
 const after=fs.readFileSync(f,'utf8');
 assert.match(after,/mouseSensitivity:0.327/);
 assert.match(after,/key_key.jump:key.keyboard.k/);
 assert.match(after,/custom_mod_setting:player/);
 for(let i=0;i<3;i++){const x=applyMasterCompleteOptions(root);assert.equal(x.applied,0);assert.equal(fs.readFileSync(f,'utf8'),after);}
});

test('una instalación limpia recibe los valores maestros sin importar datos privados', t=>{
 const root=fixture(t);const result=applyMasterCompleteOptions(root);
 assert.equal(result.first,true);
 const source=fs.readFileSync(path.join(root,'options.txt'),'utf8');
 assert.match(source,/guiScale:3/);
 assert.doesNotMatch(source,/lastServer:PRIVATE_HOST|fullscreenResolution:1920x1080/);
});

test('migra la marca v0.9.18 sin restablecer un options.txt personalizado',t=>{
 const root=fixture(t);const state=path.join(root,'config/chilly-willy/master-complete-options-v0912.json');
 fs.mkdirSync(path.dirname(state),{recursive:true});
 fs.writeFileSync(state,JSON.stringify({schema:1,managed:{mouseSensitivity:'0.5',guiScale:'3'}}));
 const target=path.join(root,'options.txt');
 fs.writeFileSync(target,'version:3955\nmouseSensitivity:0.947\nguiScale:1\nkey_key.forward:key.keyboard.up\n');
 const r=applyMasterCompleteOptions(root);
 assert.equal(r.first,false);
 const content=fs.readFileSync(target,'utf8');
 assert.match(content,/mouseSensitivity:0.947/);
 assert.match(content,/guiScale:1/);
 assert.match(content,/key_key.forward:key.keyboard.up/);
});
