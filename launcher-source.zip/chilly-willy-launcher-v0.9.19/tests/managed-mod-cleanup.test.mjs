import {test} from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import {retireRemovedManagedMods} from '../electron/managed-mod-cleanup.mjs';
const settings={minecraftVersion:'1.21.1',fabricLoaderVersion:'0.20.1',modpackManifestUrl:'https://script.google.com/macros/s/fake/exec'};
function fixture(t){
 const dir=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-clean-')); t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
 fs.mkdirSync(path.join(dir,'mods')); const put=(name,data)=>fs.writeFileSync(path.join(dir,'mods',name),data);
 put('old.jar','OLD');put('current.jar','NEW');put('extra.jar','CUSTOM');
 const cache={instanceRoot:dir,settings,pack:{modFiles:[{name:'old.jar',size:3},{name:'current.jar',size:3}]}};
 const pack={version:6,fullPack:true,completeMaster:true,fullShaderPack:true,modFiles:[{name:'current.jar',size:3}]};
 return {dir,put,cache,pack};
}
const run=x=>retireRemovedManagedMods({instanceRoot:x.dir,previousCache:x.cache,currentPack:x.pack,settings});
test('retira sólo el mod oficial eliminado, conserva mods personales y guarda respaldo',t=>{
 const x=fixture(t),result=run(x);
 assert.deepEqual(result.removed,['old.jar']);
 assert.equal(fs.existsSync(path.join(x.dir,'mods','old.jar')),false);
 assert.equal(fs.readFileSync(path.join(x.dir,'mods','extra.jar'),'utf8'),'CUSTOM');
 assert.equal(fs.readFileSync(path.join(result.quarantine,'old.jar'),'utf8'),'OLD');
});
test('si el manifest nuevo no está completo, no mueve ningún archivo',t=>{
 const x=fixture(t);x.pack.fullPack=false;
 assert.throws(()=>run(x),/incompleto/);
 assert.ok(fs.existsSync(path.join(x.dir,'mods','old.jar')));
});
test('si falta un nuevo mod o está incompleto, conserva todos los anteriores',t=>{
 const x=fixture(t);x.pack.modFiles.push({name:'new.jar',size:20});
 assert.throws(()=>run(x),/no está íntegra/);
 assert.ok(fs.existsSync(path.join(x.dir,'mods','old.jar')));
});
test('un mod modificado localmente conserva su copia',t=>{
 const x=fixture(t);x.put('old.jar','CHANGED');
 const result=run(x);
 assert.deepEqual(result.removed,[]);assert.deepEqual(result.preserved,['old.jar']);
 assert.equal(fs.readFileSync(path.join(x.dir,'mods','old.jar'),'utf8'),'CHANGED');
});
test('sin inventario anterior no toca archivos no identificados',t=>{
 const x=fixture(t);x.cache=null;
 assert.deepEqual(run(x).removed,[]);
 assert.ok(fs.existsSync(path.join(x.dir,'mods','old.jar')));
});
test('un inventario de otra instalación o manifest distinto no permite eliminar',t=>{
 const x=fixture(t);x.cache.instanceRoot=path.join(x.dir,'elsewhere');
 assert.deepEqual(run(x).removed,[]);
 assert.ok(fs.existsSync(path.join(x.dir,'mods','old.jar')));
});
test('ignora mods oficiales reemplazados por la misma ruta o con diferencia de mayúsculas',t=>{
 const x=fixture(t);x.pack.modFiles.push({name:'OLD.JAR',size:3});
 x.put('OLD.JAR','OLD');
 assert.deepEqual(run(x).removed,[]);
 assert.ok(fs.existsSync(path.join(x.dir,'mods','old.jar')));
});
test('rechaza nombres con path traversal o enlaces simbólicos',t=>{
 const x=fixture(t);x.cache.pack.modFiles=[{name:'../saves.dat',size:3}];
 assert.deepEqual(run(x).removed,[]);
 assert.ok(fs.existsSync(path.join(x.dir,'mods','old.jar')));
});
