import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const cfg = JSON.parse(readFileSync(new URL('../config/server.json', import.meta.url), 'utf8'));
const ui = readFileSync(new URL('../ui/index.html', import.meta.url), 'utf8');
const main = readFileSync(new URL('../electron/main.mjs', import.meta.url), 'utf8');
const preload = readFileSync(new URL('../electron/preload.cjs', import.meta.url), 'utf8');
const js = readFileSync(new URL('../ui/app.js', import.meta.url), 'utf8');
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));

test('configuracion Cobbleverse intacta', () => {
  assert.equal(cfg.minecraftVersion, '1.21.1');
  assert.equal(cfg.fabricLoaderVersion, '0.20.1');
  assert.equal(cfg.serverAddress, '146.181.33.25:25565');
  assert.match(cfg.modpackManifestUrl, /^https:\/\/script\.google\.com\/macros\/s\/[^/]+\/exec$/);
  assert.equal(cfg.allowGuest, true);
});
test('incluye firma del creador en ambas pantallas', () => {
  assert.match(ui, /Hecho por <strong>Chilly Willy<\/strong>/);
  assert.equal(pkg.version, '0.9.19');
});
test('Microsoft, invitado y lanzamiento permanecen disponibles', () => {
  for (const event of ['launcher:login-microsoft', 'launcher:login-guest', 'launcher:play']) assert.ok(main.includes(event));
  assert.match(main, /session\.type === 'guest' && settings\.allowGuest !== true/);
  assert.match(main, /java: \{ install: 'auto' \}/);
  assert.match(main, /minecraft\.modpackUrl|modpackUrl: settings\.modpackManifestUrl/);
});
test('interfaz premium conserva secciones y accion de JUGAR', () => {
  for (const id of ['screen-home','screen-account','screen-mods','screen-news','screen-settings','screen-help','playBtn','guestBtn','msBtn','checkManifestBtn']) assert.match(ui,new RegExp(`id="${id}"`));
  assert.match(js, /window\.cobble\.play\(\)/);
  assert.match(js, /window\.cobble\.checkManifest\(showSuccess\)/);
});
test('ajustes de memoria persisten en userData y ventana usa controles seguros', () => {
  assert.match(main, /app\.getPath\('userData'\)/);
  assert.match(main, /launcher:set-memory/);
  assert.match(preload, /setMemory:/);
  assert.match(main, /frame: false/);
  assert.match(main, /launcher:window-action/);
  assert.match(preload, /windowAction:/);
});
test('sigue siendo app local aislada',()=>{
  assert.match(main,/contextIsolation: true/);
  assert.match(main,/sandbox: true/);
  assert.match(main,/nodeIntegration: false/);
  assert.match(ui,/Content-Security-Policy/);
});
