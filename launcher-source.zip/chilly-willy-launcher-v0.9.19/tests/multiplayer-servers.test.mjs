import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {gzipSync, gunzipSync} from 'node:zlib';
import {ensureCobbleverseServer} from '../electron/multiplayer-servers.mjs';

function root(t) {const d=fs.mkdtempSync(path.join(os.tmpdir(),'cw-servers-')); t.after(()=>fs.rmSync(d,{recursive:true,force:true}));return d;}
const str = v=>{const b=Buffer.from(v,'utf8'),x=Buffer.alloc(2);x.writeUInt16BE(b.length);return Buffer.concat([x,b]);};
const i32=n=>{const b=Buffer.alloc(4);b.writeInt32BE(n);return b;};
const nstr=(k,v)=>Buffer.concat([Buffer.from([8]),str(k),str(v)]);
const record=(name,ip,extra=[])=>Buffer.concat([nstr('name',name),nstr('ip',ip),...extra,Buffer.from([0])]);
const make=(records=[],{other=false,emptyKind=false}={})=>Buffer.concat([
 Buffer.from([10]),str(''),
 ...(other?[nstr('moddedRoot','important')]:[]),
 Buffer.from([9]),str('servers'),Buffer.from([emptyKind?0:10]),i32(records.length),...records,
 Buffer.from([0])
]);
const saved=(d)=>gunzipSync(fs.readFileSync(path.join(d,'servers.dat')));

test('en primera instalación crea servers.dat NBT válido y no repite entradas',t=>{
 const d=root(t);
 const first=ensureCobbleverseServer(d,'146.181.33.25:25565');
 assert.equal(first.status,'added');assert.equal(first.backup,null);
 const original=fs.readFileSync(first.file);
 assert.ok(saved(d).includes(Buffer.from('Chilly Willy | Cobbleverse')));
 assert.ok(saved(d).includes(Buffer.from('146.181.33.25:25565')));
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'existing');
 assert.deepEqual(fs.readFileSync(first.file),original);
});

test('añade el servidor sin tocar otros ni sus iconos/atributos, realiza backup',t=>{
 const d=root(t),file=path.join(d,'servers.dat');
 const custom=record('Mi servidor','play.example.net',[
  nstr('icon','data:image/png;base64,abc123'),
  Buffer.concat([Buffer.from([1]),str('hideAddress'),Buffer.from([1])])
 ]);
 const prior=make([custom],{other:true});fs.writeFileSync(file,gzipSync(prior));
 const r=ensureCobbleverseServer(d,'146.181.33.25:25565');
 assert.equal(r.status,'added');assert.deepEqual(gunzipSync(fs.readFileSync(r.backup)),prior);
 const bytes=saved(d);
 assert.ok(bytes.includes(custom));
 assert.ok(bytes.includes(nstr('moddedRoot','important')));
 assert.equal(bytes.readInt32BE(1+2+1+2+'moddedRoot'.length+2+'important'.length+1+2+'servers'.length+1),2);
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'existing');
 assert.equal(fs.readdirSync(d).filter(x=>x.endsWith('.bak')).length,1);
});

test('si ya existe el servidor por IP respeta su nombre y no duplica',t=>{
 const d=root(t),file=path.join(d,'servers.dat'),old=make([record('Favorito propio','146.181.33.25')]);
 fs.writeFileSync(file,gzipSync(old));
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'existing');
 assert.deepEqual(saved(d),old);
 assert.equal(fs.existsSync(file+'.chilly-willy.bak'),false);
});

test('si cambió la IP actualiza solo la dirección de la entrada oficial',t=>{
 const d=root(t),file=path.join(d,'servers.dat');
 const other=record('Mineclub','mc.example.com');
 fs.writeFileSync(file,gzipSync(make([other,record('Chilly Willy | Cobbleverse','old.example.net')])));
 const res=ensureCobbleverseServer(d,'146.181.33.25:25565');
 assert.equal(res.status,'updated');
 assert.ok(saved(d).includes(other));
 assert.ok(saved(d).includes(nstr('ip','146.181.33.25:25565')));
 assert.ok(!saved(d).includes(Buffer.from('old.example.net')));
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'existing');
});

test('si servers.dat no tiene la lista servers añade la lista sin borrar otras etiquetas',t=>{
 const d=root(t),file=path.join(d,'servers.dat');
 const bytes=Buffer.concat([Buffer.from([10]),str(''),nstr('modded','value'),Buffer.from([0])]);
 fs.writeFileSync(file,gzipSync(bytes));
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'added');
 assert.ok(saved(d).includes(nstr('modded','value')));
 assert.ok(saved(d).includes(Buffer.from('146.181.33.25:25565')));
});

test('soporta lista vacía de tipo TAG_End sin perder el archivo',t=>{
 const d=root(t),file=path.join(d,'servers.dat');
 fs.writeFileSync(file,gzipSync(make([],{emptyKind:true})));
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'added');
 assert.equal(ensureCobbleverseServer(d,'146.181.33.25:25565').status,'existing');
});

test('archivo corrupto permanece intacto y nunca se sobrescribe',t=>{
 const d=root(t),file=path.join(d,'servers.dat');
 fs.writeFileSync(file,Buffer.from('ERROR INTEGRO'));
 assert.throws(()=>ensureCobbleverseServer(d,'146.181.33.25:25565'),/NBT/);
 assert.equal(fs.readFileSync(file,'utf8'),'ERROR INTEGRO');
 assert.equal(fs.existsSync(file+'.chilly-willy.bak'),false);
});

test('direcciones inválidas y rutas relativas no modifican archivos',t=>{
 const d=root(t);
 assert.throws(()=>ensureCobbleverseServer(d,'bad address'),/dirección/);
 assert.throws(()=>ensureCobbleverseServer(d,'mc.example.net:0'),/dirección/);
 assert.throws(()=>ensureCobbleverseServer('.', '146.181.33.25:25565'),/ruta/);
 assert.equal(fs.existsSync(path.join(d,'servers.dat')),false);
});

test('hook previo al inicio incluye el registro del servidor incluso en modo rápido',()=>{
 const main=fs.readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
 const hook=main.indexOf("launcher.on('launch_launch'");
 const ensure=main.indexOf('ensureCobbleverseServer(launcher.config.root, settings.serverAddress)',hook);
 const fast=main.indexOf('if (fastLaunch)',hook);
 assert.ok(hook>0 && ensure>hook && ensure<fast);
});
