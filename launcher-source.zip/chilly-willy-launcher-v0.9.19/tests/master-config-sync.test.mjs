import {test} from 'node:test';
import assert from 'node:assert/strict';
import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import {stageMasterConfig,applyMasterConfig} from '../electron/master-config-sync.mjs';
import {validateManifest} from '../electron/manifest-validator.mjs';
const URL = 'https://drive.usercontent.google.com/download?id=abcdefg123&export=download';
const mk=(rel,value,updated=1750000000000)=>({path:rel.slice(0,rel.lastIndexOf('/')+1),name:rel.slice(rel.lastIndexOf('/')+1),size:Buffer.byteLength(value),updated,url:URL,type:'OTHER'});
const v=(rel,value)=>({rel,value});
function temp(t){const root=fs.mkdtempSync(path.join(os.tmpdir(),'cw-config-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));return root;}
const data=[v('config/xaero/minimap/client.cfg','current_profile = cobbleverse\n'),v('config/xaero/minimap/profiles/cobbleverse.cfg','minimap_shape = 1\n'),v('config/xaero/world-map/profiles/cobbleverse.cfg','profile_name = COBBLEVERSE\n'),v('config/fancymenu/options.txt','S:custom_window_title = COBBLEVERSE\n'),v('config/fancymenu/customization/cobbleverse_main.txt','CUSTOM'),v('config/customsplashscreen/background.png','PNGDATA')];
const request=async url=>({ok:true,headers:{get:()=> 'application/octet-stream'},arrayBuffer:async()=>Buffer.from(data.find(x=>URL===url && false)?.value??'').buffer});
function fetchByName(requestList){let n=0;return async()=>{const buf=Buffer.from(requestList[n++].value);return {ok:true,headers:{get:key=>key==='content-length'?String(buf.length):'application/octet-stream'},arrayBuffer:async()=>buf};};}
test('copia configuración completa de Xaero y FancyMenu y hace backup, pero no mapas',async t=>{
 const root=temp(t),instance=path.join(root,'instance'),cache=path.join(root,'cache');fs.mkdirSync(path.join(instance,'config/xaero/minimap'),{recursive:true});
 fs.writeFileSync(path.join(instance,'config/xaero/minimap/client.cfg'),'current_profile = default\n');
 fs.mkdirSync(path.join(instance,'xaero','world-map'),{recursive:true});fs.writeFileSync(path.join(instance,'xaero/world-map','region.dat'),'EXPLORADO');
 const files=data.map(x=>mk(x.rel,x.value));
 let i=0;const fakeRequest=async()=>{const buf=Buffer.from(data[i++].value);return {ok:true,headers:{get:k=>k==='content-length'?String(buf.length):'application/octet-stream'},arrayBuffer:async()=>buf};};
 const snapshot=await stageMasterConfig({files,cacheRoot:cache,request:fakeRequest,concurrency:1});
 let result=applyMasterConfig({instanceRoot:instance,snapshot});assert.equal(result.first,true);assert.equal(result.applied,data.length-1);assert.equal(result.preserved,1);assert.deepEqual(result.critical,[]);
 assert.equal(fs.readFileSync(path.join(instance,'config/xaero/minimap/client.cfg'),'utf8'),'current_profile = default\n');
 assert.equal(fs.existsSync(path.join(instance,'config/chilly-willy/backups/v0913/config/xaero/minimap/client.cfg')),false);
 assert.equal(fs.readFileSync(path.join(instance,'xaero/world-map/region.dat'),'utf8'),'EXPLORADO');
 // En sincronización completa prevalece la configuración modificada por el usuario.
 fs.writeFileSync(path.join(instance,'config/xaero/minimap/client.cfg'),'current_profile = player_custom\n');
 result=applyMasterConfig({instanceRoot:instance,snapshot});assert.equal(result.first,false);assert.equal(result.preserved,1);
 assert.equal(fs.readFileSync(path.join(instance,'config/xaero/minimap/client.cfg'),'utf8'),'current_profile = player_custom\n');
});
test('rechaza archivos personales en el snapshot aunque intenten camuflarse como config',async t=>{
 const root=temp(t);
 const files=[mk('config/playerdata/user.dat','secret'),mk('config/fancymenu/options.txt','ok')];
 await assert.rejects(stageMasterConfig({files,cacheRoot:root,request:fetchByName(data)}),/no permitido/);
 assert.equal(fs.existsSync(path.join(root,'config/playerdata/user.dat')),false);
});
test('el validador de manifest devuelve todas las configuraciones a sincronizar sin exponer saves',()=>{
 const f=(name,path,type)=>({name,path,type,size:100,updated:1750000000000,url:URL});
 const result=validateManifest({version:6,source:'cobbleverse-master',files:[f('fabric-api.jar','mods/','MOD'),f('client.cfg','config/xaero/minimap/','OTHER'),f('main.txt','config/fancymenu/customization/','OTHER'),f('COBBLEVERSE RP.zip','resourcepacks/','OTHER'),f('default.zip','shaderpacks/','OTHER'),f('stuff.zip','datapacks/','OTHER'),f('options.txt','presets/','OTHER')]});
 assert.deepEqual(result.configurationFiles.map(x=>x.path+x.name),['config/xaero/minimap/client.cfg','config/fancymenu/customization/main.txt','presets/options.txt']);
});

test('aplica perfiles maestros cuando la raíz es una unión a otra unidad',async t=>{
 const base=temp(t),physical=path.join(base,'disco-D'),junction=path.join(base,'minecraft-link'),cache=path.join(base,'cache');
 fs.mkdirSync(physical,{recursive:true});fs.symlinkSync(physical,junction,'dir');
 const original=data.slice(0,1);
 const list=original.map(x=>mk(x.rel,x.value));
 const snapshot=await stageMasterConfig({files:list,cacheRoot:cache,request:fetchByName(original),concurrency:1});
 const result=applyMasterConfig({instanceRoot:junction,snapshot});
 assert.equal(result.applied,1);
 assert.equal(fs.readFileSync(path.join(physical,'config/xaero/minimap/client.cfg'),'utf8'),'current_profile = cobbleverse\n');
});

test('actualiza archivos oficiales intactos pero conserva modificaciones personales a mods', async t=>{
 const root=temp(t),instance=path.join(root,'instance'),cache=path.join(root,'cache');
 const rel='config/mod_ejemplo/settings.json';
 const makeSnapshot=async(value,folder)=>stageMasterConfig({files:[mk(rel,value)],cacheRoot:folder,request:fetchByName([{value}]),concurrency:1});
 const s1=await makeSnapshot('{"quality":1}',cache);
 applyMasterConfig({instanceRoot:instance,snapshot:s1});
 const s2=await makeSnapshot('{"quality":2}',path.join(root,'cache2'));
 applyMasterConfig({instanceRoot:instance,snapshot:s2});
 assert.equal(fs.readFileSync(path.join(instance,rel),'utf8'),'{"quality":2}');
 fs.writeFileSync(path.join(instance,rel),'{"quality":55}');
 const s3=await makeSnapshot('{"quality":3}',path.join(root,'cache3'));
 const r=applyMasterConfig({instanceRoot:instance,snapshot:s3});
 assert.equal(r.preserved,1);
 assert.equal(fs.readFileSync(path.join(instance,rel),'utf8'),'{"quality":55}');
});
