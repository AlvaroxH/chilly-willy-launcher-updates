import {test} from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {createDiscordPresence, presencePayload, DISCORD_APPLICATION_ID} from '../electron/discord-presence.mjs';

test('Application ID correcto y textos de actividad sin datos privados', () => {
  assert.equal(DISCORD_APPLICATION_ID, '1564380095164981279');
  const playing = presencePayload('playing', 1730000000000);
  assert.equal(playing.details, 'Jugando Cobbleverse');
  assert.equal(playing.largeImageKey, 'chilly_pinguino');
  assert.equal(playing.smallImageKey, 'chilly_emblema');
  assert.equal(playing.startTimestamp.getTime(), 1730000000000);
  assert.ok(!('joinSecret' in playing) && !('partyId' in playing));
  assert.equal(presencePayload('idle').details, 'En el launcher');
  assert.equal(presencePayload('preparing').details, 'Preparando Minecraft');
});

test('Discord RPC pasa de en launcher a jugando y se puede desactivar', async () => {
  const sent=[];
  const cli = new EventEmitter();
  cli.user = {
    setActivity: async (x) => {sent.push(x);},
    clearActivity: async () => {sent.push(null);}
  };
  cli.login = async () => {cli.emit('ready');};
  cli.destroy = () => {};
  const rpc = createDiscordPresence({clientFactory:async()=>cli, retryMs:1000000});
  rpc.setEnabled(true);
  for(let i=0;i<20&&!sent.length;i++)await new Promise(r=>setTimeout(r,0));
  assert.equal(sent[0].details,'En el launcher');
  rpc.setPhase('preparing');
  rpc.setPhase('playing');
  for(let i=0;i<20&&sent.length<3;i++)await new Promise(r=>setTimeout(r,0));
  assert.equal(sent.at(-1).details,'Jugando Cobbleverse');
  rpc.setPhase('idle');
  rpc.setEnabled(false);
  await new Promise(r=>setTimeout(r,0));
  assert.equal(rpc.getState().enabled,false);
  assert.ok(sent.includes(null));
  rpc.stop();
});

test('Discord ausente no impide abrir el launcher', async () => {
  const rpc = createDiscordPresence({clientFactory:async()=>{throw Error('Discord cerrado');}, retryMs:1000000});
  const old=console.warn;
  console.warn=()=>{};
  try {
    rpc.setEnabled(true);
    await new Promise(r=>setTimeout(r,3));
    assert.equal(rpc.getState().connected,false);
    assert.equal(rpc.getState().enabled,true);
    rpc.stop();
  } finally {console.warn=old;}
});
