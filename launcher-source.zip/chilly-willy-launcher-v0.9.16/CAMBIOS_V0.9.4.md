# Chilly Willy Launcher v0.9.4 — Persistencia del invitado

- Se corrigió el nick de invitado que se perdía al cerrar el programa (causa: `session` existía solo en memoria).
- Persistencia local en la carpeta de usuario de Electron, también para el portable.
- Restauración automática del perfil al iniciar el launcher; relleno del campo nick como recuperación alternativa.
- Cerrar sesión borra el perfil guardado. Cambiar a Microsoft también lo borra, sin almacenar credenciales Microsoft.
- Los ajustes de RAM siguen conservándose: se fusionan en el mismo `preferences.json`.
- Sin cambios al servidor, versión de Minecraft/Fabric, Drive, EasyAuth, skins, icono ni diseño.
- La instalación/portable aún necesita prueba real en Windows (estas verificaciones son de código en Linux).
