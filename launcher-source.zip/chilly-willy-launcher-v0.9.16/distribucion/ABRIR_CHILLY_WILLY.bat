@echo off
setlocal
set "COBBLE_EXE=%~dp0Chilly-Willy-Launcher.exe"
if not exist "%COBBLE_EXE%" (
  echo No se encontro Chilly-Willy-Launcher.exe en esta carpeta.
  echo Extrae los dos archivos juntos o ejecuta el instalador oficial.
  pause
  exit /b 1
)
start "Chilly Willy Launcher" "%COBBLE_EXE%"
exit /b 0
