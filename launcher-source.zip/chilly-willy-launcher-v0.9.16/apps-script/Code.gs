/**
 * CHILLY WILLY LAUNCHER v0.9.12 — publicación SEGURA de una instalación maestra.
 * Carpeta: https://drive.google.com/drive/folders/1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM
 * AVISO: distribuye SOLO categorías explícitas. NO publica saves, logs, screenshots,
 * historial de comandos, cachés, waypoints/Xaero, Pokémon del jugador,
 * logros, progreso, datos de servidor personales ni credenciales.
 * Para publicar: Implementar > Administrar implementaciones > Editar > Nueva versión.
 * El modpack instalado se administra por EML; este script solo devuelve metadatos.
 */
const MASTER_FOLDER_ID = '1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM';
const INCLUDED_FOLDERS = new Set([
  'mods', 'config', 'resourcepacks', 'shaderpacks', 'datapacks',
  'defaultconfigs', 'cobblemon', 'data'
]);
const OMIT_MODS = new Set(['NoChatRestrictions-Fabric-MC1.21.11-v1.0.0.jar']);
const OMIT_RESOURCEPACKS = new Set(['Xray_Ultimate_26.X_v5.4.4.zip']);
const ALLOWED_ROOT_FILES = new Set(['options.txt', 'icon.png']);
const MAX_FILES = 10000;
const MAX_BYTES_JSON = 1900000;
function safeName(name) {
  return typeof name === 'string' && name.length > 0 && name.length < 230 &&
    name !== '.' && name !== '..' && !/[\\/:*?"<>|\x00-\x1F]/.test(name) &&
    !/[. ]$/.test(name) && !/^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(\..*)?$/i.test(name);
}
function ignore(category, name, rel) {
  const lower = name.toLowerCase();
  if (!safeName(name) || name.startsWith('.') || name.endsWith('~')) return true;
  if (category === 'mods') return !lower.endsWith('.jar') || OMIT_MODS.has(name);
  if (category === 'resourcepacks') {
    return OMIT_RESOURCEPACKS.has(name) || /do[ _-]*not[ _-]*enable/i.test(name);
  }
  // Nunca distribuir datos de identidad, progreso, favoritos individuales o cachés.
  if (/^(?:username-cache\.json|servers\.dat(?:_old)?|.*\.(?:pem|key|p12)|credentials?\..*|tokens?\..*)$/i.test(name)) return true;
  if (/(?:^|\/)(?:waypoints?|advancements?|playerdata|stats|world-map-cache|map-data|cache|visited|explored|saves)(?:\/|$)/i.test(rel)) return true;
  if (category === 'config' && (rel.startsWith('config/chilly-willy/') ||
      /^(server\.properties|ops\.json|whitelist\.json|eula\.txt|banned-.*\.json|\.env.*|.*\.(?:pem|key|p12))$/i.test(name))) return true;
  // data/ del cliente únicamente tiene los recursos predeterminados de Fabric
  if (category === 'data') return rel !== 'data/' || name !== 'fabricDefaultResourcePacks.dat';
  return false;
}
function appendFile(file, prefix, category, output) {
  const name = file.getName();
  if (ignore(category,name,prefix)) return;
  if (file.getMimeType().startsWith('application/vnd.google-apps.')) return;
  const size = Number(file.getSize());
  if (!Number.isSafeInteger(size) || size < 0 || size > 1000000000) return;
  output.push({name, path:prefix, size,
    type:category === 'mods' ? 'MOD' : 'OTHER', updated:file.getLastUpdated().getTime(),
    url:'https://drive.usercontent.google.com/download?id='+encodeURIComponent(file.getId())+'&export=download&confirm=t'
  });
  if (output.length > MAX_FILES) throw Error('Demasiados archivos: comprimí los shaderpacks en ZIP');
}
function walk(folder, prefix, category, output, depth) {
  if (depth > 12) throw Error('Demasiada profundidad: '+prefix);
  const files = folder.getFiles();
  while(files.hasNext()) appendFile(files.next(), prefix, category, output);
  const dirs = folder.getFolders();
  while(dirs.hasNext()) {
    const folder = dirs.next(); const name = folder.getName();
    if (safeName(name) && !name.startsWith('.')) walk(folder,prefix+name+'/',category,output,depth+1);
  }
}
function doGet() {
  try {
    const root = DriveApp.getFolderById(MASTER_FOLDER_ID), output=[];
    const sectionsSeen = new Set();
    const folders = root.getFolders();
    while(folders.hasNext()) {
      const folder=folders.next(), name=folder.getName();
      if (!INCLUDED_FOLDERS.has(name)) continue;
      if (sectionsSeen.has(name)) throw Error('Carpeta de modpack repetida: '+name);
      sectionsSeen.add(name);
      walk(folder,name+'/',name,output,0);
    }
    for(const required of ['mods','config','resourcepacks','shaderpacks'])
      if (!sectionsSeen.has(required)) throw Error('Falta carpeta maestra '+required);
    const rootFiles=root.getFiles(); let hasOptions=false;
    while(rootFiles.hasNext()) {
      const file=rootFiles.next();
      if (ALLOWED_ROOT_FILES.has(file.getName())) {
        appendFile(file,'presets/','presets',output);
        if (file.getName()==='options.txt') hasOptions=true;
      }
    }
    if (!hasOptions) throw Error('Falta options.txt en la raíz maestra');
    output.sort((a,b)=>(a.path+a.name).localeCompare(b.path+b.name));
    const payload=JSON.stringify({version:6,source:'cobbleverse-master',files:output});
    if (payload.length>MAX_BYTES_JSON) throw Error('Manifiesto demasiado grande para Apps Script. Comprimí shaderpacks en ZIP individuales.');
    return ContentService.createTextOutput(payload).setMimeType(ContentService.MimeType.JSON);
  } catch(error) {
    return ContentService.createTextOutput(JSON.stringify({error:'Error de manifiesto Cobbleverse',detail:String(error)})).setMimeType(ContentService.MimeType.JSON);
  }
}
