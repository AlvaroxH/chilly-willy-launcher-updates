# Auditoría del modpack maestro — 25/10/2026

Fuente: https://drive.google.com/drive/folders/1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM

## Revisión de primer nivel en Google Drive

- `mods/`: 143 elementos de primer nivel, incluida la subcarpeta `.index`. Frente a Drive anterior apareció `spawnnotification-fabric-1.7.3-2.3.0.jar`.
- `config/`: 125 elementos de primer nivel. Subdirectorios preservados recursivamente.
- `resourcepacks/`: 52 elementos de primer nivel. Se añadieron Xray Ultimate y NewGlowingOres, además de `.index`. Los paquetes «DO NOT ENABLE» no se incluyen; Xray Ultimate queda excluido de distribución.
- `shaderpacks/`: 5 elementos de primer nivel, con dos shaders anidados (normal/High Quality) y el ZIP de Complementary Unbound.
- `datapacks/`: 7 elementos de primer nivel. Archivos de referencia del cliente: instalarlos en la carpeta del juego no los activa en el mundo del servidor.
- `defaultconfigs/`: vacío, pero ya está incluido en el allowlist para futuros archivos.
- `data/`: un archivo permitido `fabricDefaultResourcePacks.dat`.
- `cobblemon/`: `riding_perspectives.json`.
- `options.txt`: se distribuye exclusivamente en `presets/options.txt` para iniciar un perfil nuevo y obtener el orden de resourcepacks; no se pisa `options.txt` personal en cada ejecución.

## Excluidos deliberadamente

`saves/`, `logs/`, `screenshots/`, `command_history.txt`, `servers.dat_old`, `XaeroWaypoints_BACKUP...`, `xaero/` (mapas y waypoints privados), `showdown/` (código y datos generados), `.fabric/`, `.mixin.out/`, `downloads/`, `fancymenu_data/` (cachés y datos temporales), `server-resource-packs/`, `stackdeobf_mappings/`, `particular_cache/`, `cobblemon-battle-logs/`, `catchrate-logs/` y archivos auxiliares.

## Limitaciones reales

- No se han descargado ni auditado **todos** los bytes de cada archivo; el inventario usa metadatos de Drive y revisión de nombres.
- El manifiesto actual no incorpora hashes SHA-256 verificables para todos los archivos; el launcher no certifica equivalencia binaria con la instalación maestra.
- Drive/Apps Script puede superar límites de tiempo/tamaño al recorrer los shaderpacks descomprimidos; realizar prueba de publicación y descarga desde Windows antes de distribución pública.
- El comportamiento del motor EML para rutas nuevas debe probarse en una instalación limpia de Windows.
- La eliminación segura de archivos obsoletos requiere un registro de propiedad del instalador; se mantiene desactivada para evitar pérdidas.
- `saves`, capturas y logs subidos a la carpeta compartida **pueden exponer información privada**. Tras separar el contenido distribuible, guardarlos en una carpeta privada.

## Actualización del manifiesto

Después de extraer este proyecto, actualizar el **mismo despliegue** de Google Apps Script con el `apps-script/Code.gs` incluido. Debe devolver `version:5` y `source:cobbleverse-master`. El Setup v0.9.10 se genera en Windows con `GENERAR_EXE.vbs`; aquí no se incluye un Setup compilado.
