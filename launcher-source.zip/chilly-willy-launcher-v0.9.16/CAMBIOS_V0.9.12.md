# Chilly Willy Launcher v0.9.12 — Instalación maestra sin datos personales

## Configuraciones restauradas

- Copia **todas las opciones** del archivo raíz `options.txt` de Cobbleverse (más de 200 opciones), no solo los 15 campos visuales que migraba la v0.9.11. Esto incluye controles, sonido, idioma, accesibilidad, gráficas, packs activos y otras preferencias.
- Mantiene `config/` completo con menús de FancyMenu y sus recursos, Sodium, Iris, respackopts, sonidos, Easy mappings, REI, otros mods y perfiles de Xaero en `config/xaero/`. Se descargan con EML desde Drive.
- Se importa el `icon.png` oficial del modpack raíz a la instancia aislada, con backup si ya había uno.
- En la PRIMERA ejecución de la v0.9.12 se respalda el viejo `options.txt` en `config/chilly-willy/backups/options-before-full-master-v0912.txt` y se reemplazan preferencias anteriores por las maestras. En las siguientes ejecuciones se preservan ajustes personalizados manualmente.

## Datos personales excluidos

- **No** incluye ninguna carpeta raíz `xaero/` (waypoints/mapas y regiones exploradas), `XaeroWaypoints_BACKUP...`, `saves/`, `logs/`, `screenshots/`, `showdown/`, `cobblemon-battle-logs/`, `catchrate-logs/`, `.fabric/` o `fancymenu_data/`.
- Conserva los ajustes de mapas contenidos en `config/xaero/`, pero rechaza cualquier subdirectorio específico de waypoints, regiones exploradas, estadísticas o progreso.
- Tampoco distribuye cachés de nombres, servidores guardados de una cuenta, contraseñas/credenciales o archivos de datos personales. **Sí** incluye las preferencias individuales, como volúmenes por jugador, favoritos de REI y variables de FancyMenu, tal como pediste.
- Los Pokémon, logros, estadísticas y mundos de cada cuenta **no** se importan ni se eliminan del equipo de otro jugador. La colección real del servidor sigue en el servidor.
- Los mods y resourcepacks que crean Pokémon, modelos, texturas y animaciones sí se incluyen, porque no son colecciones individuales.

## IMPORTANTE

Esta versión requiere publicar el `apps-script/Code.gs` v6 como **nueva versión de la implementación existente** de Apps Script, preservando exactamente la URL `/exec`. Si no está publicada, el launcher explica por qué se detiene antes de instalar un manifiesto potencialmente inseguro.

## Distribución

El nuevo paquete de compilación remota vuelve a usar el GitHub Actions existente y crea la Release `v0.9.12` como **borrador**. No publica ni activa automáticamente el Auto-Updater hasta que la pruebes y publiques.
