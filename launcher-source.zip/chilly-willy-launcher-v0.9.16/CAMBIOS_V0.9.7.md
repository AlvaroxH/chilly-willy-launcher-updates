# v0.9.7 — Shaders desde Google Drive

- Se agregó `shaderpacks/` al manifiesto publicado por Apps Script.
- La carpeta principal de shaders es `COBBLEVERSE - Shaders`; la variante `High Quality` queda descargada como alternativa.
- El launcher activa shaders en `config/iris.properties` al iniciar, una vez descargados, respetando ajustes manuales.
- Se conserva el archivo de shader descargado en la instancia aislada.
- Para usar este cambio, hay que reemplazar el Code.gs de la implementación existente por el nuevo y publicar una nueva versión con la misma URL.
- Google Drive no es ideal para miles de archivos: una carpeta de shaders comprimida como .zip resulta más eficiente.
- El setup.exe no se compila en este entorno: requiere Electron y electron-builder con dependencias disponibles en un equipo de compilación.
