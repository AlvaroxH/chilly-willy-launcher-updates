// Elección y migración de la carpeta de Minecraft para EML Lib 2.7.x.
// EML usa %APPDATA%\\.cobbleverse como raíz; una junction de Windows permite
// almacenar todos los archivos (Java, assets, mods, saves) en otra unidad.
import path from 'node:path';
import { lstat, realpath, readdir, rename, rm, rmdir, unlink, cp, mkdir, stat, statfs, symlink, access } from 'node:fs/promises';
import { constants } from 'node:fs';
import { randomUUID } from 'node:crypto';

export const legacyMinecraftRoot = (appData) => path.join(appData, '.cobbleverse');
export const suggestedGamePath = (home) => path.join(home, 'Games', 'Cobbleverse');
async function existing(p) { try { return await lstat(p); } catch (err) { if (err?.code === 'ENOENT') return null; throw err; } }
function samePath(a, b) { return path.resolve(a).replace(/[\\/]$/, '').toLowerCase() === path.resolve(b).replace(/[\\/]$/, '').toLowerCase(); }
function isInside(parent, child) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..' + path.sep) && rel !== '..' && !path.isAbsolute(rel));
}
async function walkStats(p) {
  let files = 0, bytes = 0, directories = 0;
  const visit = async (root) => {
    for (const item of await readdir(root, {withFileTypes:true})) {
      const target = path.join(root, item.name);
      if (item.isSymbolicLink()) throw new Error(`El juego contiene un enlace interno (${item.name}); no se moverá automáticamente.`);
      if (item.isDirectory()) { directories++; await visit(target); }
      else if (item.isFile()) { const st = await stat(target); files++; bytes += st.size; }
      else throw new Error('Hay archivos especiales que no se pueden migrar de manera segura.');
    }
  };
  await visit(p);
  return {files, bytes, directories};
}
function requireSafeDestination(source, target, legacy) {
  if (typeof target !== 'string' || !path.isAbsolute(target) || target.trim().length < 4) throw new Error('Elegí una carpeta absoluta en un disco local, como D:\\Juegos\\Cobbleverse.');
  if (isInside(source, target) || isInside(target, source) || isInside(legacy, target) || isInside(target, legacy)) throw new Error('Elegí otra carpeta: la nueva ubicación no debe contener la carpeta actual ni estar dentro de ella.');
  if (path.parse(target).root.toLowerCase() === path.resolve(target).toLowerCase()) throw new Error('Elegí una subcarpeta, no la raíz completa del disco.');
}
// Windows puede devolver EPERM cuando mkdir(recursive:true) recibe la raíz
// de un disco que YA existe (p. ej. D:\\). No recrear raíces de unidad o UNC.
export function parentDirectoryNeedsCreation(destination, platform = process.platform) {
  const paths = platform === 'win32' ? path.win32 : path.posix;
  const parent = paths.dirname(paths.resolve(destination));
  const root = paths.parse(parent).root;
  return paths.normalize(parent).toLowerCase() !== paths.normalize(root).toLowerCase();
}
async function unlinkDirectoryLink(link) {
  // En Windows las junctions son directorios reparse; rmdir quita solamente la unión.
  if (process.platform === 'win32') await rmdir(link);
  else await unlink(link);
}
async function createLink(link, dest) {
  // En Windows junction para discos distintos sin exigir permisos de administrador.
  await symlink(dest, link, process.platform === 'win32' ? 'junction' : 'dir');
}
/**
 * Mueve el juego conservando saves y configuraciones. Solo borra el origen luego
 * de copiar/verificar, conectar la junction y comprobar que apunta al destino.
 * No toca los datos de login cifrados del launcher.
 */
export async function migrateMinecraftLocation({appData, destination, progress = () => {}}) {
  const legacy = legacyMinecraftRoot(appData);
  const desired = path.resolve(destination);
  const linkStat = await existing(legacy);
  const origin = linkStat?.isSymbolicLink() ? await realpath(legacy) : legacy;
  if (samePath(origin, desired)) return {path:desired, alreadyThere:true, copied:false, oldLocation:null};
  requireSafeDestination(origin, desired, legacy);
  let destStat = await existing(desired);
  if (destStat?.isSymbolicLink()) throw new Error('No elijas un enlace de Windows como carpeta de destino.');
  if (destStat && !destStat.isDirectory()) throw new Error('La ruta elegida es un archivo, no una carpeta.');
  if (destStat && (await readdir(desired)).length) throw new Error('Elegí una carpeta nueva o vacía para evitar sobrescribir otros datos.');
  // Una raíz existente no debe pasarse a mkdir: en Windows produce EPERM.
  const parent = path.dirname(desired);
  if (parentDirectoryNeedsCreation(desired)) await mkdir(parent, {recursive:true});
  await access(parent, constants.W_OK);
  const stage = `${desired}.chilly-copiando-${randomUUID().slice(0,8)}`;
  const backup = `${legacy}.chilly-respaldo-${randomUUID().slice(0,8)}`;
  let staged = false, originRenamed = false, linkMade = false, destinationReady = false;
  const sourceIsRealDirectory = Boolean(linkStat && !linkStat.isSymbolicLink());
  const originExists = Boolean(await existing(origin));
  try {
    if (originExists) {
      progress('Revisando los archivos de Minecraft…');
      const before = await walkStats(origin);
      // Evita iniciar copias imposibles cuando el destino no tiene capacidad suficiente.
      try {
        const space = await statfs(path.dirname(desired));
        if (space.bavail * space.bsize < before.bytes + 64 * 1024 * 1024) {
          throw new Error('El disco elegido no tiene espacio suficiente para mover Minecraft.');
        }
      } catch (err) {
        if (String(err?.message||'').includes('no tiene espacio suficiente')) throw err;
        // Algunos sistemas de archivos no implementan statfs; la copia sigue siendo segura.
      }
      progress(`Copiando ${before.files} archivos al disco elegido. No cierres el launcher…`);
      // Copia primero: si un archivo no se puede leer, no se toca la instalación actual.
      await cp(origin, stage, {recursive:true,force:false,errorOnExist:true,preserveTimestamps:true});
      staged = true;
      const after = await walkStats(stage);
      if (before.files !== after.files || before.bytes !== after.bytes || before.directories !== after.directories) {
        throw new Error('La copia no pasó la validación de cantidad y tamaño de archivos.');
      }
    } else {
      await mkdir(stage, {recursive:true}); staged = true;
    }
    // Solo una carpeta vacía puede estar ya creada por el selector.
    if (destStat) await rmdir(desired);
    await rename(stage, desired); staged = false; destinationReady = true;
    if (sourceIsRealDirectory) { await rename(legacy, backup); originRenamed = true; }
    else if (linkStat?.isSymbolicLink()) await unlinkDirectoryLink(legacy);
    await createLink(legacy, desired); linkMade = true;
    if (!samePath(await realpath(legacy), await realpath(desired))) throw new Error('La unión de Windows no apunta a la carpeta nueva.');
    if (originRenamed) {
      // Liberación de espacio después de verificar la nueva ubicación, sin borrar datos en destino.
      progress('Nueva ubicación verificada. Liberando espacio en el disco anterior…');
      try { await rm(backup, {recursive:true,force:false}); }
      catch { return {path:desired, copied:originExists, oldLocation:backup, cleanupNeeded:true}; }
    }
    return {path:desired, copied:originExists, oldLocation:linkStat?.isSymbolicLink()?origin:null, cleanupNeeded:linkStat?.isSymbolicLink()};
  } catch (err) {
    if (linkMade) {
      // Si la unión ya funciona, se prioriza mantener la nueva ubicación y no eliminarla.
      return {path:desired, copied:originExists, oldLocation:originRenamed?backup:(linkStat?.isSymbolicLink()?origin:null), cleanupNeeded:originRenamed||Boolean(linkStat?.isSymbolicLink()), warning:String(err?.message||err)};
    }
    if (originRenamed) {
      try { await rename(backup, legacy); } catch { /* preservar respaldo */ }
    } else if (linkStat?.isSymbolicLink() && !(await existing(legacy))) {
      try { await createLink(legacy, origin); } catch { /* no borrar jamás el origen */ }
    }
    // Eliminamos solo el staging nunca los datos originales.
    if (staged) { try { await rm(stage, {recursive:true,force:true}); } catch { /* staging recuperable */ } }
    throw err;
  }
}

export async function describeMinecraftPath(appData) {
  const legacy = legacyMinecraftRoot(appData);
  const info = await existing(legacy);
  if (!info) return {path:legacy, installed:false, custom:false};
  const actual = info.isSymbolicLink() ? await realpath(legacy) : legacy;
  return {path:actual, installed:true, custom:info.isSymbolicLink()};
}
