/**
 * Caché conservadora de arranque de Minecraft.
 * Sólo omite la validación completa del modpack cuando el último arranque completo
 * tuvo éxito, las versiones coinciden y siguen presentes los mods originales.
 * No se guardan tokens ni datos de jugadores. Nunca elimina archivos del usuario.
 */
import fs from 'node:fs';
import path from 'node:path';

export const REMOTE_CHECK_MS = 2 * 60 * 60 * 1000;
export const FULL_RECHECK_MS = 24 * 60 * 60 * 1000;
const SCHEMA = 1;
const MAX_BYTES = 512 * 1024;
const CHECK_FILES = ['options.txt'];
const markerName = 'launch-fast-cache-v1.json';
export const cacheFile = userData => path.join(userData, markerName);

export function readLaunchCache(userData) {
  try {
    const filename = cacheFile(userData);
    const stat = fs.statSync(filename);
    if (!stat.isFile() || stat.size > MAX_BYTES) return null;
    const entry = JSON.parse(fs.readFileSync(filename, 'utf8'));
    if (entry?.schema !== SCHEMA || !path.isAbsolute(entry.instanceRoot) ||
        !Number.isFinite(entry.checkedAt) || !Number.isFinite(entry.syncedAt) ||
        typeof entry?.manifestFingerprint !== 'string' ||
        !entry?.pack || !Array.isArray(entry.pack.modFiles) ||
        !Array.isArray(entry.pack.resourcepackFiles) ||
        !entry?.settings || entry.pack.modFiles.length < 1 ||
        entry.pack.modFiles.length > 2000) return null;
    return entry;
  } catch { return null; }
}

/** Probar por metadatos, sin leer gigabytes ni calcular hashes de mods. */
export function installedPackIntact(entry, settings) {
  if (!entry || !settings ||
      entry.settings.minecraftVersion !== settings.minecraftVersion ||
      entry.settings.fabricLoaderVersion !== settings.fabricLoaderVersion ||
      entry.settings.modpackManifestUrl !== settings.modpackManifestUrl) return false;
  try {
    if (!fs.statSync(entry.instanceRoot).isDirectory()) return false;
    for (const rel of CHECK_FILES) {
      if (!fs.statSync(path.join(entry.instanceRoot, ...rel.split('/'))).isFile()) return false;
    }
    for (const file of entry.pack.modFiles) {
      if (!file || typeof file.name !== 'string' ||
          !/^[^\\/:*?"<>|\x00-\x1f]{1,230}\.jar$/i.test(file.name) ||
          !Number.isSafeInteger(file.size) || file.size <= 0) return false;
      const stat = fs.statSync(path.join(entry.instanceRoot, 'mods', file.name));
      if (!stat.isFile() || stat.size !== file.size) return false;
    }
    return true;
  } catch { return false; }
}

export function launchMode({entry, settings, remotePack = null, force = false, now = Date.now()}) {
  if (force || entry?.pendingUpdate || !installedPackIntact(entry, settings)) return 'full';
  if (now - entry.syncedAt > FULL_RECHECK_MS || now < entry.syncedAt) return 'full';
  if (remotePack && remotePack.fingerprint !== entry.manifestFingerprint) return 'full';
  if (!remotePack && (now - entry.checkedAt > REMOTE_CHECK_MS || now < entry.checkedAt)) return 'check-remote';
  return 'fast';
}

function atomicWrite(file, text) {
  fs.mkdirSync(path.dirname(file), {recursive: true});
  const tmp = `${file}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(tmp, text, {encoding:'utf8',flag:'wx'});
    fs.renameSync(tmp, file);
  } finally {try { fs.unlinkSync(tmp); } catch {}}
}

function publicPack(pack) {
  return {
    ok:true, fullPack:pack.fullPack, fullShaderPack:pack.fullShaderPack,
    completeMaster:pack.completeMaster, version:pack.version,
    counts:pack.counts, count:pack.count, totalPackMiB:pack.totalPackMiB,
    resourcepackFiles:pack.resourcepackFiles, modFiles:pack.modFiles,
    fingerprint:pack.fingerprint
  };
}
export function saveFullLaunch(userData, {pack, settings, instanceRoot, now = Date.now()}) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('Raíz de Minecraft inválida.');
  const data = {
    schema:SCHEMA, instanceRoot, checkedAt:now, syncedAt:now, pendingUpdate:false,
    manifestFingerprint:pack.fingerprint, pack:publicPack(pack),
    settings:{minecraftVersion:settings.minecraftVersion,
      fabricLoaderVersion:settings.fabricLoaderVersion,
      modpackManifestUrl:settings.modpackManifestUrl}
  };
  // No marcamos como terminado algo que no tiene mods/configuraciones completos.
  if (!installedPackIntact(data, settings)) return false;
  atomicWrite(cacheFile(userData), JSON.stringify(data));
  return true;
}
export function markRemoteChecked(userData, cache, remotePack, now = Date.now()) {
  if (!cache || !remotePack) return false;
  const changed = remotePack.fingerprint !== cache.manifestFingerprint;
  const updated = {...cache, checkedAt:now, pendingUpdate:changed};
  atomicWrite(cacheFile(userData), JSON.stringify(updated));
  return !changed;
}

