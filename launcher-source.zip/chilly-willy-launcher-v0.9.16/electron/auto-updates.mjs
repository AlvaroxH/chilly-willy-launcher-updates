// Actualizaciones desde GitHub Releases para Setup NSIS instalado en Windows.
// El usuario acepta UNA vez con «Actualizar»: descarga dentro del launcher,
// luego instalación silenciosa y reapertura automática (sin asistente NSIS).
// La fase de instalación se ejecuta tras cerrar Electron: su progreso no es
// observable desde la ventana, por eso no se simula un porcentaje de instalación.
export const UPDATE_REPOSITORY = Object.freeze({owner:'AlvaroxH', repo:'chilly-willy-launcher-updates'});
export function updaterSupported(app, env = process.env, platform = process.platform) {
  return Boolean(app.isPackaged && platform === 'win32' && !env.PORTABLE_EXECUTABLE_FILE);
}
export function updatePercent(progress) {
  const value = Number(progress?.percent);
  return Number.isFinite(value) ? Math.max(0, Math.min(100, Math.round(value))) : null;
}
export function createUpdateManager({
  app,
  isBusy = () => false,
  emit = () => {},
  env = process.env,
  platform = process.platform,
  schedule = (callback, delay) => setTimeout(callback, delay),
  loadUpdater = async () => {
    const mod = await import('electron-updater');
    return mod.autoUpdater ?? mod.default?.autoUpdater;
  }
}) {
  const supported = updaterSupported(app, env, platform);
  let updater = null;
  let initialized = false;
  let checking = null;
  let downloading = null;
  let approvedByPlayer = false;
  let installingScheduled = false;
  let state = {
    phase: supported ? 'idle' : 'unsupported', supported,
    version: null, percent: null,
    message: supported ? 'Buscando actualizaciones en GitHub Releases…' :
      'Las actualizaciones automáticas funcionan con el Setup instalado de Windows, no con el Portable.'
  };
  const send = (patch) => { state = {...state, ...patch}; emit({...state}); return {...state}; };
  const failure = (context, e) => {
    approvedByPlayer = false;
    installingScheduled = false;
    send({phase:'error',percent:null,message:'No se pudo completar la actualización. Podés reintentar sin reinstalar el launcher.'});
    console.warn(context, e?.message ? String(e.message).slice(0,180) : 'error desconocido');
  };
  const silentInstall = () => {
    if (!approvedByPlayer || !updater || state.phase !== 'ready' || installingScheduled) return;
    if (isBusy()) {
      send({phase:'ready',percent:100,message:'Descarga completa. Esperá a que Minecraft termine de iniciarse y pulsá «Finalizar actualización».'});
      return;
    }
    installingScheduled = true;
    send({phase:'installing',percent:100,message:'Descarga completa. Aplicando actualización en segundo plano; el launcher se cerrará y volverá a abrirse solo…'});
    // Dar un instante a Electron para pintar el 100% antes de cerrar la ventana.
    schedule(() => {
      if (state.phase !== 'installing' || !approvedByPlayer) return;
      try {
        // electron-updater 6 + NSIS: (isSilent, isForceRunAfter).
        // /S evita el asistente; forceRunAfter reabre el launcher instalado.
        updater.quitAndInstall(true, true);
      } catch (e) { failure('Instalación silenciosa:', e); }
    }, 900);
  };
  async function setup() {
    if (!supported || initialized) return;
    const candidate = await loadUpdater();
    if (!candidate) throw new Error('No se pudo cargar electron-updater.');
    updater = candidate;
    // Sin descarga ni instalación hasta que el jugador pulse «Actualizar».
    updater.autoDownload = false;
    updater.autoInstallOnAppQuit = false; // API electron-updater v6.
    updater.allowPrerelease = false;
    updater.allowDowngrade = false;
    updater.on('checking-for-update', () => send({phase:'checking',message:'Buscando nuevas versiones…',percent:null}));
    updater.on('update-available', (info) => {
      approvedByPlayer = false;
      send({phase:'available',version:info?.version ?? null,percent:0,message:`Hay una nueva versión (${info?.version ?? ''}). Pulsá «Actualizar» para descargarla e instalarla automáticamente.`});
    });
    updater.on('update-not-available', () => send({phase:'current',version:app.getVersion(),percent:null,message:`Estás usando la versión más reciente (${app.getVersion()}).`}));
    updater.on('download-progress', (info) => send({phase:'downloading',percent:updatePercent(info),message:'Descargando actualización de Chilly Willy Launcher…'}));
    updater.on('update-downloaded', (info) => {
      send({phase:'ready',version:info?.version ?? state.version,percent:100,message:'Descarga completa. Preparando instalación silenciosa…'});
      if (approvedByPlayer) silentInstall();
    });
    updater.on('error', (e) => failure('Fallo de autoactualización:', e));
    initialized = true;
  }
  return {
    getState: () => ({...state}),
    async check({force = false} = {}) {
      if (!supported) return {...state};
      if (['available','ready','downloading','installing'].includes(state.phase)) return {...state};
      if (checking) return checking;
      if (!force && state.phase === 'current') return {...state};
      checking = (async () => {
        try {
          await setup();
          send({phase:'checking',percent:null,message:'Buscando actualizaciones en GitHub…'});
          await updater.checkForUpdates();
        } catch (e) { failure('Comprobación de actualización:', e); }
        finally { checking = null; }
        return {...state};
      })();
      return checking;
    },
    async install() {
      if (!supported || !['available','ready','downloading'].includes(state.phase)) {
        throw new Error('No hay una actualización disponible para instalar.');
      }
      if (isBusy()) throw new Error('Esperá a que termine de iniciar Minecraft antes de actualizar.');
      if (state.phase === 'ready') {
        approvedByPlayer = true;
        silentInstall();
        return {ok:true};
      }
      if (state.phase === 'downloading') return {ok:true};
      if (downloading) return downloading;
      if (!updater) throw new Error('El servicio de actualizaciones no está listo.');
      approvedByPlayer = true;
      send({phase:'downloading',percent:0,message:'Descargando actualización de Chilly Willy Launcher…'});
      downloading = (async () => {
        try {
          await updater.downloadUpdate();
        } catch (e) { failure('Descarga de actualización:', e); }
        finally { downloading = null; }
        return {ok:state.phase !== 'error'};
      })();
      return downloading;
    }
  };
}
