/**
 * Chilly Willy Launcher - teclas predeterminadas de Cobbleverse.
 * Default Options guarda sus controles en config/defaultoptions/keybindings.txt.
 * Nuestra activación automática de resource packs genera options.txt antes de
 * arrancar Minecraft; sin este paso, Default Options puede omitir el preset.
 *
 * Migración inicial: aplica el preset una sola vez, respaldando options.txt.
 * Ejecuciones siguientes: actualiza las teclas que sigan con el valor gestionado
 * anteriormente, respetando todas las modificaciones posteriores del jugador.
 */
import fs from 'node:fs';
import path from 'node:path';

const BINDING = /^key_[^:\r\n]{1,180}:key\.(?:keyboard|mouse)\.[a-zA-Z0-9_.-]{1,100}$/;
const MAX_PRESET_BYTES = 80 * 1024;
const VERSION = '3955'; // Minecraft 1.21.1

function parseLines(text) {
  const bom = text.startsWith('\uFEFF') ? '\uFEFF' : '';
  const plain = bom ? text.slice(1) : text;
  return {bom, eol: plain.includes('\r\n') ? '\r\n' : '\n', lines: plain.split(/\r?\n/).filter(Boolean)};
}
function getOption(lines, key) {
  const prefix = `${key}:`;
  const index = lines.findIndex(line => line.startsWith(prefix));
  return index < 0 ? undefined : lines[index].slice(prefix.length);
}
function setOption(lines, key, value) {
  const prefix = `${key}:`;
  const index = lines.findIndex(line => line.startsWith(prefix));
  if (index < 0) lines.push(prefix + value);
  else {
    lines[index] = prefix + value;
    for (let i = lines.length - 1; i > index; i--) {
      if (lines[i].startsWith(prefix)) lines.splice(i,1);
    }
  }
}
function safeReadSmallFile(file, max) {
  const stat = fs.statSync(file);
  if (!stat.isFile() || stat.size > max) throw new Error(`Archivo de controles demasiado grande o inválido: ${path.basename(file)}.`);
  return fs.readFileSync(file,'utf8');
}
export function parseDefaultKeybindings(text) {
  const map = new Map();
  for (const raw of String(text).split(/\r?\n/)) {
    const line = raw.trim();
    if (!BINDING.test(line)) continue;
    const index = line.indexOf(':');
    map.set(line.slice(0,index), line.slice(index+1));
  }
  return map;
}
function atomicWrite(file, data) {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  const temp = `${file}.tmp-${process.pid}-${Date.now()}`;
  try {
    fs.writeFileSync(temp, data, {encoding:'utf8', flag:'wx'});
    fs.renameSync(temp,file);
  } finally { try {fs.unlinkSync(temp);} catch {} }
}

/** Aplica los controles del modpack solo al directorio aislado de Minecraft. */
export function applyPackKeybindings(instanceRoot) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) {
    throw new Error('No se pudo localizar la instancia aislada de Minecraft.');
  }
  const presetPath = path.join(instanceRoot, 'config', 'defaultoptions', 'keybindings.txt');
  if (!fs.existsSync(presetPath)) {
    throw new Error('Falta config/defaultoptions/keybindings.txt en la instancia. Revisá que Drive sincronice config/ completo.');
  }
  const defaults = parseDefaultKeybindings(safeReadSmallFile(presetPath, MAX_PRESET_BYTES));
  if (defaults.size < 10) throw new Error('El preset de teclas de Drive está vacío o incompleto.');

  const optionsPath = path.join(instanceRoot, 'options.txt');
  const markerPath = path.join(instanceRoot, 'config', 'chilly-willy', 'keybinds-state.json');
  const alreadyHadOptions = fs.existsSync(optionsPath);
  const priorText = alreadyHadOptions ? safeReadSmallFile(optionsPath, 1024*1024) : '';
  let initialText = priorText;
  if (!alreadyHadOptions) {
    // En la primera instalación incorporamos también las opciones originales
    // (distancia, vídeo, sonido) que Default Options exportó para el modpack.
    const masterOptions = path.join(instanceRoot,'presets','options.txt');
    const defaultsOptions = path.join(instanceRoot,'config','defaultoptions','options.txt');
    if (fs.existsSync(masterOptions)) initialText = safeReadSmallFile(masterOptions,MAX_PRESET_BYTES);
    else if (fs.existsSync(defaultsOptions)) initialText = safeReadSmallFile(defaultsOptions,MAX_PRESET_BYTES);
  }
  const parsed = parseLines(initialText);
  if (getOption(parsed.lines,'version') === undefined) parsed.lines.unshift(`version:${VERSION}`);

  let managed = {};
  let first = !fs.existsSync(markerPath);
  if (!first) {
    try {
      const state = JSON.parse(safeReadSmallFile(markerPath, MAX_PRESET_BYTES));
      if (!state || state.schema !== 1 || typeof state.managed !== 'object' || Array.isArray(state.managed)) throw new Error('Marca corrupta');
      managed = state.managed;
    } catch {
      // No pisar teclas personales si la marca quedó corrupta.
      throw new Error('No se pudo leer el estado de teclas de Cobbleverse. Revisá config/chilly-willy/keybinds-state.json.');
    }
  }

  let applied = 0;
  const nextManaged = {};
  for (const [key,value] of defaults) {
    const current = getOption(parsed.lines,key);
    const oldValue = managed[key];
    // Primera aplicación para este perfil: establecer los valores del modpack.
    // En siguientes ejecuciones, preservar una reasignación manual del jugador.
    if (first || current === undefined || current === oldValue) {
      if (current !== value) { setOption(parsed.lines,key,value); applied++; }
      nextManaged[key] = value;
    } else {
      nextManaged[key] = oldValue ?? value;
    }
  }

  const newText = parsed.bom + parsed.lines.join(parsed.eol) + parsed.eol;
  const backupFile = path.join(instanceRoot, 'options.txt.chilly-willy-before-keybindings.bak');
  if (first && alreadyHadOptions && !fs.existsSync(backupFile)) {
    fs.copyFileSync(optionsPath,backupFile,fs.constants.COPYFILE_EXCL);
  }
  if (newText !== priorText) atomicWrite(optionsPath,newText);
  const newMarker = JSON.stringify({schema:1,managed:nextManaged},null,2) + '\n';
  const oldMarker = fs.existsSync(markerPath) ? fs.readFileSync(markerPath,'utf8') : null;
  if (oldMarker !== newMarker) atomicWrite(markerPath,newMarker);
  return {applied,total:defaults.size,first,optionsPath,backupFile: first && alreadyHadOptions ? backupFile : null};
}
