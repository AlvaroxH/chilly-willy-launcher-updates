/** Gestiona la selección de shaders de Iris (Minecraft Fabric 1.21.1).
 * No fuerza el modo High Quality ni sobrescribe la elección manual del jugador.
 * La carpeta shaderpacks se descarga mediante EML desde el manifiesto de Drive.
 */
import fs from 'node:fs';
import path from 'node:path';

const DEFAULT_SHADER = 'COBBLEVERSE - Shaders';
const HIGH_SHADER = 'COBBLEVERSE - Shaders (High Quality)';
const MARKER = 'config/chilly-willy/shader-settings.json';

function atomicWrite(file, contents) {
  fs.mkdirSync(path.dirname(file), {recursive: true});
  const temporary = file + `.tmp-${process.pid}-${Date.now()}`;
  try { fs.writeFileSync(temporary, contents, {encoding:'utf8', flag:'wx'}); fs.renameSync(temporary, file); }
  finally { try {fs.unlinkSync(temporary)} catch {} }
}
function validShaderpack(dir) {
  try { return fs.statSync(path.join(dir, 'shaders')).isDirectory(); } catch { return false; }
}
/** Se llama inmediatamente antes de iniciar Minecraft, después de descargar. */
export function activateCobbleverseShaders(instanceRoot) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) throw new Error('La instancia no tiene una ruta válida para shaders.');
  const packsRoot = path.join(instanceRoot, 'shaderpacks');
  const normal = path.join(packsRoot,DEFAULT_SHADER);
  const high = path.join(packsRoot,HIGH_SHADER);
  const zip = path.join(packsRoot, 'ComplementaryUnbound_r5.8.1.zip');
  const hasNormal = validShaderpack(normal);
  const hasHigh = validShaderpack(high);
  const hasZip = fs.existsSync(zip) && fs.statSync(zip).isFile();
  if (!hasNormal && !hasHigh && !hasZip) {
    throw new Error('No se descargó ningún shaderpack válido. Revisá shaderpacks/ y el Apps Script.');
  }
  const preset = hasNormal ? DEFAULT_SHADER : hasZip ? path.basename(zip) : HIGH_SHADER;
  const file = path.join(instanceRoot, 'config','iris.properties');
  const previous = fs.existsSync(file) ? fs.readFileSync(file, 'utf8') : '';
  const newLine = previous.includes('\r\n') ? '\r\n' : '\n';
  const lines = previous.split(/\r?\n/).filter(Boolean);
  const marker = path.join(instanceRoot, MARKER);
  let oldManaged;
  if (fs.existsSync(marker)) {
    try { const state=JSON.parse(fs.readFileSync(marker,'utf8')); oldManaged=state.managed; }
    catch { throw new Error('Marcador de shaders inválido; no se modificarán preferencias personales.'); }
  }
  const lookup = key => lines.find(line=>line.startsWith(key+'='))?.slice(key.length+1);
  const setValue = (key,val)=> {const i=lines.findIndex(line=>line.startsWith(key+'='));if(i<0)lines.push(key+'='+val);else lines[i]=key+'='+val;};
  const current = lookup('shaderPack');
  // Si el jugador ya seleccionó otro shader, se respeta.
  const shouldSet = !current || current === oldManaged || (oldManaged === undefined && current === DEFAULT_SHADER);
  if (shouldSet) {
    setValue('shaderPack', preset);
    // En la primera configuración, activar Iris aunque el preset de Drive trajera
    // enableShaders=false. En ejecuciones siguientes respetar si el usuario lo apagó.
    if (!fs.existsSync(marker) || !lookup('enableShaders')) setValue('enableShaders','true');
  } else if (!lookup('enableShaders')) { setValue('enableShaders','true'); }
  if (!fs.existsSync(marker) && previous) {
    const backup = file + '.chilly-willy-before-shaders.bak';
    if (!fs.existsSync(backup)) fs.copyFileSync(file,backup,fs.constants.COPYFILE_EXCL);
  }
  const result = lines.join(newLine) + newLine;
  if (result !== previous) atomicWrite(file,result);
  atomicWrite(marker,JSON.stringify({schema:1,managed:shouldSet ? preset : oldManaged ?? null})+'\n');
  return {selected:lookup('shaderPack') ?? preset, configured:shouldSet,hasNormal,hasHigh,hasZip};
}
