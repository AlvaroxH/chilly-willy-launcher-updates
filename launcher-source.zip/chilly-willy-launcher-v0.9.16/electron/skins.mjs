// Proveedor de avatares públicos. Nunca se usa el token de Microsoft.
// El protocolo Status no certifica que el UUID publicado por un servidor
// offline sea un UUID oficial Mojang; en la lista de jugadores preferimos el nick.
const USERNAME = /^[A-Za-z0-9_]{3,16}$/;
const UUID = /^[a-f0-9]{8}-?(?:[a-f0-9]{4}-?){3}[a-f0-9]{12}$/i;
const MAX_BYTES = 262144;
const SUCCESS_TTL = 30 * 60 * 1000;
const RETRY_TTL = 2 * 60 * 1000;
const cache = new Map();

export function avatarCandidates(identity) {
  const name = typeof identity?.name === 'string' && USERNAME.test(identity.name) ? identity.name : null;
  const uuid = typeof identity?.uuid === 'string' && UUID.test(identity.uuid)
    ? identity.uuid.replaceAll('-', '').toLowerCase() : null;
  if (identity?.type === 'guest') return [];
  if (!name && !uuid) return [];
  const urls = [];
  const byName = () => {
    if (!name) return;
    urls.push(`https://mc-heads.net/avatar/${encodeURIComponent(name)}/64`);
    urls.push(`https://api.mcskin.me/face/${encodeURIComponent(name)}?size=64`);
  };
  const byUuid = () => {
    if (!uuid) return;
    urls.push(`https://mc-heads.net/avatar/${uuid}/64`);
    urls.push(`https://crafatar.com/avatars/${uuid}?size=64&overlay=true`);
  };
  // Cuenta Microsoft sí entrega identidad autenticada, preferimos su UUID oficial.
  if (identity?.source === 'account' && uuid) { byUuid(); byName(); }
  else { byName(); if (!name) byUuid(); }
  return urls;
}

function imageMime(data) {
  if (data.length >= 8 && data.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10]))) return 'image/png';
  if (data.length >= 3 && data[0] === 255 && data[1] === 216 && data[2] === 255) return 'image/jpeg';
  if (data.length >= 12 && data.toString('ascii',0,4) === 'RIFF' && data.toString('ascii',8,12) === 'WEBP') return 'image/webp';
  return null;
}

async function readImage(response) {
  if (!response.ok || !response.body) return null;
  if (Number(response.headers.get('content-length') || 0) > MAX_BYTES) return null;
  const headerType = response.headers.get('content-type') || '';
  if (headerType && !/^image\/(png|jpeg|webp|octet-stream)/i.test(headerType)) return null;
  const pieces = [];
  let size = 0;
  const reader = response.body.getReader();
  try {
    while (true) {
      const {value,done} = await reader.read();
      if (done) break;
      size += value.length;
      if (size > MAX_BYTES) return null;
      pieces.push(Buffer.from(value));
    }
  } finally { await reader.cancel().catch(() => {}); }
  const bytes = Buffer.concat(pieces);
  const mime = imageMime(bytes);
  return mime ? `data:${mime};base64,${bytes.toString('base64')}` : null;
}

export async function fetchSkin(identity, fetchImpl = fetch) {
  const urls = avatarCandidates(identity);
  for (const url of urls) {
    try {
      const response = await fetchImpl(url, {signal: AbortSignal.timeout(5500), headers: {accept:'image/png,image/webp,image/jpeg'}});
      const result = await readImage(response);
      if (result) return result;
    } catch { /* Probamos el siguiente servicio, sin afectar el estado del servidor. */ }
  }
  return null;
}

export function getSkinHeadData(identity) {
  const urls = avatarCandidates(identity);
  if (!urls.length) return Promise.resolve(null);
  const key = urls.join('|');
  const existing = cache.get(key);
  if (existing && existing.until > Date.now()) return existing.result;
  const work = fetchSkin(identity).then(result => {
    cache.set(key, {until: Date.now() + (result ? SUCCESS_TTL : RETRY_TTL), result: Promise.resolve(result)});
    return result;
  }).catch(() => {
    cache.delete(key);
    return null;
  });
  if (cache.size > 150) cache.clear();
  cache.set(key, {until: Date.now() + RETRY_TTL, result: work});
  return work;
}
