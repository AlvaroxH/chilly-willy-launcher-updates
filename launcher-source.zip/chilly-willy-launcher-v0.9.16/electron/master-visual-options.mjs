/**
 * Aplica el aspecto de la instalación maestra incluso a usuarios que ya jugaban
 * con versiones anteriores. Copia de seguridad primero, migración una sola vez,
 * cambios futuros solo si el jugador no modificó ese campo manualmente.
 * No modifica cuentas, controles, volumen ni parámetros delicados del hardware.
 */
import fs from 'node:fs';
import path from 'node:path';

const SCHEMA = 1;
const KEYS = new Set([
  'fov', 'fovEffectScale', 'darknessEffectScale', 'gamma',
  'graphicsMode', 'guiScale', 'biomeBlendRadius', 'mipmapLevels',
  'particles', 'entityShadows', 'screenEffectScale', 'glintSpeed',
  'glintStrength', 'renderClouds', 'ao', 'bobView'
]);
const MARKER = path.join('config', 'chilly-willy', 'master-visual-state.json');

function readLimited(file, maxSize=1024*1024) {
  const stat=fs.statSync(file);
  if (!stat.isFile() || stat.size>maxSize) throw new Error('Archivo de opciones visuales demasiado grande.');
  return fs.readFileSync(file,'utf8');
}
function parse(source) {
  const bom=source.startsWith('\uFEFF')?'\uFEFF':'';
  const text=bom?source.slice(1):source;
  return {bom,eol:text.includes('\r\n')?'\r\n':'\n', lines:text.split(/\r?\n/).filter(Boolean)};
}
function get(lines,key) {
  const found=lines.find(line=>line.startsWith(key+':'));
  return found===undefined ? undefined : found.slice(key.length+1);
}
function put(lines,key,value) {
  const at=lines.findIndex(line=>line.startsWith(key+':'));
  if(at===-1) lines.push(key+':'+value);
  else {
    lines[at]=key+':'+value;
    for(let i=lines.length-1;i>at;i--) if(lines[i].startsWith(key+':')) lines.splice(i,1);
  }
}
function validate(key,value) {
  // Solo números, booleanos y el valor entre comillas de renderClouds.
  if (!/^[a-zA-Z0-9_."-]{1,40}$/.test(value)) return false;
  if (['entityShadows','ao','bobView'].includes(key)) return /^(true|false)$/.test(value);
  if (key==='renderClouds') return /^(true|false|"true"|"false"|"fast"|"fancy")$/.test(value);
  return /^-?\d+(?:\.\d+)?$/.test(value);
}
function atomicWrite(file,content){
  fs.mkdirSync(path.dirname(file),{recursive:true});
  const temp=`${file}.tmp-${process.pid}-${Date.now()}`;
  try { fs.writeFileSync(temp,content,{encoding:'utf8',flag:'wx'});fs.renameSync(temp,file); }
  finally {try{fs.unlinkSync(temp)}catch{}}
}
export function applyMasterVisualPreset(instanceRoot) {
  if(typeof instanceRoot!=='string'||!path.isAbsolute(instanceRoot)) throw new Error('Ruta inválida de instancia.');
  const source=path.join(instanceRoot,'presets','options.txt');
  if(!fs.existsSync(source)) throw new Error('No se descargó presets/options.txt del modpack maestro.');
  const master=parse(readLimited(source));
  const target=path.join(instanceRoot,'options.txt');
  const existed=fs.existsSync(target);
  const original=existed?readLimited(target):'version:3955\n';
  const local=parse(original);
  const markerFile=path.join(instanceRoot,MARKER);
  const initial=!fs.existsSync(markerFile);
  let old={};
  if(!initial){
    let state;
    try{state=JSON.parse(readLimited(markerFile,64*1024));}
    catch{throw new Error('Estado de preset visual ilegible: revisar config/chilly-willy/master-visual-state.json.');}
    if(state?.schema!==SCHEMA||!state.managed||typeof state.managed!=='object'||Array.isArray(state.managed)) throw new Error('Estado de preset visual inválido.');
    old=state.managed;
  }
  let applied=0,skipped=0;
  const managed={};
  for(const key of KEYS){
    const desired=get(master.lines,key);
    if(desired===undefined||!validate(key,desired))continue;
    const current=get(local.lines,key);
    const prior=old[key];
    if(initial || current===undefined || current===prior){
      if(current!==desired){put(local.lines,key,desired);applied++;}
      managed[key]=desired;
    }else{
      // Si el jugador lo modificó después de aplicar el preset, no se sobrescribe.
      skipped++;
      managed[key]=prior??desired;
    }
  }
  const next=local.bom+local.lines.join(local.eol)+local.eol;
  let backupFile=null;
  if(next!==original){
    if(existed&&initial){
      backupFile=target+'.chilly-willy-before-visual-preset.bak';
      if(!fs.existsSync(backupFile)) fs.copyFileSync(target,backupFile,fs.constants.COPYFILE_EXCL);
    }
    atomicWrite(target,next);
  }
  atomicWrite(markerFile,JSON.stringify({schema:SCHEMA,managed},null,2)+'\n');
  return {applied,skipped,first:initial,backupFile,optionFile:target};
}
