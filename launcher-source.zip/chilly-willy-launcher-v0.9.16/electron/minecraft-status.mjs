import net from 'node:net';

function varInt(value) {
  const out = [];
  let n = value >>> 0;
  do {
    let byte = n & 0x7f;
    n >>>= 7;
    if (n) byte |= 0x80;
    out.push(byte);
  } while (n);
  return Buffer.from(out);
}
function readVarInt(buffer, offset = 0) {
  let value = 0;
  for (let i = 0; i < 5; i++) {
    if (offset + i >= buffer.length) return null;
    const b = buffer[offset + i];
    value |= (b & 0x7f) << (7 * i);
    if (!(b & 0x80)) return { value: value >>> 0, length: i + 1 };
  }
  throw new Error('VarInt inválido');
}
function packet(content) { return Buffer.concat([varInt(content.length), content]); }
function handshake(host, port) {
  const address = Buffer.from(host, 'utf8');
  const portBytes = Buffer.alloc(2); portBytes.writeUInt16BE(port);
  // Minecraft 1.21.1 uses protocol 767; status handshake only (not a login).
  return packet(Buffer.concat([varInt(0), varInt(767), varInt(address.length), address, portBytes, varInt(1)]));
}
export async function getMinecraftStatus(serverAddress, timeoutMs = 4000) {
  const match = /^([a-zA-Z0-9._-]+)(?::(\d{1,5}))?$/.exec(serverAddress || '');
  if (!match) throw new Error('Dirección del servidor incorrecta');
  const host = match[1];
  const port = match[2] ? Number(match[2]) : 25565;
  if (port < 1 || port > 65535) throw new Error('Puerto incorrecto');
  return new Promise((resolve) => {
    let done = false; let received = Buffer.alloc(0);
    const started = Date.now();
    const socket = net.createConnection({ host, port });
    const finish = (info) => {
      if (done) return;
      done = true;
      socket.destroy();
      resolve(info);
    };
    socket.setTimeout(timeoutMs, () => finish({ online: false }));
    socket.on('error', () => finish({ online: false }));
    socket.on('connect', () => socket.write(Buffer.concat([handshake(host, port), packet(varInt(0))])));
    socket.on('data', (chunk) => {
      if (done) return;
      received = Buffer.concat([received, chunk]);
      if (received.length > 131072) return finish({ online: false });
      try {
        const length = readVarInt(received);
        if (!length) return;
        if (length.value > 100000) return finish({ online: false });
        if (received.length < length.length + length.value) return;
        const payload = received.subarray(length.length, length.length + length.value);
        const id = readVarInt(payload);
        if (!id || id.value !== 0) return finish({ online: false });
        const stringLen = readVarInt(payload, id.length);
        if (!stringLen || stringLen.value > 99000) return finish({ online: false });
        const start = id.length + stringLen.length;
        if (start + stringLen.value > payload.length) return finish({ online: false });
        const decoded = JSON.parse(payload.subarray(start, start + stringLen.value).toString('utf8'));
        const players = decoded?.players;
        const online = Math.max(0, Math.floor(Number(players?.online) || 0));
        const max = Math.max(0, Math.floor(Number(players?.max) || 0));
        const sample = Array.isArray(players?.sample) ? players.sample.filter(p => typeof p?.name === 'string' && /^[A-Za-z0-9_]{3,16}$/.test(p.name)).slice(0, 12).map(p => ({
          name: p.name,
          uuid: typeof p.id === 'string' && /^[0-9a-f]{8}-?(?:[0-9a-f]{4}-?){3}[0-9a-f]{12}$/i.test(p.id) ? p.id.replace(/-/g,'').toLowerCase() : null
        })) : [];
        finish({ online: true, playersOnline: online, playersMax: max, sample, latencyMs: Date.now() - started });
      } catch { finish({ online: false }); }
    });
  });
}
