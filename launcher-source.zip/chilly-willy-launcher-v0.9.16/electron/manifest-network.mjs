/**
 * Consulta del manifiesto publicado de Cobbleverse.
 * Apps Script puede demorar al enumerar cientos de archivos de Drive.
 * No se reintentan respuestas inválidas ni errores 4xx permanentes.
 */
export async function downloadManifestJson(url, {
  request = fetch,
  timeoutMs = 90000,
  retries = 1,
  retryDelayMs = 1500,
  onRetry = () => {},
  sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
} = {}) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    let response;
    try {
      response = await request(url, {
        signal: AbortSignal.timeout(timeoutMs),
        redirect: 'follow',
        headers: { Accept: 'application/json' }
      });
    } catch (error) {
      if (attempt < retries) {
        onRetry({ attempt: attempt + 1, reason: 'conexión o tiempo de espera' });
        await sleep(retryDelayMs);
        continue;
      }
      const timedOut = error?.name === 'TimeoutError' || error?.name === 'AbortError';
      throw new Error(timedOut
        ? `Google Apps Script tardó más de ${Math.round(timeoutMs / 1000)} segundos por intento. Comprobá la URL /exec en el navegador y reintentá.`
        : 'No se pudo conectar con Google Apps Script tras reintentar. Revisá la conexión, el acceso a script.google.com y la URL /exec.');
    }

    if (!response.ok) {
      const status = response.status;
      if (attempt < retries && [408, 429, 500, 502, 503, 504].includes(status)) {
        onRetry({ attempt: attempt + 1, reason: `HTTP ${status}` });
        await sleep(retryDelayMs);
        continue;
      }
      throw new Error(`Apps Script respondió HTTP ${status}. Revisá su implementación y acceso público.`);
    }
    if (Number(response.headers.get('content-length') || 0) > 2_000_000) {
      throw new Error('La respuesta de Apps Script es demasiado grande (más de 2 MB).');
    }
    let raw;
    try {
      raw = await response.text();
    } catch (error) {
      if (attempt < retries) {
        onRetry({ attempt: attempt + 1, reason: 'descarga incompleta de respuesta' });
        await sleep(retryDelayMs);
        continue;
      }
      throw new Error('No se pudo leer la respuesta completa de Apps Script. Revisá la conexión.');
    }
    if (raw.length > 2_000_000) throw new Error('La respuesta de Apps Script es demasiado grande (más de 2 MB).');
    try {
      return JSON.parse(raw);
    } catch {
      throw new Error('Apps Script no devolvió un JSON válido: abrí la URL /exec en incógnito. Si aparece una pantalla de inicio de sesión, revisá la publicación.');
    }
  }
  throw new Error('Error inesperado al consultar Apps Script.');
}
