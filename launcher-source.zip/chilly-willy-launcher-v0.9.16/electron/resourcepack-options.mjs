/**
 * Chilly Willy Launcher - resource packs 1.21.1.
 * La descarga la hace EML; esto selecciona packs en options.txt justo ANTES de lanzar Java.
 * Se preservan los demás ajustes del usuario y no se alteran otros Minecraft instalados.
 */
import fs from 'node:fs';
import path from 'node:path';

const PACK_ID = /^file\/(.+)$/i;
const DISABLED = /do[\s_-]*not[\s_-]*enable|xray[_ -]*ultimate/i;
const VALID_PACK = /^[^\\/:*?"<>|\x00-\x1f]{1,230}\.zip$/i;

// Solo los .zip visibles directamente en resourcepacks/; archivos .rpo y
// ZIP de créditos marcados DO NOT ENABLE no deben activarse.
export function enabledPackIdsFromManifest(resourcepackFiles) {
  if (!Array.isArray(resourcepackFiles)) throw new Error('Listado de resource packs inválido.');
  const seen = new Set();
  const out = [];
  for (const item of resourcepackFiles) {
    if (!item || item.path !== 'resourcepacks/' || typeof item.name !== 'string') continue;
    if (!VALID_PACK.test(item.name) || DISABLED.test(item.name)) continue;
    const id = 'file/' + item.name;
    const key = id.toLowerCase();
    if (!seen.has(key)) { seen.add(key); out.push(id); }
  }
  // Orden estable: una lista nueva de Drive solo cambia si se agrega/quita un pack.
  out.sort((a, b) => a.localeCompare(b, 'en', { sensitivity: 'base' }));
  return out;
}

function jsonArrayFromOption(lines, name) {
  const prefix = name + ':';
  const line = lines.find(line => line.startsWith(prefix));
  if (!line) return [];
  try {
    const result = JSON.parse(line.slice(prefix.length));
    return Array.isArray(result) ? result.filter(v => typeof v === 'string') : [];
  } catch { return []; }
}

function setOption(lines, name, value) {
  const entry = name + ':' + value;
  const at = lines.findIndex(line => line.startsWith(name + ':'));
  if (at >= 0) {
    lines[at] = entry;
    // Evitar claves duplicadas; Minecraft puede interpretar la primera o la última.
    for (let i = lines.length - 1; i > at; i--) if (lines[i].startsWith(name + ':')) lines.splice(i, 1);
  } else lines.push(entry);
}

/** Cambia únicamente resourcePacks. No toca opciones de vídeo, sonido ni teclas. */
export function activateResourcePacks(instanceRoot, resourcepackFiles) {
  if (typeof instanceRoot !== 'string' || !path.isAbsolute(instanceRoot)) {
    throw new Error('No se pudo localizar la carpeta absoluta de Minecraft (EML Lib).');
  }
  const selected = enabledPackIdsFromManifest(resourcepackFiles);
  const masterOptionsFile = path.join(instanceRoot, 'presets', 'options.txt');
  let masterOrder = [];
  if (fs.existsSync(masterOptionsFile) && fs.statSync(masterOptionsFile).size <= 1024*1024) {
    const text = fs.readFileSync(masterOptionsFile, 'utf8');
    masterOrder = jsonArrayFromOption(text.split(/\r?\n/), 'resourcePacks');
  }
  // Si Drive no aporta ZIP, no tocar options.txt accidentalmente.
  if (!selected.length) throw new Error('No hay resource packs .zip válidos para activar. Revisá Drive.');
  const optionFile = path.join(instanceRoot, 'options.txt');
  const previous = fs.existsSync(optionFile) ? fs.readFileSync(optionFile, 'utf8') : '';
  const bom = previous.startsWith('\uFEFF') ? '\uFEFF' : '';
  const plain = bom ? previous.slice(1) : previous;
  const newline = plain.includes('\r\n') ? '\r\n' : '\n';
  const lines = plain ? plain.split(/\r?\n/).filter(Boolean) : ['version:3955'];
  // 'vanilla' y 'fabric' son packs internos; conservar los que ya usa el jugador.
  // Mantener packs adicionales personales, exceptuando entradas DO NOT ENABLE.
  const existing = jsonArrayFromOption(lines, 'resourcePacks');
  const merged = [];
  const seen = new Set();
  const available = new Set(selected.map(id=>id.toLowerCase()));
  // Para el modpack maestro, primero respetamos el orden de prioridad oficial.
  // Entradas del propio juego/mod también se conservan.
  const officialOrder = masterOrder.filter(id => !PACK_ID.test(id) || available.has(id.toLowerCase()));
  const officialSet = new Set(officialOrder.map(id => id.toLowerCase()));
  // Minecraft da mayor prioridad a los elementos del FINAL de resourcePacks.
  // Por eso mantenemos el orden maestro al final y colocamos los packs externos
  // (incluidos mods añadidos a Drive) por debajo, sin modificar los que ya usa el jugador.
  const extras = [...existing, ...selected].filter(id => !officialSet.has(String(id).toLowerCase()));
  for (const id of [...extras, ...officialOrder]) {
    if (!id || typeof id !== 'string') continue;
    if (PACK_ID.test(id) && DISABLED.test(id)) continue;
    const key = id.toLowerCase();
    if (!seen.has(key)) { seen.add(key); merged.push(id); }
  }
  setOption(lines, 'resourcePacks', JSON.stringify(merged));
  if (!lines.some(line => line.startsWith('version:'))) lines.unshift('version:3955');
  if (!lines.some(line => line.startsWith('incompatibleResourcePacks:'))) {
    lines.push('incompatibleResourcePacks:[]');
  }
  const result = bom + lines.join(newline) + newline;
  if (result !== previous) {
    fs.mkdirSync(instanceRoot, { recursive: true });
    // Escritura por reemplazo para minimizar riesgos de archivo truncado.
    const temp = path.join(instanceRoot, `options.txt.chilly-${process.pid}.tmp`);
    try { fs.writeFileSync(temp, result, { encoding: 'utf8', flag: 'wx' }); fs.renameSync(temp, optionFile); }
    finally { try { fs.unlinkSync(temp); } catch {} }
  }
  return { enabledCount: selected.length, changed: result !== previous, optionFile };
}
