/**
 * Guarda la sesión Microsoft sin exponer tokens a la UI ni escribirlos en texto plano.
 * Usa la protección del sistema operativo de Electron (DPAPI en Windows).
 * Jamás persiste la contraseña Microsoft. Nunca sincronizar este archivo con Drive.
 */
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const FILENAME = 'microsoft-session.enc';
const MAX_PLAINTEXT = 256 * 1024;
const MAX_ENCRYPTED = 512 * 1024;

function filename(userDataDir) { return path.join(userDataDir, FILENAME); }

async function encrypt(storage, plaintext) {
  if (typeof storage?.isAsyncEncryptionAvailable === 'function' && typeof storage?.encryptStringAsync === 'function') {
    if (!await storage.isAsyncEncryptionAvailable()) throw new Error('Windows no tiene disponible el cifrado de sesión.');
    return storage.encryptStringAsync(plaintext);
  }
  if (typeof storage?.isEncryptionAvailable === 'function' && typeof storage?.encryptString === 'function') {
    if (!storage.isEncryptionAvailable()) throw new Error('Windows no tiene disponible el cifrado de sesión.');
    return storage.encryptString(plaintext);
  }
  throw new Error('Electron no dispone del cifrado necesario para recordar Microsoft.');
}
async function decrypt(storage, ciphertext) {
  if (typeof storage?.decryptStringAsync === 'function') {
    const plain = await storage.decryptStringAsync(ciphertext);
    return typeof plain === 'string' ? plain : plain?.result;
  }
  if (typeof storage?.decryptString === 'function') return storage.decryptString(ciphertext);
  throw new Error('La sesión no se puede descifrar con esta versión de Electron.');
}

/** Retorna null cuando no existe ningún inicio guardado. */
export async function loadMicrosoftSession(userDataDir, storage) {
  const file=filename(userDataDir);
  if (!fs.existsSync(file)) return null;
  const ciphertext=fs.readFileSync(file);
  if (ciphertext.length < 1 || ciphertext.length > MAX_ENCRYPTED) throw new Error('Sesión cifrada dañada o demasiado grande.');
  const raw=await decrypt(storage, ciphertext);
  if (typeof raw !== 'string' || Buffer.byteLength(raw,'utf8') > MAX_PLAINTEXT) throw new Error('Sesión cifrada inválida.');
  const state=JSON.parse(raw);
  if (state?.schema !== 1 || typeof state.name !== 'string' || !state.name.trim() || state.name.length > 80 || !state.account || typeof state.account !== 'object' || Array.isArray(state.account)) {
    throw new Error('Perfil Microsoft guardado inválido.');
  }
  return {name:state.name,account:state.account};
}

export async function saveMicrosoftSession(userDataDir, storage, name, account) {
  if (typeof name !== 'string' || !name.trim() || name.length > 80 || !account || typeof account !== 'object' || Array.isArray(account)) throw new Error('La cuenta Microsoft no tiene el formato esperado.');
  const plaintext=JSON.stringify({schema:1,name,account});
  if (Buffer.byteLength(plaintext,'utf8') > MAX_PLAINTEXT) throw new Error('La sesión Microsoft es demasiado grande para guardarse.');
  const encrypted=await encrypt(storage,plaintext);
  if (!Buffer.isBuffer(encrypted) || !encrypted.length || encrypted.length > MAX_ENCRYPTED) throw new Error('No se pudo cifrar la sesión Microsoft.');
  fs.mkdirSync(userDataDir,{recursive:true});
  const file=filename(userDataDir);
  const temporary=path.join(userDataDir, `.microsoft-session-${randomUUID()}.tmp`);
  try {
    fs.writeFileSync(temporary,encrypted,{mode:0o600,flag:'wx'});
    fs.renameSync(temporary,file);
  } finally {
    try {fs.unlinkSync(temporary)} catch {}
  }
}

export function deleteMicrosoftSession(userDataDir) {
  try {fs.unlinkSync(filename(userDataDir));}
  catch(error) {if(error?.code !== 'ENOENT') throw error;}
}
