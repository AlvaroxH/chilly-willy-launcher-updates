@echo off
REM Alternativa compatible. Para cero ventanas de consola usá GENERAR_EXE.vbs.
start "" wscript.exe "%~dp0GENERAR_EXE.vbs"
exit /b 0
