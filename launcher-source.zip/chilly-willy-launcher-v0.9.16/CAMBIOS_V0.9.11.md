# Chilly Willy Launcher v0.9.11 — Apariencia del modpack maestro

## Cambios
- Corrige la actualización de ajustes visuales desde `presets/options.txt` para instalaciones existentes de v0.9.10 o anteriores.
- Aplica una sola vez FOV, escala GUI, iluminación, partículas y otras opciones visuales, y crea `options.txt.chilly-willy-before-visual-preset.bak` cuando corresponda.
- En aperturas posteriores respeta cambios personales realizados en el juego; no sobrescribe teclas, volumen, pantalla completa ni parámetros de rendimiento delicados.
- Prioriza el orden de los resource packs definido en el modpack maestro (`options.txt`).
- Iris se activa por primera vez si el preset descargado indica `enableShaders=false`, sin reactivar shaders que el jugador apague más adelante.
- Conserva inicio de sesión Microsoft, Invitado, Java/Fabric, Drive y autoactualizaciones de GitHub.

## Precauciones
El primer inicio de v0.9.11 puede cambiar de nuevo algunos ajustes gráficos que cada usuario haya elegido manualmente. La versión antigua queda respaldada en la instancia. Las distancias de renderizado y la selección de GPU no se imponen a todos los jugadores. No se eliminan mundos, cuentas, teclas ni capturas.

## Qué queda por comprobar
- Inicio y apariencia reales en Windows y con una GPU de gama media.
- Descargar correctamente todo el contenido de Drive y verificar el orden de la lista activa de resource packs.
- Actualización del instalador 0.9.10 a 0.9.11 mediante GitHub Releases (requiere publicar 0.9.11).

No requiere modificar `apps-script/Code.gs` si ya tenés publicado el manifiesto maestro versión 5.
