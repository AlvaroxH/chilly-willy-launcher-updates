# Publicar nuevas versiones sin reenviar el EXE

**Repositorio de publicación:** https://github.com/AlvaroxH/chilly-willy-launcher-updates

## Una sola vez

1. En GitHub, asegurate de que ese repositorio sea **público**. Si está vacío, creá un `README.md` desde la interfaz web. Podés mantener privado el código fuente del launcher en tu PC.
2. Instalá `GitHub CLI` desde https://cli.github.com/ o `winget install --id GitHub.cli -e`.
3. Abrí PowerShell y ejecutá `gh auth login` para autorizar tu propia cuenta. **No compartas el token de GitHub ni lo guardes dentro del launcher**.
4. Los usuarios con 0.9.8 o anteriores deberán instalar una versión con Auto-Updater una sola vez (por ejemplo, la 0.9.11).

## Cada versión

1. Cambiá `version` en `package.json` (ejemplo 0.9.11); también ajustá las etiquetas visuales si corresponde.
2. En tu PC ejecutá `GENERAR_EXE.vbs`. La compilación debe usar el instalador **NSIS**, no solo portable.
3. Probá el Setup generado antes de distribuirlo.
4. Ejecutá `PUBLICAR_VERSION_GITHUB.ps1` mediante PowerShell, o con botón derecho **Ejecutar con PowerShell**. Necesita `gh auth login` previo. También podés subir manualmente los archivos de `release/` a una nueva Release pública marcada como **Latest** y no como pre-release.
5. La Release pública debe contener como mínimo:
   - `latest.yml` (metadatos con sha512 y nombre del Setup)
   - `Chilly-Willy-Launcher-Setup-X.Y.Z.exe`
   - `Chilly-Willy-Launcher-Setup-X.Y.Z.exe.blockmap` (para descargas diferenciales cuando aplique)
   - Opcional: el portable (`Chilly-Willy-Launcher-Portable-X.Y.Z.exe`).
6. El **tag de GitHub** debe ser `vX.Y.Z`, por ejemplo `v0.9.9`, y el contenido de `latest.yml` debe corresponder a la MISMA compilación. Evitá editar o reemplazar Releases antiguas.

## Para la primera Release 0.9.11

Después de compilar y probar, publicá v0.9.11 con `PUBLICAR_VERSION_GITHUB.ps1` para que las instalaciones con Auto-Updater puedan consultar novedades. Una Release inexistente o sin `latest.yml` mostrará un error de consulta, pero no impedirá jugar Minecraft.

**Nota:** la publicación no está hecha por ChatGPT: los archivos de GitHub tienen que subirse desde tu cuenta. Los cambios futuros en `config/`, `mods/`, `shaderpacks/` y resource packs siguen usando Google Drive, no GitHub Releases.

**Seguridad:** GitHub Releases es una fuente remota de ejecutables. Usá acceso seguro a tu cuenta, autenticación multifactor y firma de código para minimizar riesgos de suplantación.
