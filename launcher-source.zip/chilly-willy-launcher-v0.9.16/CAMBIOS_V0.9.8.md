# Chilly Willy Launcher v0.9.8 — Microsoft + Shaderpacks

## Microsoft
- La sesión de Microsoft se guarda cifrada en `%APPDATA%/chilly-willy-launcher/microsoft-session.enc` (la carpeta de `userData` de Electron; puede variar según sistema). **No se almacena la contraseña.**
- Usa Electron `safeStorage` con DPAPI en Windows, evitando tokens en texto plano.
- Se restaura al volver a abrir tanto el Setup instalado como el portable, con el mismo usuario de Windows.
- La sesión se valida al pulsar JUGAR y se renueva con `MicrosoftAuth.refresh()` cuando corresponde.
- Cerrar sesión o ingresar como invitado borra la sesión cifrada de Microsoft.
- Al actualizar desde v0.9.7 habrá que iniciar sesión **una última vez**, pues versiones anteriores no almacenaban ninguna credencial.
- Si el sistema no permite cifrar, funciona la sesión de esa ejecución y se muestra una advertencia; nunca se guarda sin cifrado.

## Shaders: publicación obligatoria de Apps Script
- El launcher usa `shaderpacks/` además de `mods/`, `config/`, `resourcepacks/` y `datapacks/`.
- El mensaje ahora indica la versión del manifiesto y cuántos archivos de shaders está devolviendo, en vez de solo mostrar el genérico de publicación.
- Copiá `apps-script/Code.gs` dentro del proyecto Apps Script **actual** y guardá.
- En **Implementar > Administrar implementaciones > lápiz > Versión: Nueva versión > Implementar**.
- **No crees una implementación nueva** salvo que actualices la URL del launcher: la actual ya está incluida en `config/server.json`.
- Abrí la URL `/exec` en incógnito: buscá `"version":4` y `"path":"shaderpacks/"` (o rutas que empiecen por shaderpacks/).
- Si el Apps Script público no publica shaders, el launcher no inventa una descarga: avisará y no iniciará un pack incompleto.

## Limitaciones
Estas son pruebas de código en Linux; falta probar Microsoft DPAPI y las descargas de shaders en un Windows real. El ZIP es **código para compilar**: ejecutá `GENERAR_EXE.vbs` en tu PC para crear `Setup.exe` y `Portable.exe`.
