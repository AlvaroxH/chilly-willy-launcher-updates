# Chilly Willy Launcher - GitHub release publisher (fixed for first release)
# Run from the project folder: powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\PUBLICAR_VERSION_GITHUB.ps1"
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$pkg = Get-Content -LiteralPath (Join-Path $root 'package.json') -Raw | ConvertFrom-Json
$version = [string]$pkg.version
$repo = 'AlvaroxH/chilly-willy-launcher-updates'
$dir = Join-Path $root 'release'
$setup = Join-Path $dir "Chilly-Willy-Launcher-Setup-$version.exe"
$meta = Join-Path $dir 'latest.yml'
$map = "$setup.blockmap"
$portable = Join-Path $dir "Chilly-Willy-Launcher-Portable-$version.exe"

if (-not (Get-Command gh.exe -ErrorAction SilentlyContinue)) {
    throw 'GitHub CLI not found. Install it and try again.'
}
if (-not (Test-Path -LiteralPath $setup) -or -not (Test-Path -LiteralPath $meta)) {
    throw 'Missing release Setup.exe or latest.yml. Build with GENERAR_EXE.vbs first.'
}
$latest = Get-Content -LiteralPath $meta -Raw
if (-not $latest.Contains("Chilly-Willy-Launcher-Setup-$version.exe")) {
    throw 'latest.yml points to another installer/version. Rebuild before publishing.'
}

# Unlike 'gh release view', listing releases also succeeds when the repository has no releases.
$releaseJson = & gh.exe release list --repo $repo --json tagName --limit 100
if ($LASTEXITCODE -ne 0) { throw 'Could not list GitHub Releases. Check repository access and gh auth status.' }
$existing = @($releaseJson | ConvertFrom-Json)
if (@($existing | Where-Object { $_ -and $_.tagName -eq "v$version" }).Count -gt 0) {
    throw "Release v$version already exists. Publish a newer version instead."
}

$files = @($setup, $meta)
if (Test-Path -LiteralPath $map) {
    $files += $map
} else {
    Write-Warning 'No .blockmap found; clients may download the full installer.'
}
if (Test-Path -LiteralPath $portable) { $files += $portable }

Write-Host "Publishing v$version to $repo ..."
& gh.exe release create "v$version" @files --repo $repo --title "Chilly Willy Launcher v$version" --notes "Chilly Willy Launcher v$version - stable release" --latest
if ($LASTEXITCODE -ne 0) {
    throw 'Could not publish release. Check that repository has an initial commit and your account can publish.'
}
Write-Host 'Done. Check GitHub Releases for the Setup.exe and latest.yml files.'
