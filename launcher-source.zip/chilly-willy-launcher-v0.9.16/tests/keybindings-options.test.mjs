import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { applyPackKeybindings, parseDefaultKeybindings } from '../electron/keybindings-options.mjs';
import { activateResourcePacks } from '../electron/resourcepack-options.mjs';
const sample = ['key_key.forward:key.keyboard.w','key_key.sprint:key.keyboard.left.control','key_key.cobblemon.summary:key.keyboard.c','key_key.cobblemon.throwpartypokemon:key.keyboard.r','key_key.lumymon.access_pc:key.keyboard.p','key_key.zoomify.key.zoom:key.keyboard.z','key_key.inventory:key.keyboard.e','key_key.sneak:key.keyboard.left.shift','key_key.jump:key.keyboard.space','key_key.swapOffhand:key.keyboard.f','key_gui.xaero_open_map:key.keyboard.m'].join('\r\n')+'\r\n';
function fixture(t) {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'chilly-keys-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const base=path.join(dir,'config','defaultoptions');fs.mkdirSync(base,{recursive:true});
  fs.writeFileSync(path.join(base,'keybindings.txt'),sample);
  fs.writeFileSync(path.join(base,'options.txt'),'version:3955\r\nmaxFps:260\r\nsoundCategory_music:0.2\r\n');
  return dir;
}
test('lee 11 enlaces de modpack y descarta entradas malformadas',()=> {
  const result=parseDefaultKeybindings(sample+'key_bad:abc\nkey_malicioso:../../fichero');
  assert.equal(result.size,11);assert.equal(result.get('key_key.cobblemon.summary'),'key.keyboard.c');
});
test('instalación limpia aplica teclas y otros defaults junto a resourcepacks',t=> {
  const dir=fixture(t);
  const applied=applyPackKeybindings(dir);
  assert.equal(applied.first,true); assert.equal(applied.total,11);
  const rp=activateResourcePacks(dir,[{name:'COBBLEVERSE RP.zip',path:'resourcepacks/'}]);
  assert.equal(rp.enabledCount,1);
  const txt=fs.readFileSync(path.join(dir,'options.txt'),'utf8');
  assert.match(txt,/key_key\.cobblemon\.summary:key\.keyboard\.c/);
  assert.match(txt,/maxFps:260/);
  assert.match(txt,/resourcePacks:\["file\/COBBLEVERSE RP\.zip"\]/);
  assert.match(txt,/soundCategory_music:0\.2/);
});
test('actualización respalda y aplica una sola vez el preset para v0.9.6',t=> {
  const dir=fixture(t);const f=path.join(dir,'options.txt');
  const prior='version:3955\r\nkey_key.cobblemon.summary:key.keyboard.x\r\nmaxFps:123\r\n';
  fs.writeFileSync(f,prior);
  const first=applyPackKeybindings(dir);
  assert.equal(first.first,true);
  assert.equal(fs.readFileSync(path.join(dir,'options.txt.chilly-willy-before-keybindings.bak'),'utf8'),prior);
  assert.match(fs.readFileSync(f,'utf8'),/key_key\.cobblemon\.summary:key\.keyboard\.c/);
  assert.match(fs.readFileSync(f,'utf8'),/maxFps:123/);
  const again=applyPackKeybindings(dir);assert.equal(again.first,false);assert.equal(again.applied,0);
});
test('tras migración no se sobrescriben cambios personales',t=> {
  const dir=fixture(t);const file=path.join(dir,'options.txt');
  applyPackKeybindings(dir);
  fs.writeFileSync(file,fs.readFileSync(file,'utf8').replace('key_key.cobblemon.summary:key.keyboard.c','key_key.cobblemon.summary:key.keyboard.g'));
  const repeat=applyPackKeybindings(dir);
  assert.equal(repeat.first,false);
  assert.match(fs.readFileSync(file,'utf8'),/key_key.cobblemon.summary:key.keyboard.g/);
});
test('actualiza defaults del pack si el jugador no había personalizado su tecla',t=> {
  const dir=fixture(t); const f=path.join(dir,'options.txt');
  applyPackKeybindings(dir);
  const keyfile=path.join(dir,'config','defaultoptions','keybindings.txt');
  fs.writeFileSync(keyfile,sample.replace('key_key.cobblemon.summary:key.keyboard.c','key_key.cobblemon.summary:key.keyboard.v'));
  applyPackKeybindings(dir);
  assert.match(fs.readFileSync(f,'utf8'),/key_key.cobblemon.summary:key.keyboard.v/);
});
test('falta del preset da un error claro en vez de falsear instalación',t=> {
  const dir=fixture(t);
  fs.unlinkSync(path.join(dir,'config','defaultoptions','keybindings.txt'));
  assert.throws(()=>applyPackKeybindings(dir),/Falta config\/defaultoptions\/keybindings/);
});
test('hook de inicio aplica teclas primero y packs después',()=> {
  const main=fs.readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
  assert.match(main,/applyPackKeybindings\(launcher\.config\.root\)/);
  assert.ok(main.indexOf('const keys = applyPackKeybindings(') < main.indexOf('const selected = activateResourcePacks('));
});
