import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const read = p => readFileSync(new URL('../'+p, import.meta.url), 'utf8');
const cfg=JSON.parse(read('config/server.json'));
const main=read('electron/main.mjs'), ui=read('ui/app.js'), html=read('ui/index.html');
test('invitado permitido en cliente sin cambiar el host de Minecraft',()=>{
  assert.equal(cfg.allowGuest,true);
  assert.equal(cfg.serverAddress,'146.181.33.25:25565');
  assert.equal(cfg.minecraftVersion,'1.21.1');
  assert.equal(cfg.fabricLoaderVersion,'0.20.1');
});
test('nick es validado en main y EML usa perfil offline',()=>{
  assert.match(main,/const USERNAME = \/\^\[A-Za-z0-9_\]\{3,16\}\$\//);
  assert.match(main,/new CrackAuth\(\)\.auth\(name\)/);
  assert.match(main,/session\.account/);
  assert.match(main,/session\.type === 'guest' && settings\.allowGuest !== true/);
});
test('interfaz invita a JUGAR sin toast engañoso de bloqueo',()=>{
  assert.match(ui,/window\.cobble\.loginGuest/);
  assert.doesNotMatch(ui,/Perfil invitado creado\. Para ingresar al servidor hace falta habilitar invitados/);
  assert.match(html,/el servidor debe aceptar cuentas offline/i);
});
test('incluye guía de protección de identidades y empaquetado',()=>{
  assert.ok(existsSync(new URL('../CONFIGURAR_INVITADOS_SERVIDOR.md',import.meta.url)));
  const doc=read('CONFIGURAR_INVITADOS_SERVIDOR.md');
  assert.match(doc,/EasyAuth/);
  assert.match(doc,/suplantaci[oó]n/);
  assert.match(doc,/backup/);
});
