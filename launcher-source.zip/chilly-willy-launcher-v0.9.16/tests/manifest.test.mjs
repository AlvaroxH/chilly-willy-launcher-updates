import test from 'node:test';
import assert from 'node:assert/strict';
import {validateManifest} from '../electron/manifest-validator.mjs';
const source = 'https://drive.usercontent.google.com/download?id=abc123&export=download&confirm=t';
const file=(name,path,type,size=42) => ({name,path,type,size,updated:1793000000000,url:source});
const manifest={version:3,files:[
  file('Cobblemon.jar','mods/','MOD',2000),
  file('config.json','config/cobbleverse/','OTHER'),
  file('shader.rpo','resourcepacks/','OTHER',2),
  file('PokeCenter.zip','datapacks/','OTHER',1000)
]};
test('soporta mods, config anidada, resourcepacks auxiliares y datapacks',()=>{
  const out=validateManifest(manifest);
  assert.equal(out.counts.mods,1);
  assert.equal(out.counts.config,1);
  assert.equal(out.counts.resourcepacks,1);
  assert.equal(out.counts.datapacks,1);
  assert.equal(out.fullPack,true);
});
test('el Apps Script anterior sigue reconocible pero no está completo',()=>{
  const out=validateManifest({files:[manifest.files[0]]});
  assert.equal(out.fullPack,false);
  assert.match(out.warnings[0],/Apps Script/);
});
test('rechaza manifest vacío',()=> assert.throws(()=>validateManifest({files:[]}),/vacío/));
test('rechaza subir directorio fuera de las secciones',()=> assert.throws(()=>validateManifest({files:[...manifest.files,{...manifest.files[1],path:'saves/world/'}]}),/no permitida/));
test('rechaza path traversal',()=>assert.throws(()=>validateManifest({files:[...manifest.files,{...manifest.files[1],path:'config/../'}]}),/no permitida/));
test('rechaza url externa',()=>assert.throws(()=>validateManifest({files:[{...manifest.files[0],url:'https://example.org/download?id=abc'}]}),/no permitido/));
test('rechaza repetidos',()=>assert.throws(()=>validateManifest({files:[...manifest.files,manifest.files[0]]}),/duplicado/));
test('rechaza tipo MOD en config',()=>assert.throws(()=>validateManifest({files:[{...manifest.files[1],type:'MOD'}]}),/Tipo inválido/));
test('rechaza nombres Windows reservados',()=>assert.throws(()=>validateManifest({files:[{...manifest.files[1],name:'CON.txt'}]}),/Nombre inválido/));
test('rechaza manifiesto con error remoto',()=>assert.throws(()=>validateManifest({error:'Drive exception'}),/Apps Script/));
