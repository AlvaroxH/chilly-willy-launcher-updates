import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { enabledPackIdsFromManifest, activateResourcePacks } from '../electron/resourcepack-options.mjs';
import { validateManifest } from '../electron/manifest-validator.mjs';

const rp = names => names.map(name => ({ name, path: 'resourcepacks/' }));
const packs = rp([
  'COBBLEVERSE RP.zip',
  'Fresh Animations.zip',
  'COBBLEVERSE Soundtrack.zip',
  'z DO NOT ENABLE z [CavsCobbleMons - Credits Only].zip',
  'Cobblemon Interface.zip.rpo',
  'Cobblemon Interface Modded.zip.rpo'
]);

test('activa zip reales y excluye creditos NO HABILITAR y archivos rpo', () => {
  const ids = enabledPackIdsFromManifest(packs);
  assert.deepEqual(ids, ['file/COBBLEVERSE RP.zip', 'file/COBBLEVERSE Soundtrack.zip', 'file/Fresh Animations.zip']);
  assert.ok(ids.every(id => !id.includes('DO NOT ENABLE') && !id.endsWith('.rpo')));
});

test('rechaza subcarpetas, nombres no zip e inyeccion de rutas', () => {
  assert.deepEqual(enabledPackIdsFromManifest([
    ...rp(['Readme.txt', 'Evil\\..\\file.zip', 'foo/../../evil.zip']),
    { path: 'resourcepacks/sub/', name: 'sub.zip' },
    { path: 'resourcepacks/', name: 'Good.zip' }
  ]), ['file/Good.zip']);
});

test('instala options.txt inicial con la versión correcta y packs seleccionados', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chilly-rp-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  const result = activateResourcePacks(dir, packs);
  assert.equal(result.enabledCount, 3);
  const text = fs.readFileSync(path.join(dir, 'options.txt'), 'utf8');
  assert.match(text, /^version:3955\n/);
  assert.deepEqual(JSON.parse(text.match(/^resourcePacks:(.+)$/m)[1]), enabledPackIdsFromManifest(packs));
  assert.match(text, /^incompatibleResourcePacks:\[\]$/m);
  assert.equal(activateResourcePacks(dir, packs).changed, false);
});

test('preserva volumen, teclas, fps, preferencias personales y añade packs nuevos en cada inicio', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chilly-rp-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  fs.writeFileSync(path.join(dir, 'options.txt'), [
    'version:3955', 'soundCategory_master:0.17', 'maxFps:143',
    'resourcePacks:["vanilla","fabric","file/MiPackPersonal.zip"]',
    'key_key.forward:key.keyboard.up', 'incompatibleResourcePacks:["file/Legacy.zip"]', ''
  ].join('\r\n'));
  const result = activateResourcePacks(dir, [...packs, ...rp(['New Pack.zip'])]);
  assert.equal(result.enabledCount, 4);
  const contents = fs.readFileSync(path.join(dir, 'options.txt'), 'utf8');
  assert.match(contents, /soundCategory_master:0\.17\r\n/);
  assert.match(contents, /key_key.forward:key.keyboard.up\r\n/);
  assert.match(contents, /maxFps:143\r\n/);
  assert.match(contents, /incompatibleResourcePacks:\["file\/Legacy.zip"\]/);
  assert.deepEqual(JSON.parse(contents.match(/^resourcePacks:(.+)$/m)[1]), [
    'vanilla', 'fabric', 'file/MiPackPersonal.zip', ...enabledPackIdsFromManifest([...packs,...rp(['New Pack.zip'])])
  ]);
});

test('descarta DO NOT ENABLE incluso si jugador lo habia activado manualmente', (t) => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'chilly-rp-'));
  t.after(() => fs.rmSync(dir, { recursive: true, force: true }));
  fs.writeFileSync(path.join(dir, 'options.txt'), 'version:3955\nresourcePacks:["vanilla","file/z DO NOT ENABLE z [Credits Only].zip"]\n');
  const r=activateResourcePacks(dir, packs);
  assert.equal(r.enabledCount,3);
  assert.doesNotMatch(fs.readFileSync(path.join(dir, 'options.txt'),'utf8'), /DO NOT ENABLE/);
});

test('manifest seguro expone nombres de resourcepacks para activar y cuenta los modpacks', () => {
  const f=(name,path,type)=>({name,path,type,size:100,url:'https://drive.usercontent.google.com/download?id=abcdefghijklmn&export=download&confirm=t'});
  const data={version:3,files:[f('fabric-api.jar','mods/','MOD'),f('settings.json','config/','OTHER'),f('COBBLEVERSE RP.zip','resourcepacks/','OTHER'),f('COBBLEVERSE-DP.zip','datapacks/','OTHER')]};
  const checked=validateManifest(data);
  assert.equal(checked.fullPack,true);
  assert.deepEqual(checked.resourcepackFiles,[{name:'COBBLEVERSE RP.zip',path:'resourcepacks/'}]);
});

test('el proceso principal activa paquetes DESPUES de descargar y ANTES del spawn', () => {
  const main=fs.readFileSync(new URL('../electron/main.mjs', import.meta.url), 'utf8');
  const ix=main.indexOf("launcher.on('launch_launch'");
  assert.ok(ix>main.indexOf('new Launcher('));
  assert.match(main.slice(ix,ix+1600),/activateResourcePacks\(launcher\.config\.root, pack\.resourcepackFiles\)/);
  assert.match(main,/await launcher\.launch\(\)/);
});
