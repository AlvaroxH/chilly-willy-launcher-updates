import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import os from 'node:os';
import {mkdtemp, mkdir, readFile, readdir, writeFile, rm, realpath} from 'node:fs/promises';
import {readFileSync} from 'node:fs';
import {migrateMinecraftLocation, describeMinecraftPath, legacyMinecraftRoot} from '../electron/game-location.mjs';
import {readPreferences, savePreferences} from '../electron/profile-store.mjs';
const testBase = async (t) => {
  const root=await mkdtemp(path.join(os.tmpdir(),'chilly-move-test-'));
  t.after(async()=>{await rm(root,{recursive:true,force:true})});
  const appData=path.join(root,'appdata');const other=path.join(root,'games');
  await mkdir(appData); await mkdir(other);
  return {root,appData,other,legacy:legacyMinecraftRoot(appData)};
};
test('La primera instalación puede elegir carpeta vacía de otra unidad',async t=>{
 const {appData,other,legacy}=await testBase(t);
 const chosen=path.join(other,'Cobbleverse');
 await mkdir(chosen);
 const result=await migrateMinecraftLocation({appData,destination:chosen});
 assert.equal(result.path,chosen);
 assert.equal((await realpath(legacy)),await realpath(chosen));
 assert.deepEqual(await readdir(chosen),[]);
 assert.equal((await describeMinecraftPath(appData)).custom,true);
});
test('Una instalación previa mueve Java, mundos, shaders, mods y opciones',async t=>{
 const {appData,other,legacy}=await testBase(t);
 for(const [folder,file,contents] of [['saves/world','level.dat','world'],['runtime/jre-21/bin','java.exe','java'],['mods','cobblemon.jar','mod'],['config/fancymenu','options.txt','custom menu'],['shaderpacks','shader.zip','shader']]){
  const target=path.join(legacy,folder);await mkdir(target,{recursive:true});await writeFile(path.join(target,file),contents);
 }
 const desired=path.join(other,'Cobb');
 const result=await migrateMinecraftLocation({appData,destination:desired});
 assert.equal(result.cleanupNeeded,false);
 // Windows puede convertir RUNNER~1 a runneradmin al resolver una junction.
 // Comparamos ubicaciones canónicas, no la grafía textual del camino.
 assert.equal(await realpath((await describeMinecraftPath(appData)).path),await realpath(desired));
 for(const [folder,file,contents] of [['saves/world','level.dat','world'],['runtime/jre-21/bin','java.exe','java'],['mods','cobblemon.jar','mod'],['config/fancymenu','options.txt','custom menu'],['shaderpacks','shader.zip','shader']]){
  assert.equal((await readFile(path.join(legacy,folder,file),'utf8')),contents);
  assert.equal((await readFile(path.join(desired,folder,file),'utf8')),contents);
 }
 assert.ok(!(await readdir(appData)).some(n=>n.includes('chilly-respaldo')));
});
test('Rechaza destino no vacío sin tocar el origen',async t=>{
 const {appData,other,legacy}=await testBase(t);
 await mkdir(legacy);await writeFile(path.join(legacy,'options.txt'),'keep');
 const chosen=path.join(other,'existing');await mkdir(chosen);await writeFile(path.join(chosen,'hello.txt'),'old');
 await assert.rejects(migrateMinecraftLocation({appData,destination:chosen}),/vacía/);
 assert.equal(await readFile(path.join(legacy,'options.txt'),'utf8'),'keep');
 assert.equal(await readFile(path.join(chosen,'hello.txt'),'utf8'),'old');
});
test('No acepta mover dentro del propio directorio de Minecraft',async t=>{
 const {appData,legacy}=await testBase(t);
 await mkdir(legacy);await writeFile(path.join(legacy,'options.txt'),'keep');
 await assert.rejects(migrateMinecraftLocation({appData,destination:path.join(legacy,'nested')}),/otra carpeta/);
 assert.equal(await readFile(path.join(legacy,'options.txt'),'utf8'),'keep');
});
test('Permite cambiar otra vez de disco sin duplicar archivos en el origen anterior',async t=>{
 const {appData,other,legacy}=await testBase(t);
 const first=path.join(other,'first');const second=path.join(other,'second');
 await migrateMinecraftLocation({appData,destination:first});
 await mkdir(path.join(legacy,'mods'),{recursive:true});await writeFile(path.join(legacy,'mods','file.jar'),'model');
 const moved=await migrateMinecraftLocation({appData,destination:second});
 assert.equal(moved.cleanupNeeded,true);
 // Al leer una junction en Windows, realpath puede expandir nombres DOS 8.3.
 assert.equal(await realpath(moved.oldLocation),await realpath(first));
 assert.equal(await readFile(path.join(second,'mods','file.jar'),'utf8'),'model');
 assert.equal(await readFile(path.join(first,'mods','file.jar'),'utf8'),'model');
});
test('Conserva preferencia de ubicación seleccionada sin mezclar tokens',async t=>{
 const {appData}=await testBase(t);savePreferences(appData,{storageChoiceMade:true});
 assert.equal(readPreferences(appData).storageChoiceMade,true);
 const f=readFileSync(path.join(appData,'preferences.json'),'utf8');assert.doesNotMatch(f,/token|password/);
});
test('NSIS permite escoger destino y la UI ofrece Minecraft independiente',()=>{
 const root=new URL('../',import.meta.url);
 const pkg=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8'));
 const ui=readFileSync(new URL('../ui/index.html',import.meta.url),'utf8');
 const main=readFileSync(new URL('../electron/main.mjs',import.meta.url),'utf8');
 assert.equal(pkg.build.nsis.oneClick,false);
 assert.equal(pkg.build.nsis.allowToChangeInstallationDirectory,true);
 assert.match(ui,/Elegir o mover Minecraft/);
 assert.match(ui,/Antes de descargar/i);
 assert.match(main,/launcher:choose-game-location/);
});
