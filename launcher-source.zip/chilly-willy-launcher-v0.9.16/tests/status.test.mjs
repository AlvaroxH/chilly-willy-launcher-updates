import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import { getMinecraftStatus } from '../electron/minecraft-status.mjs';

function varInt(n) { const bytes=[];do{let byte=n&127;n>>>=7;if(n)byte|=128;bytes.push(byte)}while(n);return Buffer.from(bytes); }

test('consulta real de status y extrae jugadores verificados por protocolo', async () => {
  const server = net.createServer(socket => socket.once('data',()=>{
    const msg = JSON.stringify({players:{online:2,max:18,sample:[{name:'ChillyWilly'},{name:'Explorador_1'},{name:'<script>bad'}]}});
    const json=Buffer.from(msg,'utf8');
    const content=Buffer.concat([varInt(0),varInt(json.length),json]);
    socket.end(Buffer.concat([varInt(content.length),content]));
  }));
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  try {
    const info=await getMinecraftStatus(`127.0.0.1:${server.address().port}`);
    assert.equal(info.online,true);
    assert.equal(info.playersOnline,2);
    assert.equal(info.playersMax,18);
    assert.deepEqual(info.sample,[{name:'ChillyWilly',uuid:null},{name:'Explorador_1',uuid:null}]);
  } finally { await new Promise(resolve=>server.close(resolve)); }
});

test('devuelve offline sin inventar datos si no hay servidor',async()=>{
  const server=net.createServer(); await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const port=server.address().port;await new Promise(resolve=>server.close(resolve));
  const info=await getMinecraftStatus(`127.0.0.1:${port}`,500);
  assert.deepEqual(info,{online:false});
});
