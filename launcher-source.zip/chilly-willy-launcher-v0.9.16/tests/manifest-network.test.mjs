import test from 'node:test';
import assert from 'node:assert/strict';
import { downloadManifestJson } from '../electron/manifest-network.mjs';
const url = 'https://script.google.com/macros/s/demo/exec';
const response = (body, status = 200) => ({
  ok: status >= 200 && status < 300, status,
  headers: { get: () => null },
  text: async () => body
});
test('lee JSON y sigue la redirección de Google', async () => {
  let args;
  const output = await downloadManifestJson(url, {
    request: async (_url, opts) => { args = opts; return response('{"version":3,"files":[]}'); }
  });
  assert.deepEqual(output, {version:3,files:[]});
  assert.equal(args.redirect,'follow');
});
test('reintenta si falla transitoriamente y recupera el manifiesto', async () => {
  let calls = 0, notices = 0;
  const output = await downloadManifestJson(url, {
    request: async () => { calls++; if (calls===1) throw new Error('fetch failed'); return response('{"version":3,"files":[]}'); },
    sleep: async () => {}, onRetry: () => notices++
  });
  assert.equal(calls, 2); assert.equal(notices, 1); assert.equal(output.version,3);
});
test('reintenta HTTP 503 pero no HTTP 403', async () => {
  let calls = 0;
  const output = await downloadManifestJson(url, {request:async()=>{calls++;return calls===1?response('',503):response('{"files":[]}');},sleep:async()=>{}});
  assert.equal(calls,2); assert.ok(output.files);
  calls = 0;
  await assert.rejects(downloadManifestJson(url, {request:async()=>{calls++;return response('',403);},sleep:async()=>{}}),/HTTP 403/);
  assert.equal(calls,1);
});
test('distingue timeout de fallo de red', async () => {
  await assert.rejects(downloadManifestJson(url, {request: async ()=> {const e = new Error(''); e.name='TimeoutError'; throw e;}, retries:0}),/tardó más de 90 segundos/);
  await assert.rejects(downloadManifestJson(url, {request: async ()=> {throw new Error('fetch failed');},retries:0}),/No se pudo conectar/);
});
test('no reintenta respuesta JSON inválida', async () => {
  let calls=0;
  await assert.rejects(downloadManifestJson(url,{request:async()=>{calls++;return response('<html>login</html>')},sleep:async()=>{}}),/no devolvió un JSON válido/);
  assert.equal(calls,1);
});
