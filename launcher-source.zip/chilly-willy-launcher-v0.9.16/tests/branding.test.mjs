import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
const read = (f) => readFileSync(new URL('../'+f,import.meta.url),'utf8');
const pkg = JSON.parse(read('package.json'));
test('marca visible y ejecutables Chilly Willy sin alterar Minecraft o server',()=>{
  assert.equal(pkg.build.productName, 'Chilly Willy Launcher');
  assert.equal(pkg.build.nsis.shortcutName, 'Chilly Willy Launcher');
  assert.match(pkg.build.nsis.artifactName, /^Chilly-Willy-Launcher-Setup/);
  assert.match(pkg.build.portable.artifactName, /^Chilly-Willy-Launcher-Portable/);
  assert.match(read('ui/index.html'),/<title>Chilly Willy Launcher<\/title>/);
  assert.match(read('ui/index.html'),/CHILLY WILLY <span>LAUNCHER<\/span>/);
  assert.match(read('electron/main.mjs'),/title: 'Chilly Willy Launcher'/);
  assert.match(read('build/GENERADOR_GUI.ps1'),/Chilly-Willy-Launcher-Setup-\$version\.exe/);
  assert.match(read('build/GENERADOR_GUI.ps1'),/ConvertFrom-Json\)\.version/);
  const cfg=JSON.parse(read('config/server.json'));
  assert.equal(cfg.fabricLoaderVersion,'0.20.1');
  assert.equal(cfg.serverAddress,'146.181.33.25:25565');
});
test('cabeza pública se obtiene mediante IPC y falla a imagen local, sin mostrar letras',()=>{
 assert.match(read('electron/preload.cjs'),/skinHead: /);
 assert.match(read('electron/main.mjs'),/launcher:skin-head/);
 assert.match(read('ui/app.js'),/img\.src = dataUrl/);
 assert.match(read('ui/app.js'),/skin-fallback\.png/);
 assert.match(read('ui/index.html'),/img-src 'self' data:/);
});
