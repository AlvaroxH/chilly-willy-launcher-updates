import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync, readFileSync, writeFileSync } from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { readPreferences, savePreferences, validGuestName } from '../electron/profile-store.mjs';

const temp = fn => {
  const dir = mkdtempSync(path.join(os.tmpdir(), 'chilly-willy-pref-'));
  try { return fn(dir); } finally { rmSync(dir, { recursive: true, force: true }); }
};

test('el perfil invitado se guarda y se restaura despues de reiniciar (incluido portable)', () => temp(dir => {
  assert.deepEqual(readPreferences(dir), {});
  savePreferences(dir, { guestName: 'Holas1232' });
  const afterRestart = readPreferences(dir);
  assert.equal(afterRestart.guestName, 'Holas1232');
  assert.deepEqual(JSON.parse(readFileSync(path.join(dir, 'preferences.json'), 'utf8')), { guestName: 'Holas1232' });
}));

test('guardar RAM no elimina nick; guardar invitado no borra RAM', () => temp(dir => {
  savePreferences(dir, { guestName: 'Jugador_ABC' });
  savePreferences(dir, { memoryMb: 8192 });
  assert.deepEqual(readPreferences(dir), { memoryMb: 8192, guestName: 'Jugador_ABC' });
  savePreferences(dir, { guestName: 'Otro_123' });
  assert.deepEqual(readPreferences(dir), { memoryMb: 8192, guestName: 'Otro_123' });
}));

test('cerrar sesion elimina invitado y conserva RAM', () => temp(dir => {
  savePreferences(dir, { memoryMb: 6144, guestName: 'Test_123' });
  savePreferences(dir, { guestName: null });
  assert.deepEqual(readPreferences(dir), { memoryMb: 6144 });
}));

test('valida el nombre: 3-16 caracteres, sin rutas ni saltos de linea', () => temp(dir => {
  for (const name of ['a', '', 'hola hola', '../otro', 'a'.repeat(17), 'niñito']) {
    assert.equal(validGuestName(name), false);
    assert.throws(() => savePreferences(dir, { guestName: name }));
  }
  assert.equal(validGuestName('Chilly_Willy'), true);
}));

test('ficheros corruptos o antiguos no impiden iniciar y no almacena tokens', () => temp(dir => {
  const file = path.join(dir, 'preferences.json');
  writeFileSync(file, '{invalid json');
  assert.deepEqual(readPreferences(dir), {});
  writeFileSync(file, JSON.stringify({ memoryMb: 4096, accessToken: 'secret', refreshToken: 'secret2', guestName: 'Jugador_1' }));
  assert.deepEqual(readPreferences(dir), { memoryMb: 4096, guestName: 'Jugador_1' });
  savePreferences(dir, { guestName: 'Jugador_2' });
  assert.doesNotMatch(readFileSync(file, 'utf8'), /secret|accessToken|refreshToken/);
}));

test('el proceso principal restaura invitado antes de abrir la ventana y elimina en logout', () => {
  const main = readFileSync(new URL('../electron/main.mjs', import.meta.url), 'utf8');
  const ui = readFileSync(new URL('../ui/app.js', import.meta.url), 'utf8');
  assert.match(main, /await restoreSavedGuestSession\(\);\s*createWindow\(\);/);
  assert.match(main, /savePreferences\(app\.getPath\('userData'\), \{ guestName: name \}\)/);
  assert.match(main, /savePreferences\(app\.getPath\('userData'\), \{ guestName: null \}\)/);
  assert.match(ui, /cfg\.savedGuestName/);
});
