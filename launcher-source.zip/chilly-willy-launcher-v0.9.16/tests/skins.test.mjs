import test from 'node:test';
import assert from 'node:assert/strict';
import { avatarCandidates, fetchSkin } from '../electron/skins.mjs';
const png = Buffer.from('89504e470d0a1a0a0000000049454e44ae426082','hex');
function imageResponse(body, mime='image/png', status=200) {
  return new Response(body, {status, headers: { 'content-type': mime }});
}
test('la lista online prioriza nick incluso con UUID del servidor',()=>{
 const urls = avatarCandidates({name:'Kler_my',uuid:'12345678123412341234123412341234',source:'server'});
 assert.match(urls[0], /mc-heads\.net\/avatar\/Kler_my\/64/);
 assert.equal(urls.some(s=>s.includes('12345678123412341234123412341234')),false);
});
test('cuenta Microsoft prioriza UUID autenticado',()=>{
 const urls=avatarCandidates({name:'Jugador',uuid:'069a79f444e94726a5befca90e38aaf5',source:'account',type:'microsoft'});
 assert.match(urls[0],/069a79f444e94726a5befca90e38aaf5/);
});
test('invitado e identificadores inválidos no consultan proveedores',()=>{
 assert.deepEqual(avatarCandidates({name:'Notch',type:'guest'}),[]);
 assert.deepEqual(avatarCandidates({name:'../bad'}),[]);
});
test('si falla un proveedor usa el siguiente',async()=>{
 let times=0;
 const result=await fetchSkin({name:'zMaruchan_',source:'server'},async()=>{
    times++;return times===1?imageResponse('No disponible','text/plain',404):imageResponse(png);
 });
 assert.equal(times,2);
 assert.match(result,/^data:image\/png;base64,/);
});
test('rechaza falso PNG, imágenes demasiado grandes y usa fallback',async()=>{
 let count=0;
 const result=await fetchSkin({name:'Kler_my',source:'server'},async()=>{
  count++;return count===1?imageResponse('<html>error</html>','text/html'):imageResponse(new Uint8Array(262145));
 });
 assert.equal(result,null);
});
