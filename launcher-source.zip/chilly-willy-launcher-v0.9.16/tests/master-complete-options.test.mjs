import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {applyMasterCompleteOptions,copyMasterPackIcon} from '../electron/master-complete-options.mjs';
import {validateManifest} from '../electron/manifest-validator.mjs';

function fixture(t){
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'cw-master-complete-'));
  t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.mkdirSync(path.join(root,'presets'),{recursive:true});
  const opts=['version:3955','fov:0.25','guiScale:3','gamma:1.0','soundCategory_master:0.6','soundCategory_music:0.0','lang:es_es','renderDistance:13','resourcePacks:["vanilla","fabric","file/Pack.zip"]','key_key.jump:key.keyboard.space','key_key.inventory:key.keyboard.e','fullscreenResolution:1920x1080','lastServer:PRIVATE_HOST'];
  for(let i=0;i<35;i++)opts.push(`modOption_${i}:value_${i}`);
  fs.writeFileSync(path.join(root,'presets','options.txt'),opts.join('\n')+'\n');
  return root;
}
test('copia TODAS las opciones maestras en instalaciones previas y elimina opciones viejas',t=>{
  const root=fixture(t);
  fs.writeFileSync(path.join(root,'options.txt'),'version:3955\nfov:0.99\nsoundCategory_music:1.0\nmodOption_stale:true\nfullscreenResolution:1366x768\nlastServer:LOCAL_PRIVATE\n');
  const r=applyMasterCompleteOptions(root);
  assert.equal(r.first,true);
  assert.ok(r.applied>=40);
  assert.ok(r.total>=40);
  const o=fs.readFileSync(path.join(root,'options.txt'),'utf8');
  assert.match(o,/fov:0.25/);assert.match(o,/soundCategory_music:0.0/);
  assert.match(o,/key_key.jump:key.keyboard.space/);assert.match(o,/modOption_34:value_34/);
  assert.doesNotMatch(o,/modOption_stale/);
  assert.match(o,/fullscreenResolution:1366x768/);
  assert.match(o,/lastServer:LOCAL_PRIVATE/);
  assert.doesNotMatch(o,/PRIVATE_HOST/);
  assert.ok(fs.existsSync(r.backupFile));
});
test('respeta cambios personales posteriores sin perder ajustes nuevos del maestro',t=>{
 const root=fixture(t);applyMasterCompleteOptions(root);
 const f=path.join(root,'options.txt'); fs.writeFileSync(f,fs.readFileSync(f,'utf8').replace('guiScale:3','guiScale:2').replace('soundCategory_music:0.0','soundCategory_music:0.8'));
 const p=path.join(root,'presets','options.txt');fs.writeFileSync(p,fs.readFileSync(p,'utf8').replace('renderDistance:13','renderDistance:14'));
 const r=applyMasterCompleteOptions(root);
 assert.equal(r.first,false);assert.equal(r.preserved,2);
 const o=fs.readFileSync(f,'utf8');assert.match(o,/guiScale:2/);assert.match(o,/soundCategory_music:0.8/);assert.match(o,/renderDistance:14/);
});
test('no incorpora datos identificables, waypoints, ni datos de progreso como opciones',t=>{
 const root=fixture(t);const p=path.join(root,'presets','options.txt');
 fs.appendFileSync(p,'accountToken:SECRET_123\nwaypointSecret:45,-7,45\nadvancementProgress:99\n');
 applyMasterCompleteOptions(root);
 const o=fs.readFileSync(path.join(root,'options.txt'),'utf8');
 assert.doesNotMatch(o,/SECRET_123|waypointSecret|advancementProgress|PRIVATE_HOST/);
});
test('soporta migrar directamente desde el estado anterior v0.9.11 sin borrar backups',t=>{
 const root=fixture(t);const p=path.join(root,'config','chilly-willy');fs.mkdirSync(p,{recursive:true});
 fs.writeFileSync(path.join(p,'master-visual-state.json'),JSON.stringify({schema:1,managed:{fov:'0.25'}}));
 const o=path.join(root,'options.txt');fs.writeFileSync(o,'fov:0.7\nsoundCategory_music:0.5\n');
 assert.equal(applyMasterCompleteOptions(root).first,true);
 assert.match(fs.readFileSync(o,'utf8'),/soundCategory_music:0.0/);
 assert.ok(fs.existsSync(path.join(p,'master-visual-state.json')));
});
test('copia el icono legítimo sin tocar saves ni mapas, con respaldo',t=>{
 const root=fixture(t);const src=path.join(root,'presets','icon.png');const png=Buffer.from([137,80,78,71,13,10,26,10,...new Array(110).fill(0)]);
 fs.writeFileSync(src,png);fs.writeFileSync(path.join(root,'icon.png'),Buffer.from('original'));
 const r=copyMasterPackIcon(root);assert.equal(r.copied,true);assert.ok(fs.readFileSync(path.join(root,'icon.png')).equals(png));assert.equal(copyMasterPackIcon(root).copied,false);
});
test('manifiesto v6 permite el icono y rechaza almacenamiento personal',()=>{
 const files=[['mods/','abc.jar','MOD',123],['config/','sodium-options.json','OTHER',123],['resourcepacks/','Cobbleverse.zip','OTHER',456],['datapacks/','Cobbleverse.zip','OTHER',456],['shaderpacks/','ComplementaryUnbound_r5.8.1.zip','OTHER',456],['presets/','options.txt','OTHER',123],['presets/','icon.png','OTHER',400]];
 const items=files.map(([p,n,type,size],i)=>({path:p,name:n,type,size,updated:123456,url:`https://drive.usercontent.google.com/download?id=file${i}&export=download&confirm=t`}));
 const x=validateManifest({version:6,source:'cobbleverse-master',files:items});assert.equal(x.completeMaster,true);assert.equal(x.counts.presets,2);
 assert.throws(()=>validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],name:'username-cache.json'}]}),/individuales/);
 const preferences=validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],path:'config/roughlyenoughitems/',name:'favorites.json5'},{...items[1],path:'config/voicechat/',name:'player-volumes.properties'},{...items[1],path:'config/fancymenu/',name:'user_variables.db'}]});
 assert.equal(preferences.counts.config,4);
 assert.throws(()=>validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],path:'xaero/waypoints/'}]}));
 assert.throws(()=>validateManifest({version:6,source:'cobbleverse-master',files:[...items,{...items[1],path:'config/xaero/waypoints/'}]}),/exploración/);
});
