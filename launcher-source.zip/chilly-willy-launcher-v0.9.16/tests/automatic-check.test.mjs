import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const main = readFileSync(new URL('../electron/main.mjs', import.meta.url), 'utf8');
const ui = readFileSync(new URL('../ui/app.js', import.meta.url), 'utf8');

test('valida mods al abrir el launcher',()=>{
  assert.match(ui, /async function initializeLauncher\(\)/);
  assert.match(ui, /await checkModsManifest\(\)/);
  assert.match(ui, /initializeLauncher\(\);/);
});
test('reutiliza caché local antes de jugar y reconsulta Drive cuando corresponde',()=>{
  assert.match(main,/ipcMain\.handle\('launcher:play'/);
  assert.match(main,/launchMode\(\{entry:cached, settings, force:forced, remotePack:knownRemote\}\)/);
  assert.match(main,/const remote = await fetchManifest\(\)/);
});
test('Java 21 automático',()=>assert.match(main,/java: \{ install: 'auto' \}/));
test('acceso no bloqueado por comprobacion manual',()=>{
  assert.match(ui, /window\.cobble\.play\(\)/);
  assert.match(ui,/window\.cobble\.checkManifest\(showSuccess\)/);
});
