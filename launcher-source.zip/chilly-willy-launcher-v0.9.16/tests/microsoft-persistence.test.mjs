import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createCipheriv,createDecipheriv,randomBytes} from 'node:crypto';
import {loadMicrosoftSession,saveMicrosoftSession,deleteMicrosoftSession} from '../electron/secure-account-store.mjs';

// Fake reversible encryption ONLY for isolated tests. Production uses Electron safeStorage/Windows DPAPI.
const key=randomBytes(32);
const crypt={
  async isAsyncEncryptionAvailable(){return true;},
  async encryptStringAsync(text){const iv=randomBytes(12);const c=createCipheriv('aes-256-gcm',key,iv);const enc=Buffer.concat([c.update(text,'utf8'),c.final()]);return Buffer.concat([iv,c.getAuthTag(),enc]);},
  async decryptStringAsync(buf){const d=createDecipheriv('aes-256-gcm',key,buf.subarray(0,12));d.setAuthTag(buf.subarray(12,28));return {result:Buffer.concat([d.update(buf.subarray(28)),d.final()]).toString('utf8'),shouldReEncrypt:false};}
};
function temp(){return fs.mkdtempSync(path.join(os.tmpdir(),'chilly-ms-'));}
const account={name:'ChillyPlayer',uuid:'8afaa137b00b4f2b81a603fc934ffa02',access_token:'SECRET_ACCESS_TOKEN',refresh_token:'SECRET_REFRESH_TOKEN'};

test('Microsoft se recuerda cifrado tras reiniciar Setup o portable',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  assert.equal(await loadMicrosoftSession(dir,crypt),null);
  await saveMicrosoftSession(dir,crypt,account.name,account);
  const raw=fs.readFileSync(path.join(dir,'microsoft-session.enc'));
  assert.equal(raw.includes(Buffer.from(account.access_token)),false);
  assert.equal(raw.includes(Buffer.from(account.refresh_token)),false);
  assert.deepEqual(await loadMicrosoftSession(dir,crypt),{name:account.name,account});
});
test('Renovación sobrescribe tokens antiguos',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  await saveMicrosoftSession(dir,crypt,account.name,account);
  await saveMicrosoftSession(dir,crypt,account.name,{...account,access_token:'ROTATED',refresh_token:'ROTATED_REFRESH'});
  assert.equal((await loadMicrosoftSession(dir,crypt)).account.refresh_token,'ROTATED_REFRESH');
});
test('Cerrar sesión y cambiar a invitado borran cache Microsoft',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  await saveMicrosoftSession(dir,crypt,account.name,account);
  deleteMicrosoftSession(dir);
  deleteMicrosoftSession(dir);
  assert.equal(await loadMicrosoftSession(dir,crypt),null);
});
test('Nunca escribir tokens en claro si falla el cifrado',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const noEncryption={isAsyncEncryptionAvailable:async()=>false,encryptStringAsync:()=>{throw new Error('no');}};
  await assert.rejects(saveMicrosoftSession(dir,noEncryption,account.name,account),/cifrado/);
  assert.equal(fs.existsSync(path.join(dir,'microsoft-session.enc')),false);
});
test('Credenciales dañadas no se aceptan como sesión válida',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  await saveMicrosoftSession(dir,crypt,account.name,account);
  fs.writeFileSync(path.join(dir,'microsoft-session.enc'),Buffer.from('NO_ES_UNA_SESION'));
  await assert.rejects(loadMicrosoftSession(dir,crypt));
});
test('Rechaza cuentas extrañas o excesivamente grandes',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  await assert.rejects(saveMicrosoftSession(dir,crypt,'Jugador',null),/formato/);
  await assert.rejects(saveMicrosoftSession(dir,crypt,'Jugador',{blob:'x'.repeat(270000)}),/demasiado grande/);
});
test('No guarda perfil Microsoft dentro de preferences.json',async t=>{
  const dir=temp();t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  await saveMicrosoftSession(dir,crypt,account.name,account);
  assert.equal(fs.existsSync(path.join(dir,'preferences.json')),false);
});
