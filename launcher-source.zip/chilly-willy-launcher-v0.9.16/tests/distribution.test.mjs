import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
const dir = new URL('../', import.meta.url);
const pkg = JSON.parse(readFileSync(new URL('../package.json', import.meta.url), 'utf8'));
test('genera instalador NSIS y portable para Windows x64', () => {
  assert.deepEqual(pkg.build.win.target, ['nsis','portable']);
  assert.match(pkg.scripts['build:win'], /--win --x64/);
  assert.equal(pkg.build.nsis.oneClick, false);
  assert.match(pkg.build.portable.artifactName, /Portable/);
});
test('incluye constructor BAT y lanzador BAT para jugadores', () => {
  assert.ok(existsSync(new URL('../GENERAR_EXE.bat', import.meta.url)));
  assert.ok(existsSync(new URL('../distribucion/ABRIR_CHILLY_WILLY.bat', import.meta.url)));
  const text = readFileSync(new URL('../distribucion/ABRIR_CHILLY_WILLY.bat', import.meta.url),'utf8');
  assert.match(text, /Chilly-Willy-Launcher\.exe/);
  assert.doesNotMatch(text, /npm|node/i);
});
