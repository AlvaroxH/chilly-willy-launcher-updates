import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {parentDirectoryNeedsCreation} from '../electron/game-location.mjs';

test('Windows: no intenta mkdir sobre D:\\ si el destino tiene una sola carpeta', () => {
  assert.equal(parentDirectoryNeedsCreation('D:\\Cobbleverse', 'win32'), false);
  assert.equal(parentDirectoryNeedsCreation('D:\\Juegos\\Cobbleverse', 'win32'), true);
  assert.equal(parentDirectoryNeedsCreation('C:\\Users\\alvar\\Games', 'win32'), true);
});

test('Windows: no intenta crear la raíz de una unidad UNC', () => {
  assert.equal(parentDirectoryNeedsCreation('\\\\servidor\\compartido\\Cobbleverse', 'win32'), false);
  assert.equal(parentDirectoryNeedsCreation('\\\\servidor\\compartido\\Juegos\\Cobbleverse', 'win32'), true);
});

test('POSIX: distingue la raíz del sistema de una subcarpeta', () => {
  assert.equal(parentDirectoryNeedsCreation('/Cobbleverse', 'linux'), false);
  assert.equal(parentDirectoryNeedsCreation('/home/Cobbleverse', 'linux'), true);
});

test('UI no muestra una versión vieja, ni el package pierde compatibilidad', () => {
  const ui = readFileSync(new URL('../ui/index.html',import.meta.url),'utf8');
  const pkg = JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8'));
  assert.equal(pkg.version,'0.9.16');
  assert.match(ui,/Build 0\.9\.16/);
  assert.match(ui,/V0\.9\.16/);
  assert.equal(pkg.build.appId,'com.cobbleverse.launcher');
});
