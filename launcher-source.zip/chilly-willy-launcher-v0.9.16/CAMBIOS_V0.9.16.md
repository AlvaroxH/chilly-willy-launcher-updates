# Chilly Willy Launcher 0.9.16 — Corrección de carpetas en Windows

## Corregido

- Evita llamar a `mkdir('D:\')` cuando el usuario elige `D:\Cobbleverse` (o una carpeta directamente dentro de cualquier unidad). Esa llamada generaba `EPERM` en Windows aunque la carpeta raíz ya existía.
- También evita intentar recrear la raíz de unidades compartidas (UNC).
- Mantiene las validaciones de permisos, espacio disponible, carpetas vacías, copiado/verificación y respaldo de archivos.
- Corrige el texto estático `Build 0.9.14` de la parte superior para que diga `Build 0.9.16`, de acuerdo con `package.json`.
- Agrega pruebas automatizadas para el caso de la raíz `D:\` y rutas anidadas.

## Nuevo: actualización con un clic, sin asistente de instalación (a partir de esta versión)

- El Setup instalado consulta GitHub al abrir y **avisa** si hay versión nueva, pero **no descarga automáticamente** sin consentimiento.
- El jugador pulsa **Actualizar** una sola vez: se descarga en segundo plano con una barra y porcentaje real en el banner del launcher.
- Tras alcanzar el 100 %, el launcher indica que va a aplicar la actualización, se cierra brevemente y `electron-updater` ejecuta NSIS **en modo silencioso** (`quitAndInstall(true, true)`), sin asistente de instalación.
- El Setup actualizado vuelve a abrirse automáticamente. Se mantiene la ubicación del programa y los datos del perfil: no se borran mods, mundos, cuentas ni preferencias.
- Si Minecraft está en medio del proceso de arranque al terminar la descarga, **no se fuerza el cierre**; la actualización espera a que el usuario pulse «Finalizar actualización».
- No se instala nada solo por cerrar el launcher. El usuario controla el momento de actualizar.
- Windows puede mostrar una solicitud de permisos del sistema en instalaciones con elevación; el launcher **no intenta omitir la seguridad de Windows**.
- El progreso real mostrado corresponde a la **descarga**. La fase de reemplazo no puede dibujar progreso dentro de la misma ventana porque Electron debe cerrarse para sustituirse.
- **Compatibilidad:** al venir desde v0.9.15, el proceso de actualización lo gestiona el código ya instalado de v0.9.15 (anterior); puede mostrar el asistente **una última vez**. Para pasar desde v0.9.16 a las siguientes versiones se usa el flujo nuevo.
- El Portable continúa sin actualizarse solo.

## Qué no cambia

- El modpack, FancyMenu, Xaero y las cuentas de los usuarios no se modifican en esta versión.
- Tu ubicación ya movida sigue funcionando; no necesitás migrarla otra vez.
- Compatible con el flujo GitHub Actions existente. La release se crea en **borrador** hasta que la pruebes y publiques.

## Compilación

Ejecutá `INICIAR_COMPILACION_NUBE.cmd` del ZIP exterior desde Windows. Requiere GitHub CLI conectado con permisos de repositorio. El código fuente se subirá al repositorio público, previa confirmación.
