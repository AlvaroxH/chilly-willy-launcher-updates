# Chilly Willy Launcher 0.9.5 — Selección automática de resource packs

Se agrega un paso justo antes del arranque del proceso Minecraft: tras descargar los archivos, el launcher configura `resourcePacks:` en `options.txt` de la instancia aislada de Cobbleverse. Omite `.rpo` y archivos marcados `DO NOT ENABLE`. Conserva la configuración restante y se ejecuta en cada inicio.

### Compilar

Doble clic en `GENERAR_EXE.vbs`. Se generan Setup y Portable 0.9.5 junto al proyecto.

### Sin cambios de Google Apps Script

No es necesario reemplazar `Code.gs` si la URL actual ya enumera `resourcepacks`, `mods`, `config` y `datapacks`.

### Comprobar

Tras iniciar el juego, abrí Opciones > Paquetes de recursos. Los ZIP normales deberían aparecer en la columna de seleccionados. Minecraft puede rechazar alguno que tenga formato incompatible o pack.mcmeta inválido; este cambio solo automatiza su selección.
