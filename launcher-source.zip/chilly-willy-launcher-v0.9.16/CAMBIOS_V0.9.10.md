# v0.9.10 — Instalación maestra Cobbleverse

- Nueva fuente oficial: carpeta de Drive `1NSKkq-cvMuhjVLREf9Xfxz_fC2SWF-rM`.
- Descarga categorías aprobadas: mods, config, resourcepacks, shaderpacks, datapacks (solo referencia del cliente), defaultconfigs, cobblemon y archivo permitido de data.
- Copia de `options.txt` maestro hacia `presets/options.txt` como plantilla inicial, sin pisar opciones personales en los próximos arranques.
- Resource packs en el orden de prioridad definido en el options.txt maestro. Se excluyen los packs «DO NOT ENABLE» y Xray Ultimate.
- Se omiten saves, logs, screenshots, cachés, waypoints privados, historial de comandos, showdown y archivos internos.
- Mantiene el arranque automático con Fabric y Java 21 y el Auto-Updater Github de v0.9.9.
- Require instalar una vez la actualización del propio launcher y REPUBLICAR Apps Script existente como nueva versión para activar fuente maestra.
- No se implementa la eliminación automatizada de archivos obsoletos (seguridad); requerirá sistema de propiedad por manifiesto y backups.
- Sin garantías de descargas de Drive a gran escala; probar en Windows limpio con los archivos pesados.
