# Chilly Willy Launcher v0.9.4 — Invitados: preparación del servidor

**Qué cambia el ZIP:** se puede crear un perfil Invitado con un nick de 3 a 16 caracteres y pulsar JUGAR; el cliente utiliza el mecanismo offline de EML Lib. No cambia la configuración de Cobbleverse ni crea cuentas oficiales o licencias de Minecraft.

**Qué hay que preparar en Cobbleverse:** si el servidor Fabric tiene `online-mode=true`, rechazará al invitado. **No cambies ese ajuste sin antes proteger el servidor.** Una configuración incorrecta permitiría suplantar cuentas de usuarios, incluso operadores.

## Pasos seguros recomendados para el administrador

1. Hacé un backup completo del mundo, `playerdata`, `ops.json`, `whitelist.json`, `usercache.json` y configs desde Crafty. Un cambio de `online-mode` puede cambiar UUIDs, afectando inventarios, permisos y datos existentes.
2. Elegí y probá un sistema de autenticación de servidor que proteja cuentas invitadas y nombres premium. Ejemplo: **EasyAuth** para Fabric, con versión específica para Minecraft 1.21.1 y sus dependencias. Página del proyecto: https://modrinth.com/mod/easyauth y versión 1.21.1: https://modrinth.com/mod/easyauth/version/NQu1Efao . Revisá su documentación y configuraciones antes de instalar.
3. Configurá registro/login de invitados, protección de nombres y cuentas premium/operadores; probá los casos de suplantación ANTES de abrir el servidor al público. Nunca bases seguridad en un nick del cliente.
4. Solo cuando la autenticación ya esté configurada y probada, considerá `online-mode=false` en `server.properties` **si la arquitectura de autenticación elegida lo necesita**. Verificá el cambio de UUIDs y la compatibilidad con mods de servidor.
5. Con otra PC, comprobá acceso con nick propio, acceso Microsoft, rechazo de suplantación de un nick premium/operador y conservación de inventarios. Si falla una prueba, revertí el cambio y restaurá backups.

**No automatizamos** la modificación de `server.properties` porque no sabemos cómo está protegido tu servidor actual. Activar el botón Invitado en el launcher no equivale a habilitarlo en Fabric.

## Limitaciones actuales

- La cuenta Invitado no se valida contra Microsoft. No verifica titularidad de una licencia de Minecraft.
- Los jugadores invitados no tienen una skin oficial verificable por UUID; se verá el avatar genérico salvo integración adicional.
- Se conserva el mismo Google Apps Script `/exec`; para recursos completos hace falta que la implementación publique `mods`, `config`, `resourcepacks` y `datapacks`.
- No se ha probado el arranque real con un invitado o Microsoft en un servidor externo durante esta preparación.
