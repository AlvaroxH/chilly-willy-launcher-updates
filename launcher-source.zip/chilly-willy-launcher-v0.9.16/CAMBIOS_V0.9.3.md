# Chilly Willy Launcher v0.9.3 — Estabilidad de Google Drive

Esta versión conserva el diseño y el servidor de Cobbleverse, las carpetas del modpack y el acceso Microsoft/invitado. Corrige un posible problema en la consulta del manifiesto:

- El tiempo de espera por consulta sube de 20 a 90 segundos para Apps Script con muchas carpetas.
- Se realiza un reintento automático ante fallos temporales de red o HTTP 429/5xx.
- Se distinguen errores de timeout, red, permisos (HTTP 403) y JSON inválido.
- El launcher muestra que está reintentando, para que el usuario no lo confunda con una descarga bloqueada.

## Instalar

1. Extraé el ZIP en una carpeta nueva fuera de OneDrive.
2. Abrí `GENERAR_EXE.vbs` en Windows para generar setup y portable 0.9.3.
3. Instalá el setup 0.9.3 reemplazando el anterior.
4. No hace falta modificar el Apps Script si en la interfaz ya aparece «138 mods y recursos completos».

## Diagnóstico rápido

Abrí la URL /exec de `config/server.json` en incógnito. Debe mostrar JSON con `"version":3` y `"files"`.
Si el navegador tampoco responde o pide iniciar sesión, revisá la implementación de Apps Script, no Minecraft.

## Avisos

- No se pudo ejecutar el launcher o comprobar Apps Script en vivo desde este entorno.
- Las descargas completas de Drive y el arranque real de Minecraft deben probarse en Windows.
- El modo invitado requiere configuración y verificación de seguridad en el servidor; no se modifica `online-mode` desde este paquete.
