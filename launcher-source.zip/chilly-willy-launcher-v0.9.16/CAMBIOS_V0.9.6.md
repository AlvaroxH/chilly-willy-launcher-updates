# Chilly Willy Launcher v0.9.6 — Controles del modpack

- Detecta `config/defaultoptions/keybindings.txt` (ya alojado en tu Google Drive).
- Aplica la distribución de teclado de Cobbleverse antes de que Minecraft inicie.
- En una instalación NUEVA inicializa también `options.txt` usando `config/defaultoptions/options.txt` si existe.
- Para quienes vienen de versiones anteriores, realiza una migración de controles **una sola vez**, guarda copia de seguridad en `options.txt.chilly-willy-before-keybindings.bak` y después respeta cambios manuales de teclas.
- Si cambian los controles sugeridos en Drive, actualiza solo aquellos que el jugador no haya personalizado desde la sincronización anterior.
- Sigue activando automáticamente los resource packs desde Drive; no cambia el resto del launcher.
- No hace falta modificar Google Apps Script si `config/` ya se publica correctamente.

**Atención al actualizar desde v0.9.5:** la primera apertura de v0.9.6 aplicará los controles predeterminados de Cobbleverse, incluso si el usuario había elegido otros previamente. Su `options.txt` anterior queda respaldado; futuras personalizaciones se respetarán.

**Pruebas locales:** verificación de lógica de teclas y resource packs; no se ha ejecutado Minecraft en Windows ni comprobado el descargador final de EML en esta sesión.
