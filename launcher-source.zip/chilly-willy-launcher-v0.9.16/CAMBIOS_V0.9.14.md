# Chilly Willy Launcher v0.9.14 — Directorios seleccionables

## Dos ubicaciones independientes

- **Carpeta del launcher:** el asistente NSIS (Setup.exe) incluye **Examinar** para elegir dónde instalar el programa, por ejemplo `D:\Programas\Chilly Willy Launcher`. La selección del directorio es parte del asistente de instalación; no modifica dónde EML guarda Minecraft.
- **Carpeta del juego:** al iniciar por primera vez sin una instalación existente aparece un selector previo a la descarga. Desde **Ajustes → Carpeta de Minecraft y modpack** se puede elegir y cambiar después. El juego se puede guardar en `E:\Juegos\Cobbleverse`.

## Migración de instalaciones existentes

EML Lib 2.7.x fija su directorio raíz en `%APPDATA%\.cobbleverse`. La v0.9.14 utiliza una *junction* de Windows para que esa ruta apunte a una carpeta de otro disco. A la carpeta elegida van Java, assets, libraries, mods, saves, options.txt, shaderpacks y demás archivos que gestiona EML.

1. Elegir carpeta nueva o vacía mediante el selector gráfico de Windows.
2. Confirmar la migración. El launcher no permite hacerla mientras Minecraft inicia o está en ejecución.
3. Copiar los archivos a una carpeta temporal en la unidad de destino.
4. Validar cantidad/tamaño de los archivos y comprobar espacio libre cuando se pueda.
5. Activar la unión con la carpeta nueva y verificarla.
6. Solo después de validar, eliminar el respaldo anterior. Si la eliminación falla, el launcher mostrará dónde quedó el respaldo para limpieza posterior. Cuando se cambia **otra vez** un destino que estaba enlazado previamente, el directorio anterior se conserva como respaldo y se informa su ruta.

No se trasladan ni modifican las cuentas cifradas ni las preferencias de autenticación del launcher. La cuenta Microsoft sigue bajo la carpeta de datos del usuario de Windows.

## Límites y precauciones

- Las junctions necesitan que la unidad de destino esté conectada. Preferí discos fijos NTFS con permisos de escritura; no uses ubicaciones de red, carpetas protegidas o la raíz de un disco.
- La carpeta de Minecraft seleccionada debe estar vacía para evitar conflictos de archivos.
- Durante la migración entre discos, se necesita espacio para una copia completa hasta terminar la validación. No cierres el launcher ni apagues Windows durante el proceso.
- La ruta de instalación del programa se elige desde **Setup.exe**. El Portable no tiene asistente.
- El Auto-Updater y la autenticación mantienen el mecanismo de versiones anteriores.

## Pruebas

111 pruebas de Node superadas en Linux, incluidas pruebas de migración, rutas anidadas, carpeta ocupada y persistencia de preferencias. Falta comprobar una instalación y migración reales de Windows y que el Setup muestre el selector de ruta al compilarse en GitHub.
