# Chilly Willy Launcher v0.9.9 — Actualización automática

- Repositorio: https://github.com/AlvaroxH/chilly-willy-launcher-updates
- Nuevo: `electron-updater` + Github Releases, comprobación al abrir (Windows Setup instalado).
- Detecta Releases posteriores, descarga en segundo plano, informa porcentaje real y ofrece «Instalar y reiniciar».
- No interfiere con Google Drive, mods, Java, Fabric ni sesiones guardadas.
- Instala al aceptar explícitamente; no interrumpe mientras está lanzando Minecraft.
- Portable/desarrollo: actualización del programa no disponible.
- **Importante:** la Release debe contener `latest.yml`, el instalador NSIS indicado allí y, preferentemente, el `.blockmap`. El Setup 0.9.8 anterior NO se actualiza solo.
- Firma de código recomendada antes de distribuir a más usuarios. Sin firma Windows puede mostrar SmartScreen.
- Pruebas unitarias locales realizadas; publicación real y autoactualización en Windows aún sin verificar.
