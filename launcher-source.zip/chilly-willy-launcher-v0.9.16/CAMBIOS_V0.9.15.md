# Chilly Willy Launcher v0.9.15 — Inicio rápido

- Después de una instalación verificada, JUGAR reutiliza mods, recursos, configuraciones y shaders descargados.
- No se manda `modpackUrl` a EML Lib en inicios rápidos; se evitan las verificaciones masivas de Drive por cada partida.
- La presencia y tamaño de todos los JAR del modpack y de los archivos fundamentales se comprueban localmente antes de optar por el inicio rápido.
- Las novedades de Drive se comprueban cada 2 horas; se fuerza una revisión completa cada 24 horas como seguridad.
- Cuando cambie el manifiesto, falte un archivo o el usuario elija reparar, se ejecuta la sincronización completa.
- Si Google Apps Script está temporalmente inaccesible, el modpack previamente verificado puede iniciarse con su caché.
- Nuevo botón en Mods: **Reparar en el próximo inicio**.
- No modifica instalación por discos, credenciales, mundos, waypoints ni iconos.

**Alcance:** reduce especialmente el tiempo de preparación del modpack en inicios sucesivos. EML Lib puede seguir comprobando bibliotecas básicas de Minecraft y Java; el tiempo real depende del disco y del equipo. La compilación con Windows/GitHub Actions y un inicio real de Minecraft todavía deben probarse.
