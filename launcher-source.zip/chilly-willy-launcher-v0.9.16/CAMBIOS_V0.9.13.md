# Chilly Willy Launcher v0.9.13

- Copia verificada de la configuración maestra completa: **config/**, **cobblemon/**, **data/** y **presets/**, antes de Java. No distribuye exploraciones/waypoints Xaero ni progreso o datos de jugador.
- Recuperación del perfil `cobbleverse` de Xaero (minimap, world-map, lib), assets FancyMenu y fondos Custom Splash Screen, con copia de seguridad de archivos previos.
- UI: logo de pingüino. Escritorio: pingüino. Barra de tareas y ejecutable: emblema C púrpura (en Windows puede requerir desanclar el icono viejo).
- Compilación GitHub Actions: Setup, Portable, .blockmap y latest.yml. Los archivos del modpack NO se incluyen en el exe.

La v0.9.13 se prueba primero como release Draft; al publicarse aparecerá como actualización automática en el Setup instalado, sujeto a una prueba real en Windows.

No hace falta cambiar Code.gs si v0.9.12 (manifiesto v6) ya estaba desplegado correctamente.
